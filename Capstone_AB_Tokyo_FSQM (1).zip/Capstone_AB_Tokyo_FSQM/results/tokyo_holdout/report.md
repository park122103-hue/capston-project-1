# fsqm_holdout | Router sabre

16 ca mạch–topology, 3 seed, 192 dòng PASS, 0 kiểm tra toán tử và cấu trúc, 192 kiểm tra cấu trúc.

| Phương án | Mốc | ΔCX (%) | KTC 95% | ΔCX | Thắng/Hòa/Thua | ΔDepth (%) | T mapping | T biên dịch |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| A | G | 0.55 | [-1.08, 2.64] | -28.12 | 5/8/3 | 0.88 | 1.45× | 1.13× |
| B | G | -3.08 | [-8.54, 0.18] | -30.56 | 6/7/3 | -0.24 | 1.48× | 1.10× |
| A+B | G | -3.26 | [-8.84, 0.30] | -91.50 | 8/5/3 | -0.86 | 1.89× | 1.06× |
| A+B | A | -3.75 | [-9.10, -0.43] | -63.38 | 9/4/3 | -1.84 | 1.30× | 0.94× |
| A+B | B | -0.19 | [-0.79, 0.52] | -60.94 | 4/11/1 | -0.60 | 1.28× | 0.96× |
| A | B | 5.32 | [-0.01, 14.28] | 2.44 | 4/4/8 | 2.54 | 0.98× | 1.03× |

Trung bình theo seed trước, sau đó cho mỗi ca mạch–topology trọng số bằng nhau. KTC bootstrap gom theo tên mạch. Tỷ lệ thời gian là trung bình nhân qua các ca. Thời gian biên dịch tính từ mạch đã chuẩn hóa.
