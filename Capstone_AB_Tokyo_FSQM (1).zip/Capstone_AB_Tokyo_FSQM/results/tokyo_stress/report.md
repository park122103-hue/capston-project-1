# fsqm_stress | Router sabre

3 ca mạch–topology, 1 seed, 12 dòng PASS, 0 kiểm tra toán tử và cấu trúc, 12 kiểm tra cấu trúc.

| Phương án | Mốc | ΔCX (%) | KTC 95% | ΔCX | Thắng/Hòa/Thua | ΔDepth (%) | T mapping | T biên dịch |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| A | G | 0.00 | [0.00, 0.00] | 0.00 | 0/3/0 | 0.00 | 1.49× | 0.96× |
| B | G | 2.50 | [0.56, 6.15] | 3980.00 | 0/0/3 | 1.87 | 1.08× | 0.97× |
| A+B | G | 0.55 | [0.30, 0.78] | 1433.00 | 0/0/3 | 0.37 | 1.78× | 1.13× |
| A+B | A | 0.55 | [0.30, 0.78] | 1433.00 | 0/0/3 | 0.37 | 1.19× | 1.18× |
| A+B | B | -1.84 | [-5.51, 0.00] | -2547.00 | 1/2/0 | -1.43 | 1.65× | 1.16× |
| A | B | -2.37 | [-5.79, -0.55] | -3980.00 | 3/0/0 | -1.80 | 1.38× | 0.98× |

Trung bình theo seed trước, sau đó cho mỗi ca mạch–topology trọng số bằng nhau. KTC bootstrap gom theo tên mạch. Tỷ lệ thời gian là trung bình nhân qua các ca. Thời gian biên dịch tính từ mạch đã chuẩn hóa.
