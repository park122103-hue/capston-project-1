# fsqm_fit | Router sabre

9 ca mạch–topology, 3 seed, 108 dòng PASS, 0 kiểm tra toán tử và cấu trúc, 108 kiểm tra cấu trúc.

| Phương án | Mốc | ΔCX (%) | KTC 95% | ΔCX | Thắng/Hòa/Thua | ΔDepth (%) | T mapping | T biên dịch |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| A | G | -3.99 | [-7.67, -1.10] | -29.44 | 6/2/1 | -2.10 | 1.13× | 0.95× |
| B | G | -4.18 | [-11.71, 1.77] | 14.67 | 3/4/2 | -6.69 | 1.33× | 1.10× |
| A+B | G | -3.83 | [-9.36, 0.52] | 2.89 | 4/2/3 | -2.17 | 1.67× | 1.06× |
| A+B | A | 0.08 | [-2.87, 2.52] | 32.33 | 1/5/3 | -0.09 | 1.48× | 1.12× |
| A+B | B | 0.81 | [-1.54, 4.16] | -11.78 | 2/3/4 | 7.42 | 1.26× | 0.97× |
| A | B | 1.12 | [-3.65, 8.00] | -44.11 | 4/2/3 | 7.79 | 0.85× | 0.86× |

Trung bình theo seed trước, sau đó cho mỗi ca mạch–topology trọng số bằng nhau. KTC bootstrap gom theo tên mạch. Tỷ lệ thời gian là trung bình nhân qua các ca. Thời gian biên dịch tính từ mạch đã chuẩn hóa.
