"""Run the Capstone A, B and A+B initial-mapping comparison."""

import argparse
from dataclasses import asdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
import os
import sys

# Set the same defaults in the parent process and its workers.
for variable in ("RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(variable, "1")

from qiskit import qpy, transpile
from qiskit.quantum_info import Operator

from .catalog import (
    ROOT, FSQM_CONFIG, FSQM_FIT, FSQM_TOPOLOGY, SUITES, case_catalog, file_hash,
    hardware_catalog, read_json, select_cases, write_csv, write_json,
)
from .compiler import (
    BASIS, METHODS, POST_OPT, ROUTERS, Arm, CompilerOptions, compile_circuit, interaction_weights,
    load_unitary, normalize,
)
from .mapping import PlacementProblem
from .study import evaluation_arms, lock_output, make_spec, run_case, run_study, search_space
from .verification import Verifier


def positive(value):
    value = int(value)
    if value < 1:
        raise argparse.ArgumentTypeError("Expected a positive integer")
    return value


def nonnegative(value):
    value = int(value)
    if value < 0:
        raise argparse.ArgumentTypeError("Expected a nonnegative integer")
    return value


def parameter_grid(value, *, integer=False):
    def number(token):
        result = Decimal(token)
        if not result.is_finite() or result < 0 or (not integer and result > 1):
            raise ValueError
        if integer and result != result.to_integral_value():
            raise ValueError
        return result

    try:
        if ":" in value:
            parts = value.split(":")
            if len(parts) not in (2, 3):
                raise ValueError
            start, stop = map(number, parts[:2])
            step = number(parts[2]) if len(parts) == 3 else Decimal(1 if integer else "0.1")
            if start > stop or step <= 0:
                raise ValueError
            count = int((stop - start) // step) + 1
            values = (start + step * index for index in range(count))
        else:
            values = map(number, value.split(","))
        result = list(map(int if integer else float, values))
        if len(result) != len(set(result)):
            raise ValueError
        return result
    except (ValueError, InvalidOperation, OverflowError):
        domain = "nonnegative integer K" if integer else "alpha in [0, 1]"
        raise argparse.ArgumentTypeError(
            f"Expected unique {domain} values as a list or an ascending start:stop[:step] range"
        ) from None


def seeds(value):
    result = [nonnegative(seed) for seed in value.split(",")]
    if len(set(result)) != len(result) or any(seed > 2**32 - 1 for seed in result):
        raise argparse.ArgumentTypeError("Seeds must be unique unsigned 32-bit integers")
    return result


def methods(value):
    result = [method.strip().upper() for method in value.split(",")]
    if len(set(result)) != len(result) or not set(result) <= set(METHODS):
        raise argparse.ArgumentTypeError(f"Choose unique methods from {','.join(METHODS)}")
    return result


def compiler_flags(parser):
    parser.add_argument("--router", choices=ROUTERS, default="sabre")
    parser.add_argument("--post-opt", choices=POST_OPT, default="none")
    parser.add_argument("--swap-trials", type=positive, default=1)
    parser.add_argument("--layout-trials", type=positive, default=1)
    parser.add_argument("--sabre-iterations", type=positive, default=3)
    parser.add_argument("--operator-max-qubits", type=nonnegative, default=6)


def study_flags(parser):
    parser.add_argument("--out", type=Path)
    parser.add_argument("--topology")
    parser.add_argument("--circuit")
    parser.add_argument("--seeds", type=seeds)
    parser.add_argument("--repeats", type=positive)
    parser.add_argument("--warmups", type=nonnegative)
    parser.add_argument("--timeout", type=nonnegative)
    parser.add_argument("--resume", action="store_true")
    compiler_flags(parser)


def catalog(args):
    circuits = case_catalog()
    topologies = hardware_catalog()
    for topology in topologies.values():
        print(f"{topology.name}: {topology.width} physical qubits, {len(topology.edges)} undirected edges")
    print(f"{len(list((ROOT / 'benchmarks').glob('*.qasm')))} QASM files")
    for suite in SUITES:
        print(f"{suite}: {len(circuits[suite])} topology/circuit cases")
        if args.verbose:
            for case in circuits[suite]:
                print(f"    {case.label}")
    manifest = read_json(ROOT / "config/input_manifest.json")
    changed = [name for name, digest in manifest["files"].items() if file_hash(ROOT / name) != digest]
    if changed:
        raise ValueError(f"Alpha inputs differ from the original archive: {', '.join(changed)}")
    print(f"Verified {len(manifest['files'])} original Alpha files by SHA-256")
    manifest = read_json(FSQM_CONFIG)
    changed = [name for name, digest in manifest["files"].items() if file_hash(ROOT / name) != digest]
    if changed:
        raise ValueError(f"FSQM inputs differ from the archived QASM: {', '.join(changed)}")
    print(f"Verified {len(manifest['files'])} FSQM inputs by SHA-256")


def midterm(args):
    source = ROOT / "fixtures/midterm_normalized.qpy"
    manifest = read_json(ROOT / "config/input_manifest.json")
    if file_hash(source) != manifest["midterm_fixture"]["sha256"]:
        raise ValueError("Midterm fixture hash does not match")
    with source.open("rb") as handle:
        logical, = qpy.load(handle)
    hardware = hardware_catalog()["line5"]
    coupling = hardware.coupling_map()
    options = CompilerOptions(router="basic")
    verifier = Verifier(logical, hardware, 6)
    problem = PlacementProblem(interaction_weights(logical), hardware.distances)
    _, optimum, ties, layouts = problem.exhaustive(120)
    if (optimum, ties, layouts, verifier.input_cx) != (15, 4, 120, 14):
        raise ValueError("Midterm fixture differs from the reported interaction cost")
    expected = {
        "T": ((0, 1, 2, 3), 20, 3, 23, 90),
        "G": ((2, 1, 3, 0), 15, 2, 20, 77),
    }
    arms, param_source = evaluation_arms(("T", "G", "A", "B", "A+B"), search_space(), args.params)
    rows = []
    for arm in arms:
        compiled = compile_circuit(logical, hardware, coupling, arm, 42, options)
        quality = verifier.check(compiled)
        cost = problem.cost(compiled.initial)
        actual = compiled.initial, cost, quality["swap"], quality["cx"], quality["depth"]
        if arm.method in expected:
            legacy = transpile(
                logical, basis_gates=list(BASIS), coupling_map=coupling, routing_method="basic",
                initial_layout=list(compiled.initial), optimization_level=0, seed_transpiler=42,
            )
            if actual != expected[arm.method] or (legacy.count_ops()["cx"], legacy.depth()) != actual[-2:]:
                raise ValueError(f"Midterm regression for {arm.method}: {actual}")
        rows.append({"method": arm.method, "alpha": arm.alpha, "width": arm.width,
                     "initial_layout": list(compiled.initial), "final_layout": list(compiled.final),
                     "uniform_cost": cost, "mapping_cost": compiled.mapping_cost, **quality})
        print(f"{arm.method:3s} M={list(compiled.initial)} C={cost} "
              f"SWAP={quality['swap']} CX={quality['cx']} depth={quality['depth']}")
    write_csv(args.out / "midterm.csv", rows)
    write_json(args.out / "midterm.json", {
        "fixture_sha256": file_hash(source), "router": "basic", "seed": 42,
        "parameter_source": param_source, "c_static_optimum": optimum,
        "optimum_ties": ties, "layouts": layouts, "input_cx": verifier.input_cx,
    })


def execute(args):
    from .analysis import choose_fit, write_report

    cases = select_cases(args.suite, args.topology, args.circuit)
    spec = make_spec(args, cases)
    output = (args.out or Path("results") / args.suite).resolve()
    with lock_output(output):
        study, rows = run_study(output, spec, resume=args.resume)
        if not all(row["status"] == "PASS" for row in rows):
            print(f"Inspect failed rows in {output / 'raw.csv'} and rerun with --resume", file=sys.stderr)
            return 1
        if args.command == "fit":
            selected = choose_fit(study, rows, output)
            print(f"Frozen settings: alpha={selected['alpha']}, K={selected['width']}")
        else:
            write_report(study, rows, output)
    print(output)


def analyze(args):
    from .analysis import choose_fit, read_raw, write_report

    with lock_output(args.out):
        study = read_json(args.out / "study.json")
        rows = read_raw(args.out / "raw.csv")
        if study["spec"]["phase"] == "fit":
            choose_fit(study, rows, args.out)
        else:
            write_report(study, rows, args.out)


def compile_one(args):
    graph = hardware_catalog()[args.topology]
    options = CompilerOptions(args.router, args.swap_trials, args.layout_trials,
                              args.sabre_iterations, args.post_opt, args.operator_max_qubits)
    original = load_unitary(args.qasm, trim_idle=graph.name == FSQM_TOPOLOGY)
    logical = normalize(original)
    if logical.num_qubits <= options.operator_max_qubits and not Operator(original).equiv(Operator(logical)):
        raise ValueError("Basis normalization changed the input unitary")
    default_arms, _ = evaluation_arms((args.method,), search_space(), args.params)
    [default] = default_arms
    arm = Arm(default.label, default.method,
              args.alpha if args.alpha is not None else default.alpha,
              args.width if args.width is not None else default.width)
    compiled = compile_circuit(logical, graph, graph.coupling_map(), arm, args.seed, options)
    metrics = Verifier(logical, graph, options.operator_max_qubits).check(compiled)
    result = {
        "arm": asdict(arm), "topology": graph.name, "seed": args.seed, "options": asdict(options),
        "circuit_sha256": file_hash(args.qasm), "initial_layout": list(compiled.initial),
        "final_layout": list(compiled.final), "mapping_cost": compiled.mapping_cost,
        **metrics, **compiled.times,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    for name, circuit in (("routed.qpy", compiled.routed), ("compiled.qpy", compiled.output)):
        with (args.out / name).open("wb") as handle:
            qpy.dump(circuit, handle)
    write_json(args.out / "metrics.json", result)
    print(f"{metrics['verification']} | SWAP={metrics['swap']} CX={metrics['cx']} depth={metrics['depth']}")
    print(args.out.resolve())


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)

    inventory = commands.add_parser("catalog", help="List and verify the original Alpha inputs")
    inventory.add_argument("--verbose", action="store_true")
    inventory.set_defaults(handler=catalog)

    baseline = commands.add_parser("midterm", help="Reproduce the reported Line5 baseline")
    baseline.add_argument("--params", type=Path)
    baseline.add_argument("--out", type=Path, default=Path("results/midterm"))
    baseline.set_defaults(handler=midterm)

    fit = commands.add_parser("fit", help="Choose A and B settings on the development suite")
    study_flags(fit)
    fit.add_argument("--suite", choices=("fit", FSQM_FIT), default="fit")
    fit.add_argument("--alpha-grid", type=parameter_grid,
                     help="Comma-separated values or start:stop[:step] (default step 0.1)")
    fit.add_argument("--k-grid", type=lambda value: parameter_grid(value, integer=True),
                     help="Comma-separated values or start:stop[:step] (default step 1)")
    fit.set_defaults(handler=execute)

    run = commands.add_parser("run", help="Compare frozen settings on a benchmark suite")
    run.add_argument("--suite", choices=SUITES, default="smoke")
    run.add_argument("--params", type=Path, help="Freeze settings with fit/selected.json")
    run.add_argument("--methods", type=methods, default=list(METHODS))
    study_flags(run)
    run.set_defaults(handler=execute)

    single = commands.add_parser("compile", help="Run one method on a QASM circuit and export QPY")
    single.add_argument("qasm", type=Path)
    single.add_argument("--topology", required=True)
    single.add_argument("--method", choices=METHODS, default="A+B")
    single.add_argument("--params", type=Path)
    single.add_argument("--alpha", type=float)
    single.add_argument("--k", "--width", dest="width", type=nonnegative)
    single.add_argument("--seed", type=nonnegative, default=42)
    single.add_argument("--out", type=Path, default=Path("results/single"))
    compiler_flags(single)
    single.set_defaults(handler=compile_one)

    report = commands.add_parser("analyze", help="Regenerate results from raw CSV")
    report.add_argument("--out", type=Path, required=True)
    report.set_defaults(handler=analyze)

    worker = commands.add_parser("_case", help=argparse.SUPPRESS)
    worker.add_argument("manifest", type=Path)
    worker.add_argument("index", type=nonnegative)
    worker.add_argument("checkpoint", type=Path)
    worker.set_defaults(handler=lambda args: run_case(args.manifest, args.index, args.checkpoint))

    args = parser.parse_args(argv)
    try:
        return args.handler(args) or 0
    except (ValueError, OSError, KeyError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
