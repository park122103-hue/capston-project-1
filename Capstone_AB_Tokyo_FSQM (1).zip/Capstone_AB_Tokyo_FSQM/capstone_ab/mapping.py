"""Interaction cost and bounded one-step lookahead for initial placement.

A layout is a tuple indexed by logical qubit whose values are physical sites.
Temporal weights are represented as scaled integers to make ties reproducible.
"""

from collections import deque
from dataclasses import dataclass
from itertools import permutations
from math import perm


def distances_from_edges(width, edges):
    if width < 1:
        raise ValueError("Hardware width must be positive")
    neighbors = [[] for _ in range(width)]
    for a, b in edges:
        if not (0 <= a < width and 0 <= b < width) or a == b:
            raise ValueError(f"Invalid hardware edge {(a, b)}")
        neighbors[a].append(b)
        neighbors[b].append(a)

    distances = []
    for source in range(width):
        distance = [-1] * width
        distance[source] = 0
        pending = deque([source])
        while pending:
            current = pending.popleft()
            for neighbor in neighbors[current]:
                if distance[neighbor] == -1:
                    distance[neighbor] = distance[current] + 1
                    pending.append(neighbor)
        if -1 in distance:
            raise ValueError("Hardware graph must be connected")
        distances.append(tuple(distance))
    return tuple(distances)


def check_layout(layout, n, m):
    if (
        len(layout) != n
        or len(set(layout)) != n
        or any(not isinstance(p, int) or not 0 <= p < m for p in layout)
    ):
        raise ValueError(f"Invalid layout for logical/physical widths {n}/{m}: {layout}")


@dataclass(frozen=True)
class SearchResult:
    layout: tuple
    cost: int
    evaluations: int = 0


class PlacementProblem:
    def __init__(self, weights, distances):
        self.n = len(weights)
        self.m = len(distances)
        if not 1 <= self.n <= self.m or any(len(row) != self.n for row in weights):
            raise ValueError("W must be square and logical width must fit the hardware")
        if any(
            type(weight) is not int or weight < 0 or weight != weights[j][i]
            or (i == j and weight != 0)
            for i, row in enumerate(weights) for j, weight in enumerate(row)
        ):
            raise ValueError("W must be symmetric, nonnegative and have a zero diagonal")
        self.weights = weights
        self.distances = distances
        self.centrality = tuple(map(sum, distances))
        self.importance = tuple(map(sum, weights))
        self.interactions = tuple(
            tuple((j, weight) for j, weight in enumerate(row) if weight)
            for row in weights
        )
        self.pairs = tuple(
            (i, j, weight)
            for i, neighbors in enumerate(self.interactions)
            for j, weight in neighbors
            if i < j
        )
        self.order = self.logical_order()

    def logical_order(self):
        affinity = [0] * self.n
        remaining = set(range(self.n))
        order = []
        while remaining:
            logical = min(
                remaining, key=lambda q: (-affinity[q], -self.importance[q], q)
            )
            order.append(logical)
            remaining.remove(logical)
            for other, weight in self.interactions[logical]:
                affinity[other] += weight
        return tuple(order)

    def cost(self, layout):
        check_layout(layout, self.n, self.m)
        return self._cost(layout)

    def _cost(self, layout):
        return sum(
            weight * self.distances[layout[i]][layout[j]]
            for i, j, weight in self.pairs
        )

    def _position_scores(self, logical, assigned, free):
        partners = [
            (assigned[other], weight)
            for other, weight in self.interactions[logical]
            if assigned[other] != -1
        ]
        return (
            (
                sum(weight * self.distances[physical][other] for other, weight in partners),
                self.centrality[physical],
                physical,
            )
            for physical in free
        )

    def _complete(self, assigned, free, start):
        layout = assigned.copy()
        free = free.copy()
        for logical in self.order[start:]:
            position = min(self._position_scores(logical, layout, free))[-1]
            layout[logical] = position
            free.remove(position)
        return tuple(layout)

    def greedy(self):
        layout = self._complete([-1] * self.n, set(range(self.m)), 0)
        return SearchResult(layout, self._cost(layout))

    def lookahead(self, width):
        """Choose a site by placing one additional logical qubit hypothetically."""
        if type(width) is not int or width < 0:
            raise ValueError("Lookahead width must be a nonnegative integer")
        if width <= 1:
            return self.greedy()
        assigned = [-1] * self.n
        free = set(range(self.m))
        anchor = min(free, key=lambda p: (self.centrality[p], p))
        assigned[self.order[0]] = anchor
        free.remove(anchor)
        evaluations = 0

        for logical, next_logical in zip(self.order[1:], self.order[2:]):
            candidates = sorted(self._position_scores(logical, assigned, free))[:width]
            ranked = []
            for local_cost, centrality, site in candidates:
                assigned[logical] = site
                remaining = free - {site}
                next_cost = min(self._position_scores(next_logical, assigned, remaining))[0]
                ranked.append((local_cost + next_cost, local_cost, centrality, site))
            site = min(ranked)[-1]
            assigned[logical] = site
            free.remove(site)
            evaluations += len(candidates)

        if self.n > 1:
            last = self.order[-1]
            assigned[last] = min(self._position_scores(last, assigned, free))[-1]
        layout = tuple(assigned)
        return SearchResult(layout, self._cost(layout), evaluations)

    def exhaustive(self, limit):
        count = perm(self.m, self.n)
        if count > limit:
            raise ValueError(f"{count:,} layouts exceed exhaustive limit {limit:,}")

        best_cost = None
        best_layout = None
        ties = 0
        for layout in permutations(range(self.m), self.n):
            cost = self._cost(layout)
            if best_cost is None or cost < best_cost:
                best_cost, best_layout, ties = cost, layout, 1
            elif cost == best_cost:
                ties += 1
        return best_layout, best_cost, ties, count
