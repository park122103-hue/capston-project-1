"""Controlled Qiskit compiler pipeline with explicit native-SWAP capture."""

from dataclasses import dataclass
import math
import re
from time import perf_counter_ns

from qiskit import QuantumCircuit, qasm2, qasm3, transpile
from qiskit.circuit import Gate
from qiskit.circuit.equivalence_library import SessionEquivalenceLibrary
from qiskit.circuit.library import CXGate
from qiskit.transpiler import PassManager
from qiskit.transpiler.passes import BasicSwap, BasisTranslator, InverseCancellation, SabreLayout, SabreSwap

from .mapping import PlacementProblem, check_layout

BASIS = ("rz", "sx", "x", "cx")
METHODS = ("G", "A", "B", "A+B", "SABRE-FULL")
ROUTERS = ("sabre", "basic")
POST_OPT = ("none", "cancel-cx")
WEIGHT_SCALE = 10**12


@dataclass(frozen=True)
class Arm:
    label: str
    method: str
    alpha: float = 1.0
    width: int = 1

    def __post_init__(self):
        if self.method not in METHODS + ("T",):
            raise ValueError(f"Unknown mapping method {self.method}")
        if not 0 <= self.alpha <= 1 or type(self.width) is not int or self.width < 0:
            raise ValueError("Expected 0 <= alpha <= 1 and a nonnegative K")
        if self.method not in {"A", "A+B"} and self.alpha != 1:
            raise ValueError("Temporal weighting is only used by A and A+B")
        if self.method not in {"B", "A+B"} and self.width != 1:
            raise ValueError("Lookahead is only used by B and A+B")


@dataclass(frozen=True)
class CompilerOptions:
    router: str = "sabre"
    swap_trials: int = 1
    layout_trials: int = 1
    sabre_iterations: int = 3
    post_opt: str = "none"
    operator_max_qubits: int = 6

    def __post_init__(self):
        if self.router not in ROUTERS or self.post_opt not in POST_OPT:
            raise ValueError("Unknown router or optimization mode")
        if min(self.swap_trials, self.layout_trials, self.sabre_iterations) < 1:
            raise ValueError("SABRE trial and iteration counts must be positive")
        if not 0 <= self.operator_max_qubits <= 9:
            raise ValueError("Operator width limit must be in [0, 9]")


@dataclass
class Compiled:
    initial: tuple
    final: tuple
    routed: QuantumCircuit
    translated: QuantumCircuit
    output: QuantumCircuit
    times: dict
    lookahead_evals: int = 0
    mapping_cost: float | None = None


def elapsed_ms(start):
    return (perf_counter_ns() - start) / 1_000_000


def load_unitary(path, *, trim_idle=False):
    with path.open("r", encoding="utf-8-sig") as handle:
        header = handle.read(16384)
    match = re.search(r"(?m)^\s*OPENQASM\s+([23])(?:\.\d+)?\s*;", header)
    if not match:
        raise ValueError(f"No supported OpenQASM header in {path.name}")
    if match.group(1) == "2":
        parsed = qasm2.load(
            path, include_path=(), custom_instructions=qasm2.LEGACY_CUSTOM_INSTRUCTIONS,
            custom_classical=qasm2.LEGACY_CUSTOM_CLASSICAL,
        )
    else:
        parsed = qasm3.load(str(path))
    if parsed.num_qubits == 0 or parsed.parameters:
        raise ValueError(f"{path.name} must use fixed parameters and have at least one qubit")

    qubits = parsed.qubits
    if trim_idle:
        active = {
            qubit for instruction in parsed.data if instruction.name != "barrier"
            for qubit in instruction.qubits
        }
        qubits = [qubit for qubit in qubits if qubit in active] or qubits[:1]
    original = QuantumCircuit(len(qubits), global_phase=parsed.global_phase)
    if trim_idle:
        original.metadata = {"declared_qubits": parsed.num_qubits}
    bit_indices = {bit: i for i, bit in enumerate(qubits)}
    for instruction in parsed.data:
        operation = instruction.operation
        if operation.name == "barrier":
            continue
        if not isinstance(operation, Gate) or instruction.clbits:
            raise ValueError(f"{path.name} has unsupported non-unitary instruction {operation.name}")
        original.append(operation, [bit_indices[q] for q in instruction.qubits])
    return original


def normalize(original):
    logical = transpile(
        original, basis_gates=list(BASIS), optimization_level=0, seed_transpiler=0
    )
    if set(logical.count_ops()) - set(BASIS):
        raise ValueError("Normalization failed to reduce the circuit to the common basis")
    if any(not math.isfinite(float(x)) for instruction in logical.data for x in instruction.params):
        raise ValueError("Circuit contains a nonfinite gate parameter")
    return logical


def cx_layers(logical):
    """Layer the CX-only dependency graph, matching the Alpha input study."""
    bit_indices = {bit: i for i, bit in enumerate(logical.qubits)}
    next_layer = [0] * logical.num_qubits
    triples = []
    for instruction in logical.data:
        if instruction.name == "cx":
            a, b = (bit_indices[q] for q in instruction.qubits)
            layer = max(next_layer[a], next_layer[b])
            triples.append((a, b, layer))
            next_layer[a] = next_layer[b] = layer + 1
    return triples, max(next_layer, default=0) - 1


def interaction_weights(logical, alpha=1.0):
    if not 0 <= alpha <= 1:
        raise ValueError("Temporal alpha must be in [0, 1]")
    n = logical.num_qubits
    weights = [[0] * n for _ in range(n)]
    if alpha != 1:
        triples, max_layer = cx_layers(logical)
        span = max(1, max_layer)
        # Layer zero has unit weight, including at alpha=0. With alpha=0,
        # all subsequent layers have zero weight.
        factors = [WEIGHT_SCALE]
        factors.extend(int(WEIGHT_SCALE * alpha ** (layer / span) + 0.5)
                       for layer in range(1, max_layer + 1))
        for control, target, layer in triples:
            increment = factors[layer]
            weights[control][target] += increment
            weights[target][control] += increment
        return weights

    bit_indices = {bit: i for i, bit in enumerate(logical.qubits)}
    for instruction in logical.data:
        if instruction.name == "cx":
            control, target = (bit_indices[q] for q in instruction.qubits)
            weights[control][target] += 1
            weights[target][control] += 1
    return weights


def _fixed_route(logical, hardware, coupling, layout, seed, options):
    placed = QuantumCircuit(hardware.width)
    placed.compose(logical, qubits=list(layout), inplace=True)
    if hardware.width == 1:
        return placed, layout
    if options.router == "basic":
        routing = BasicSwap(coupling)
    else:
        routing = SabreSwap(coupling, heuristic="decay", seed=seed, trials=options.swap_trials)

    manager = PassManager(routing)
    routed = manager.run(placed)
    final_layout = manager.property_set.get("final_layout")
    final = layout if final_layout is None else tuple(final_layout[routed.qubits[p]] for p in layout)
    return routed, final


def _full_sabre(logical, hardware, coupling, seed, options):
    if hardware.width == 1:
        return logical.copy(), (0,), (0,)
    layout_pass = SabreLayout(
        coupling, seed=seed, max_iterations=options.sabre_iterations,
        swap_trials=options.swap_trials, layout_trials=options.layout_trials,
        skip_routing=False,
    )
    routed = PassManager(layout_pass).run(logical)
    if routed.layout is None:
        raise RuntimeError("SABRE did not return layout metadata")
    initial = tuple(routed.layout.initial_index_layout(filter_ancillas=True))
    final = tuple(routed.layout.final_index_layout(filter_ancillas=True))
    return routed, initial, final


def compile_circuit(logical, hardware, coupling, arm, seed, options):
    started = perf_counter_ns()
    n = logical.num_qubits
    if n > hardware.width:
        raise ValueError(f"{n} logical qubits exceed {hardware.name} capacity {hardware.width}")
    stages = dict(mapping_ms=None, route_ms=None, sabre_joint_ms=None)
    evaluations = 0
    mapping_cost = None

    if arm.method == "SABRE-FULL":
        routed, initial, final = _full_sabre(logical, hardware, coupling, seed, options)
        stages["sabre_joint_ms"] = elapsed_ms(started)
    else:
        if arm.method == "T":
            initial = tuple(range(n))
        else:
            problem = PlacementProblem(interaction_weights(logical, arm.alpha), hardware.distances)
            search = problem.lookahead(arm.width) if arm.width > 1 else problem.greedy()
            initial, evaluations = search.layout, search.evaluations
            mapping_cost = search.cost / WEIGHT_SCALE if arm.alpha != 1 else search.cost
        check_layout(initial, n, hardware.width)
        stages["mapping_ms"] = elapsed_ms(started)
        route_start = perf_counter_ns()
        routed, final = _fixed_route(logical, hardware, coupling, initial, seed, options)
        stages["route_ms"] = elapsed_ms(route_start)

    translation_start = perf_counter_ns()
    translator = BasisTranslator(SessionEquivalenceLibrary, list(BASIS))
    translated = PassManager(translator).run(routed)
    output = translated
    if options.post_opt == "cancel-cx":
        output = PassManager(InverseCancellation([CXGate()])).run(translated)
    stages["finish_ms"] = elapsed_ms(translation_start)
    stages["compile_ms"] = elapsed_ms(started)
    return Compiled(initial, final, routed, translated, output, stages, evaluations, mapping_cost)
