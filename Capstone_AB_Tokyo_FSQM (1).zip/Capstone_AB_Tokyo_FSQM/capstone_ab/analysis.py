"""Paired comparisons by circuit/topology, with circuit-cluster resampling."""

from collections import defaultdict
import csv
from itertools import product
import json
from statistics import geometric_mean, mean, median

import numpy as np

from .catalog import write_csv, write_json, write_text

METRICS = ("cx", "swap", "depth", "cx_depth", "uniform_cost", "mapping_ms", "route_ms",
           "compile_ms", "compile_plus_prepare_ms")
PRIMARY = ("G", "A", "B", "A+B")
PAIR_ORDER = (
    ("A", "G"), ("B", "G"), ("A+B", "G"),
    ("A+B", "A"), ("A+B", "B"), ("A", "B"),
    ("A", "SABRE-FULL"), ("B", "SABRE-FULL"), ("A+B", "SABRE-FULL"),
)
EPS = 1e-9


def read_raw(path):
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["seed"] = int(row["seed"])
        if row["status"] == "PASS":
            for key in METRICS:
                row[key] = float(row[key]) if row[key] != "" else None
            row["initial_layout"] = json.loads(row["initial_layout"])
    return rows


def case_means(study, rows):
    spec = study["spec"]
    cases = [(entry["topology"], entry["circuit"]) for entry in spec["cases"]]
    labels = [entry["label"] for entry in spec["arms"]]
    expected = set(product(cases, labels, spec["seeds"]))
    keys = {((r["topology"], r["circuit"]), r["arm"], r["seed"]) for r in rows}
    if keys != expected or len(rows) != len(expected) or any(r["status"] != "PASS" for r in rows):
        raise ValueError("Analysis requires exactly one PASS row per requested case, arm and seed")

    grouped = defaultdict(dict)
    for row in rows:
        grouped[row["topology"], row["circuit"], row["arm"]][row["seed"]] = row

    result = {}
    for topology, circuit in cases:
        for label in labels:
            values = grouped[topology, circuit, label]
            entry = {}
            for metric in METRICS:
                valid = [r[metric] for r in values.values() if r[metric] is not None]
                entry[metric] = mean(valid) if valid else None
            entry["layouts"] = tuple(tuple(values[seed]["initial_layout"]) for seed in spec["seeds"])
            result[topology, circuit, label] = entry
    return cases, labels, result


def delta_percent(value, reference):
    return 100 * (value - reference) / reference if reference > 0 else None


def paired_rows(cases, values, label, reference):
    rows = []
    for topology, circuit in cases:
        x = values[topology, circuit, label]
        base = values[topology, circuit, reference]
        row = dict(topology=topology, circuit=circuit, arm=label, reference=reference)
        for metric in ("cx", "swap", "depth", "cx_depth", "uniform_cost"):
            row[f"{metric}_arm"] = x[metric]
            row[f"{metric}_reference"] = base[metric]
            row[f"delta_{metric}"] = x[metric] - base[metric]
        for metric in ("cx", "depth"):
            row[f"delta_{metric}_pct"] = delta_percent(x[metric], base[metric])
        for metric in ("mapping_ms", "compile_ms", "compile_plus_prepare_ms"):
            row[f"{metric}_arm"] = x[metric]
            row[f"{metric}_reference"] = base[metric]
            row[f"{metric}_ratio"] = (
                x[metric] / base[metric] if x[metric] and base[metric] else None
            )
        row["layout_changed"] = any(a != b for a, b in zip(x["layouts"], base["layouts"]))
        row["layout_diff_seed_pct"] = 100 * mean(a != b for a, b in zip(x["layouts"], base["layouts"]))
        rows.append(row)
    return rows


def cluster_interval(rows, metric, seed):
    clusters = defaultdict(list)
    for row in rows:
        if row[metric] is not None:
            clusters[row["circuit"]].append(row[metric])
    if len(clusters) < 2:
        return None, None
    sums = np.array([sum(group) for group in clusters.values()])
    sizes = np.array([len(group) for group in clusters.values()])
    draws = np.random.default_rng(seed).integers(0, len(sums), size=(10_000, len(sums)))
    estimates = sums[draws].sum(axis=1) / sizes[draws].sum(axis=1)
    return tuple(map(float, np.quantile(estimates, [0.025, 0.975])))


def summary(rows, group, seed):
    changes = [row["delta_cx"] for row in rows]
    relative = [row["delta_cx_pct"] for row in rows if row["delta_cx_pct"] is not None]
    depth_relative = [row["delta_depth_pct"] for row in rows if row["delta_depth_pct"] is not None]
    lo, hi = cluster_interval(rows, "delta_cx_pct", seed)
    result = {
        "group": group, "arm": rows[0]["arm"], "reference": rows[0]["reference"],
        "cases": len(rows), "circuits": len({row["circuit"] for row in rows}),
        "cx_wins": sum(delta < -EPS for delta in changes),
        "cx_ties": sum(abs(delta) <= EPS for delta in changes),
        "cx_losses": sum(delta > EPS for delta in changes),
        "mean_delta_cx": mean(changes), "median_delta_cx": median(changes),
        "mean_delta_cx_pct": mean(relative) if relative else None,
        "cx_ci_low_pct": lo, "cx_ci_high_pct": hi, "cx_pct_cases": len(relative),
        "mean_delta_swap": mean(row["delta_swap"] for row in rows),
        "mean_delta_depth": mean(row["delta_depth"] for row in rows),
        "mean_delta_depth_pct": mean(depth_relative) if depth_relative else None,
        "mean_delta_cx_depth": mean(row["delta_cx_depth"] for row in rows),
        "layout_changed_cases": sum(row["layout_changed"] for row in rows),
        "lower_uniform_cost_higher_cx": sum(
            row["delta_uniform_cost"] < 0 and row["delta_cx"] > EPS for row in rows
        ),
    }
    for metric in ("mapping_ms", "compile_ms", "compile_plus_prepare_ms"):
        ratios = [row[f"{metric}_ratio"] for row in rows if row[f"{metric}_ratio"] is not None]
        result[f"{metric}_ratio"] = geometric_mean(ratios) if ratios else None
    return result


def choose_fit(study, rows, output):
    cases, labels, values = case_means(study, rows)
    spec = study["spec"]
    ranked = []
    for arm in spec["arms"]:
        if arm["label"] == "G":
            continue
        pairs = paired_rows(cases, values, arm["label"], "G")
        is_control = (arm["method"] == "A" and arm["alpha"] == 1 or
                      arm["method"] == "B" and arm["width"] <= 1)
        if is_control and any(
            pair["layout_changed"] or any(pair[f"delta_{metric}"] != 0
                                          for metric in ("cx", "swap", "depth", "cx_depth"))
            for pair in pairs
        ):
            raise ValueError(f"{arm['label']} did not reproduce G")
        comparison = summary(pairs, "all", spec["bootstrap_seed"])
        ranked.append({**comparison, "method": arm["method"], "alpha": arm["alpha"], "width": arm["width"]})
    if "G" not in labels or any(r["cx_pct_cases"] != len(cases) for r in ranked):
        raise ValueError("Fit requires a baseline and positive baseline CX for every fit case")

    # Retain the mildest decay / smallest lookahead on a quality tie.
    def rank(row):
        return (round(row["mean_delta_cx_pct"], 10),
                round(row["mean_delta_depth_pct"], 10), -row["alpha"], row["width"])

    ranked.sort(key=lambda row: (row["method"], rank(row)))
    picked_a = next(row for row in ranked if row["method"] == "A")
    picked_b = next(row for row in ranked if row["method"] == "B")
    selection = {
        "alpha": picked_a["alpha"], "width": picked_b["width"],
        "fit_run_id": study["run_id"], "compiler_options": spec["compiler_options"],
        "selection_rule": "Mean paired CX %, then depth %, then higher alpha / smaller width",
        "A_fit": picked_a, "B_fit": picked_b,
    }
    if "fsqm_config_sha256" in spec:
        selection.update(fit_suite=spec["suite"], fsqm_config_sha256=spec["fsqm_config_sha256"],
                         fit_case_count=len(cases), k=picked_b["width"])
    write_csv(output / "fit_ranking.csv", ranked)
    write_json(output / "selected.json", selection)
    return selection


def factorial_rows(cases, values):
    rows = []
    for topology, circuit in cases:
        g, a, b, ab = (values[topology, circuit, label]["cx"] for label in PRIMARY)
        interaction = ab - a - b + g
        rows.append({
            "topology": topology, "circuit": circuit, "cx_g": g, "cx_a": a, "cx_b": b, "cx_ab": ab,
            "interaction_cx": interaction, "interaction_pct": 100 * interaction / g if g else None,
        })
    return rows


def formatted(value, digits=2):
    return "—" if value is None else f"{value:.{digits}f}"


def write_report(study, rows, output):
    cases, labels, values = case_means(study, rows)
    spec = study["spec"]
    groups = sorted({topology for topology, _ in cases})
    paired, summaries = [], []
    for a, g in PAIR_ORDER:
        if a in labels and g in labels:
            comparison = paired_rows(cases, values, a, g)
            paired.extend(comparison)
            summaries.append(summary(comparison, "all", spec["bootstrap_seed"]))
            for topology in groups:
                section = [row for row in comparison if row["topology"] == topology]
                summaries.append(summary(section, topology, spec["bootstrap_seed"]))
    if not summaries and len(labels) > 1:
        reference = labels[0]
        for label in labels[1:]:
            comparison = paired_rows(cases, values, label, reference)
            paired.extend(comparison)
            summaries.append(summary(comparison, "all", spec["bootstrap_seed"]))
    write_csv(output / "paired_cases.csv", paired, list(paired[0]) if paired else ("arm", "reference"))
    write_csv(output / "summary.csv", summaries, list(summaries[0]) if summaries else ("group", "arm", "reference"))
    if set(PRIMARY) <= set(labels):
        factorial = factorial_rows(cases, values)
        write_csv(output / "factorial.csv", factorial)
        interaction_rows = [row["interaction_pct"] for row in factorial if row["interaction_pct"] is not None]
        low, high = cluster_interval(factorial, "interaction_pct", spec["bootstrap_seed"])
        write_json(output / "factorial.json", {
            "mean_interaction_cx": mean(row["interaction_cx"] for row in factorial),
            "mean_interaction_pct": mean(interaction_rows) if interaction_rows else None,
            "ci_low_pct": low, "ci_high_pct": high,
        })

    opts = spec["compiler_options"]
    status = read_verification(rows)
    table = [
        f"# {spec['suite']} | Router {opts['router']}",
        "",
        f"{len(cases)} ca mạch–topology, {len(spec['seeds'])} seed, "
        f"{len(rows)} dòng PASS, {status['operator']} kiểm tra toán tử và cấu trúc, "
        f"{status['structural']} kiểm tra cấu trúc.",
        "",
        "| Phương án | Mốc | ΔCX (%) | KTC 95% | ΔCX | Thắng/Hòa/Thua | ΔDepth (%) | T mapping | T biên dịch |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summaries:
        if row["group"] == "all":
            tally = f"{row['cx_wins']}/{row['cx_ties']}/{row['cx_losses']}"
            interval = f"[{formatted(row['cx_ci_low_pct'])}, {formatted(row['cx_ci_high_pct'])}]"
            table.append(
                f"| {row['arm']} | {row['reference']} | {formatted(row['mean_delta_cx_pct'])} | {interval} "
                f"| {formatted(row['mean_delta_cx'])} | {tally} | {formatted(row['mean_delta_depth_pct'])} "
                f"| {formatted(row['mapping_ms_ratio'])}× | {formatted(row['compile_ms_ratio'])}× |"
            )
    table.extend(["", "Trung bình theo seed trước, sau đó cho mỗi ca mạch–topology trọng số bằng nhau. "
                  "KTC bootstrap gom theo tên mạch. Tỷ lệ thời gian là trung bình nhân qua các ca. "
                  "Thời gian biên dịch tính từ mạch đã chuẩn hóa."])
    write_text(output / "report.md", "\n".join(table) + "\n")


def read_verification(rows):
    return {
        "operator": sum(r["verification"] == "OPERATOR+STRUCTURAL" for r in rows),
        "structural": sum(r["verification"] == "STRUCTURAL" for r in rows),
    }
