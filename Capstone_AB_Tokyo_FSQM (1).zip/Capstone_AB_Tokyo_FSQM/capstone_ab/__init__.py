"""Reproducible comparison for initial mapping improvements A and B."""
