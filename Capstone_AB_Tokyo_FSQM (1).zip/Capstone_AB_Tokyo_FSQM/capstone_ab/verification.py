"""Audit routing permutations, native translation and the unitary on small chips."""

from hashlib import sha256
from math import isclose, remainder, tau
from struct import pack

from qiskit import QuantumCircuit
from qiskit.quantum_info import Operator

from .compiler import BASIS
from .mapping import check_layout

GATE_CODES = {name: index for index, name in enumerate(BASIS)}


def gate_signature(instruction, bit_indices):
    return (
        instruction.name,
        tuple(bit_indices[qubit] for qubit in instruction.qubits),
        tuple(float(param) for param in instruction.params),
    )


class WireTrace:
    """Incremental ordered SHA-256 per wire, including partner and CX direction."""

    def __init__(self, width):
        self.digests = [sha256() for _ in range(width)]

    def add(self, name, positions, params=()):
        encoded = pack("<BBB", GATE_CODES[name], len(positions), len(params))
        encoded += pack("<" + "I" * len(positions), *positions)
        encoded += pack("<" + "d" * len(params), *(x or 0.0 for x in params))
        for position in positions:
            self.digests[position].update(encoded)

    def signature(self):
        return tuple(digest.digest() for digest in self.digests)


def native_trace(circuit, edges=None, cancel_cx=False):
    bit_indices = {qubit: i for i, qubit in enumerate(circuit.qubits)}
    trace = WireTrace(circuit.num_qubits)
    stacks = [[] for _ in circuit.qubits] if cancel_cx else None
    for instruction in circuit.data:
        name, positions, params = gate_signature(instruction, bit_indices)
        if name not in BASIS:
            raise ValueError(f"Unexpected native gate {name}")
        if name == "cx" and edges is not None and tuple(sorted(positions)) not in edges:
            raise ValueError(f"Native CX outside the coupling graph: {positions}")
        if stacks is None:
            trace.add(name, positions, params)
            continue

        signature = (name, positions, params)
        addressed = [stacks[p] for p in positions]
        if name == "cx" and all(stack and stack[-1] == signature for stack in addressed):
            for stack in addressed:
                stack.pop()
        else:
            for stack in addressed:
                stack.append(signature)
    if stacks is None:
        return trace.signature()
    return tuple(tuple(stack) for stack in stacks)


def _same_phase(a, b):
    return isclose(remainder(float(a) - float(b), tau), 0.0, abs_tol=1e-10)


class Verifier:
    def __init__(self, logical, hardware, operator_limit):
        self.logical = logical
        self.hardware = hardware
        self.operator_limit = operator_limit
        self.input_signature = native_trace(logical)
        self.input_cx = logical.count_ops().get("cx", 0)
        self.edges = frozenset(hardware.edges)

    def check(self, compiled):
        n, m = self.logical.num_qubits, self.hardware.width
        check_layout(compiled.initial, n, m)
        check_layout(compiled.final, n, m)
        if any(qc.num_qubits != m or qc.num_clbits for qc in
               (compiled.routed, compiled.translated, compiled.output)):
            raise ValueError("Unexpected physical circuit size")
        if any(not _same_phase(self.logical.global_phase, qc.global_phase)
               for qc in (compiled.routed, compiled.translated, compiled.output)):
            raise ValueError("Global phase changed in the compilation pipeline")

        positions = [-1] * m
        for logical, physical in enumerate(compiled.initial):
            positions[physical] = logical
        spare_labels = iter(range(n, m))
        positions = [next(spare_labels) if label == -1 else label for label in positions]

        logical_trace = WireTrace(n)
        expected_native = WireTrace(m)
        swaps = []
        bit_indices = {qubit: i for i, qubit in enumerate(compiled.routed.qubits)}
        for instruction in compiled.routed.data:
            name, physical_args, params = gate_signature(instruction, bit_indices)
            if name in {"cx", "swap"} and tuple(sorted(physical_args)) not in self.edges:
                raise ValueError(f"Router produced {name} on a non-edge: {physical_args}")
            if name == "swap":
                a, b = physical_args
                positions[a], positions[b] = positions[b], positions[a]
                swaps.append((a, b))
                expected_native.add("cx", (a, b))
                expected_native.add("cx", (b, a))
                expected_native.add("cx", (a, b))
                continue
            if name not in BASIS:
                raise ValueError(f"Unexpected routed instruction {name}")
            args = tuple(positions[p] for p in physical_args)
            if any(q >= n for q in args):
                raise ValueError("Router used a spare logical wire as a data operand")
            logical_trace.add(name, args, params)
            expected_native.add(name, physical_args, params)

        if logical_trace.signature() != self.input_signature:
            raise ValueError("Router changed the order or content of gates on a logical wire")
        audited_final = tuple(positions.index(q) for q in range(n))
        if audited_final != compiled.final:
            raise ValueError(f"Audited permutation {audited_final} differs from Qiskit {compiled.final}")

        if expected_native.signature() != native_trace(compiled.translated, self.edges):
            raise ValueError("Native translation differs from the audited 3-CX expansion")
        native_cx = compiled.translated.count_ops().get("cx", 0)
        if native_cx != self.input_cx + 3 * len(swaps):
            raise ValueError("Unexpected pre-optimization CX count")
        output_cx = compiled.output.count_ops().get("cx", 0)
        if compiled.output is not compiled.translated:
            before = native_trace(compiled.translated, self.edges, cancel_cx=True)
            after = native_trace(compiled.output, self.edges, cancel_cx=True)
            if before != after or output_cx > native_cx:
                raise ValueError("CX cancellation changed the reduced physical wire traces")

        verification = "STRUCTURAL"
        if m <= self.operator_limit:
            expected = QuantumCircuit(m)
            expected.compose(self.logical, qubits=list(compiled.initial), inplace=True)
            for a, b in swaps:
                expected.swap(a, b)
            if not Operator(expected).equiv(Operator(compiled.output)):
                raise ValueError("Operator equivalence under the routed final permutation failed")
            verification = "OPERATOR+STRUCTURAL"

        return {
            "verification": verification,
            "input_cx": self.input_cx,
            "swap": len(swaps),
            "cx_before_post_opt": native_cx,
            "cx": output_cx,
            "added_cx": output_cx - self.input_cx,
            "depth": compiled.output.depth(),
            "cx_depth": compiled.output.depth(lambda inst: inst.name == "cx"),
        }
