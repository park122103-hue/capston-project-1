"""Reproducible input catalog and atomic output helpers."""

import csv
import hashlib
import json
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from .mapping import distances_from_edges

ROOT = Path(__file__).resolve().parents[1]
FSQM_TOPOLOGY = "tokyo20_fsqm"
FSQM_FIT = "fsqm_fit"
FSQM_SUITES = (FSQM_FIT, "fsqm_holdout", "fsqm_stress")
SUITES = ("smoke", "fit", "holdout", "extended", "stress", *FSQM_SUITES)
FSQM_CONFIG = ROOT / "config/fsqm_study.json"
SAFE_NAME = re.compile(r"[A-Za-z0-9_-]+")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _atomic_write(path, write):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="", dir=path.parent, delete=False
    ) as handle:
        temporary = Path(handle.name)
        try:
            write(handle)
            handle.flush()
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)


def write_json(path, data):
    _atomic_write(path, lambda f: json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False))


def write_text(path, value):
    _atomic_write(path, lambda f: f.write(value))


def write_csv(path, rows, fields=None):
    if fields is None:
        fields = list(dict.fromkeys(key for row in rows for key in row))

    def write(handle):
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    _atomic_write(path, write)


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fingerprint(value):
    serialized = json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False)
    return hashlib.sha256(serialized.encode("ascii")).hexdigest()


@dataclass(frozen=True)
class Hardware:
    name: str
    width: int
    edges: tuple
    source: str
    distances: tuple = field(init=False, repr=False)

    def __post_init__(self):
        if not SAFE_NAME.fullmatch(self.name):
            raise ValueError(f"Invalid topology name {self.name!r}")
        if type(self.width) is not int or self.width < 1:
            raise ValueError(f"Invalid width for {self.name}")
        if len(self.edges) != len(set(self.edges)):
            raise ValueError(f"Duplicate edges in {self.name}")
        object.__setattr__(self, "distances", distances_from_edges(self.width, self.edges))

    def coupling_map(self):
        from qiskit.transpiler import CouplingMap

        coupling = CouplingMap()
        for physical in range(self.width):
            coupling.add_physical_qubit(physical)
        for a, b in self.edges:
            coupling.add_edge(a, b)
            coupling.add_edge(b, a)
        return coupling


@dataclass(frozen=True)
class Case:
    topology: str
    circuit: str

    def __post_init__(self):
        if not all(SAFE_NAME.fullmatch(name) for name in (self.topology, self.circuit)):
            raise ValueError(f"Invalid topology/circuit identifier: {self}")

    @property
    def label(self):
        return f"{self.topology}/{self.circuit}"

    @property
    def path(self):
        directory = ROOT / "benchmarks"
        if self.topology == FSQM_TOPOLOGY:
            directory /= "fsqm"
        for suffix in (".qasm", ".qasm3"):
            path = directory / f"{self.circuit}{suffix}"
            if path.is_file():
                return path
        raise ValueError(f"Cannot find QASM for {self.label} under {directory}")


def hardware_catalog():
    catalog = read_json(ROOT / "config/topologies.json")
    catalog[FSQM_TOPOLOGY] = read_json(FSQM_CONFIG)["hardware"]
    return {
        name: Hardware(
            name,
            record["width"],
            tuple(tuple(sorted(edge)) for edge in record["edges"]),
            record.get("source", ""),
        )
        for name, record in catalog.items()
    }


def case_catalog():
    config = read_json(ROOT / "config/cases.json")
    fsqm = read_json(FSQM_CONFIG)["suites"]
    config.update({suite: {FSQM_TOPOLOGY: circuits} for suite, circuits in fsqm.items()})
    catalog = {
        suite: [Case(topology, circuit) for topology, circuits in groups.items() for circuit in circuits]
        for suite, groups in config.items()
    }
    topologies = hardware_catalog()
    for suite in SUITES:
        cases = catalog[suite]
        if not cases or len(set(cases)) != len(cases):
            raise ValueError(f"Empty suite or duplicate cases in {suite}")
        for case in cases:
            if case.topology not in topologies:
                raise ValueError(f"Unknown topology in {case.label}")
            _ = case.path
    fit = {case.circuit: file_hash(case.path) for case in catalog["fit"]}
    holdout = {case.circuit: file_hash(case.path) for case in catalog["holdout"]}
    if fit.keys() & holdout.keys() or set(fit.values()) & set(holdout.values()):
        raise ValueError("The fit and holdout suites share circuit names or identical QASM")
    fsqm_cases = [case for suite in FSQM_SUITES for case in catalog[suite]]
    if len(set(fsqm_cases)) != len(fsqm_cases):
        raise ValueError("The FSQM suites share circuit names")
    return catalog


def select_cases(suite, topology=None, circuit=None):
    cases = [
        case for case in case_catalog()[suite]
        if (topology is None or case.topology == topology)
        and (circuit is None or case.circuit == circuit)
    ]
    if not cases:
        raise ValueError("The topology and circuit filters leave no configured cases")
    return cases
