"""Suite orchestration, seeded timing, and resumable per-case checkpoints."""

from collections import Counter
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime, timezone
import fcntl
from importlib import metadata
from random import Random
from statistics import median
from time import perf_counter_ns
import os
import platform
import subprocess
import sys

from qiskit.quantum_info import Operator

from .catalog import (
    ROOT, FSQM_CONFIG, FSQM_FIT, FSQM_SUITES, FSQM_TOPOLOGY, Case, Hardware, file_hash,
    fingerprint, hardware_catalog, read_json, write_csv, write_json,
)
from .compiler import (
    BASIS, Arm, CompilerOptions, compile_circuit, elapsed_ms, interaction_weights,
    load_unitary, normalize,
)
from .mapping import PlacementProblem
from .verification import Verifier

TIME_FIELDS = ("mapping_ms", "route_ms", "sabre_joint_ms", "finish_ms", "compile_ms")
ROW_FIELDS = (
    "suite", "topology", "circuit", "seed", "arm", "method", "alpha", "width", "router",
    "post_opt", "status", "reason", "declared_qubits", "logical_qubits", "physical_qubits", "input_cx",
    "verification", "initial_layout", "final_layout", "uniform_cost", "mapping_cost", "swap",
    "cx_before_post_opt", "cx", "added_cx", "depth", "cx_depth",
    "lookahead_evals",
    "prepare_ms", *TIME_FIELDS, "compile_plus_prepare_ms", "repeats",
)
TIMING_FIELDS = ("suite", "topology", "circuit", "seed", "arm", "method", "repeat", *TIME_FIELDS)


def search_space(suite=None):
    legacy = read_json(ROOT / "config/search_space.json")
    if suite == FSQM_FIT:
        legacy.update(read_json(FSQM_CONFIG)["defaults"])
    return legacy


def arm_grid(space):
    return (
        [Arm("G", "G")]
        + [Arm(f"A@{alpha}", "A", alpha=alpha) for alpha in space["alpha"]]
        + [Arm(f"B@{width}", "B", width=width) for width in space["width"]]
    )


def evaluation_arms(methods, space, params_path):
    defaults = space["defaults"]
    if params_path is None:
        alpha, width = defaults["alpha"], defaults["width"]
        source = {"kind": "preset", **defaults}
    else:
        selected = read_json(params_path)
        alpha, width = selected["alpha"], selected["width"]
        source = {
            "kind": "fit", "sha256": file_hash(params_path), "alpha": alpha, "width": width,
            "fit_run_id": selected["fit_run_id"], "compiler_options": selected["compiler_options"],
        }
        if "fsqm_config_sha256" in selected:
            source.update(fsqm_config_sha256=selected["fsqm_config_sha256"],
                          fit_suite=selected["fit_suite"], fit_case_count=selected["fit_case_count"])
    return [
        Arm(method, method, alpha if method in {"A", "A+B"} else 1.0,
            width if method in {"B", "A+B"} else 1)
        for method in methods
    ], source


def _environment():
    thread_names = ("RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
    return {
        "python": platform.python_version(), "platform": platform.platform(),
        "machine": platform.machine(), "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "packages": {
            name: metadata.version(name) for name in
            ("qiskit", "numpy", "scipy", "rustworkx", "qiskit-qasm3-import")
        },
        "thread_environment": {name: os.environ.get(name) for name in thread_names},
    }


def make_spec(args, cases):
    space = search_space(args.suite)
    protocol = read_json(ROOT / "config/protocol.json")
    fsqm = read_json(FSQM_CONFIG) if args.suite in FSQM_SUITES else None
    fsqm_sha = file_hash(FSQM_CONFIG) if fsqm else None
    if fsqm:
        protocol.update(fsqm["protocol"])
    defaults = protocol[args.suite]
    seeds = defaults["seeds"] if args.seeds is None else args.seeds
    repeats = defaults["repeats"] if args.repeats is None else args.repeats
    warmups = defaults["warmups"] if args.warmups is None else args.warmups
    timeout = defaults["case_timeout_s"] if args.timeout is None else args.timeout

    options = CompilerOptions(
        args.router, args.swap_trials, args.layout_trials, args.sabre_iterations,
        args.post_opt, args.operator_max_qubits,
    )
    if args.command == "fit":
        if args.alpha_grid is not None:
            space["alpha"] = args.alpha_grid
        if args.k_grid is not None:
            space["width"] = args.k_grid
        arms = arm_grid(space)
        source = {"kind": "grid", "alpha_grid": space["alpha"], "k_grid": space["width"]}
    else:
        arms, source = evaluation_arms(args.methods, space, args.params)
        if fsqm and (
            source.get("fit_suite") != FSQM_FIT or source.get("fsqm_config_sha256") != fsqm_sha
        ):
            raise ValueError("FSQM comparisons require selected.json from fit --suite fsqm_fit")
        if fsqm and source["compiler_options"] != asdict(options):
            raise ValueError("Use the same compiler options as the Tokyo fit")
    hardware = hardware_catalog()
    case_records = [{**asdict(case), "sha256": file_hash(case.path)} for case in cases]
    if fsqm:
        for case, record in zip(cases, case_records):
            path = case.path.relative_to(ROOT).as_posix()
            if record["sha256"] != fsqm["files"].get(path):
                raise ValueError(f"FSQM benchmark does not match its archived input: {path}")
    return {
        "schema": 1,
        "suite": args.suite,
        "phase": args.command,
        "cases": case_records,
        "topologies": {
            name: {"width": hardware[name].width, "edges": [list(edge) for edge in hardware[name].edges],
                   "source": hardware[name].source}
            for name in sorted({case.topology for case in cases})
        },
        "arms": [asdict(arm) for arm in arms],
        "basis": list(BASIS),
        "compiler_options": asdict(options),
        "seeds": seeds,
        "warmups": warmups,
        "repeats": repeats,
        "case_timeout_s": timeout,
        "bootstrap_seed": protocol["bootstrap_seed"],
        "param_source": source,
        **({"fsqm_config_sha256": fsqm_sha} if fsqm else {}),
        "full_suite": args.topology is None and args.circuit is None,
        "protocol_seeds": seeds == defaults["seeds"],
        "protocol_timing": warmups == defaults["warmups"] and repeats == defaults["repeats"],
        "environment": _environment(),
        "code_sha256": fingerprint({
            file.name: file_hash(file) for file in sorted((ROOT / "capstone_ab").glob("*.py"))
        }),
    }


@contextmanager
def lock_output(output):
    output.mkdir(parents=True, exist_ok=True)
    with (output / ".run.lock").open("a", encoding="utf-8") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError(f"An experiment is already using {output}") from None
        yield


def _arm_from_json(record):
    return Arm(**record)


def _context(spec, case, seed, arm):
    return {
        "suite": spec["suite"],
        "topology": case.topology,
        "circuit": case.circuit,
        "seed": seed,
        "arm": arm.label,
        "method": arm.method,
        "alpha": arm.alpha,
        "width": arm.width,
        "router": "sabre-joint" if arm.method == "SABRE-FULL" else spec["compiler_options"]["router"],
        "post_opt": spec["compiler_options"]["post_opt"],
    }


def _quality_signature(compiled):
    return (
        compiled.initial, compiled.final,
        compiled.routed.count_ops().get("swap", 0),
        compiled.translated.count_ops().get("cx", 0),
        compiled.output.count_ops().get("cx", 0),
        compiled.output.depth(),
        compiled.output.depth(lambda inst: inst.name == "cx"),
    )


def _repeat_arm(logical, hardware, coupling, arm, context, spec, verifier, problem):
    seed = context["seed"]
    options = CompilerOptions(**spec["compiler_options"])
    for _ in range(spec["warmups"]):
        compile_circuit(logical, hardware, coupling, arm, seed, options)

    samples = []
    first = None
    for repeat in range(1, spec["repeats"] + 1):
        compiled = compile_circuit(logical, hardware, coupling, arm, seed, options)
        signature = _quality_signature(compiled)
        if first is None:
            quality = verifier.check(compiled)
            first = signature
            initial = compiled.initial
            final = compiled.final
            lookahead_evals = compiled.lookahead_evals
            mapping_cost = compiled.mapping_cost
        elif signature != first:
            raise ValueError("Layout or circuit metrics changed across repeats with the same seed")
        samples.append({"repeat": repeat, **compiled.times})
        del compiled

    times = {
        key: median(sample[key] for sample in samples) if samples[0][key] is not None else None
        for key in TIME_FIELDS
    }
    row = {
        **context, "status": "PASS",
        "logical_qubits": logical.num_qubits, "physical_qubits": hardware.width,
        **quality,
        "initial_layout": list(initial), "final_layout": list(final),
        "uniform_cost": problem.cost(initial),
        "mapping_cost": mapping_cost,
        "lookahead_evals": lookahead_evals,
        **times, "repeats": len(samples),
    }
    timings = [
        {**{key: context[key] for key in TIMING_FIELDS[:6]}, **sample} for sample in samples
    ]
    return row, timings


def run_case(spec_path, case_index, destination):
    study = read_json(spec_path)
    spec = study["spec"]
    case_with_hash = spec["cases"][case_index]
    case = Case(case_with_hash["topology"], case_with_hash["circuit"])
    if file_hash(case.path) != case_with_hash["sha256"]:
        raise ValueError(f"Circuit changed after the run started: {case.label}")
    # Use the graph frozen into the experiment manifest.
    graph = spec["topologies"][case.topology]
    hardware = Hardware(case.topology, graph["width"], tuple(map(tuple, graph["edges"])), graph["source"])
    coupling = hardware.coupling_map()
    options = CompilerOptions(**spec["compiler_options"])

    started = perf_counter_ns()
    original = load_unitary(case.path, trim_idle=case.topology == FSQM_TOPOLOGY)
    declared_qubits = original.metadata.get("declared_qubits", original.num_qubits)
    logical = normalize(original)
    prepare_ms = elapsed_ms(started)
    if logical.num_qubits > hardware.width:
        raise ValueError(f"{case.label} does not fit: {logical.num_qubits} > {hardware.width}")
    if logical.num_qubits <= options.operator_max_qubits:
        if not Operator(original).equiv(Operator(logical)):
            raise ValueError("Basis normalization changed the input unitary")
    del original

    problem = PlacementProblem(interaction_weights(logical), hardware.distances)
    verifier = Verifier(logical, hardware, options.operator_max_qubits)
    if sum(weight for _, _, weight in problem.pairs) != verifier.input_cx:
        raise ValueError("sum(W[i,j] for i < j) is inconsistent with input CX")

    rows, timings = [], []
    arms = [_arm_from_json(record) for record in spec["arms"]]
    for seed in spec["seeds"]:
        order = arms.copy()
        Random(f"arm-order/{case.label}/{seed}").shuffle(order)
        for arm in order:
            context = _context(spec, case, seed, arm)
            try:
                row, samples = _repeat_arm(logical, hardware, coupling, arm, context, spec, verifier, problem)
                rows.append({**row, "declared_qubits": declared_qubits, "prepare_ms": prepare_ms,
                             "compile_plus_prepare_ms": prepare_ms + row["compile_ms"]})
                timings.extend(samples)
            except Exception as exc:
                rows.append({**context, "status": "FAIL", "reason": f"{type(exc).__name__}: {exc}"})
    write_json(destination, {"run_id": study["run_id"], "rows": rows, "timings": timings})


def _whole_case_failure(study, case, reason, status):
    spec = study["spec"]
    return {
        "run_id": study["run_id"],
        "rows": [
            {**_context(spec, case, seed, _arm_from_json(record)), "status": status, "reason": reason}
            for seed in spec["seeds"] for record in spec["arms"]
        ],
        "timings": [],
    }


def run_study(output, spec, resume=False):
    manifest = output / "study.json"
    run_id = fingerprint(spec)
    if manifest.exists():
        if not resume:
            raise ValueError(f"Output already used: {output}. Use --resume or choose another --out")
        study = read_json(manifest)
        if study["run_id"] != run_id:
            raise ValueError("Resume settings, code, data or environment differ from study.json")
    else:
        if any(path.name != ".run.lock" for path in output.iterdir()):
            raise ValueError(f"Use an empty experiment output directory: {output}")
        study = {"run_id": run_id, "created_utc": datetime.now(timezone.utc).isoformat(), "spec": spec}
        write_json(manifest, study)

    checkpoint_dir = output / "checkpoints"
    checkpoint_dir.mkdir(exist_ok=True)
    rows, timings = [], []
    for index, record in enumerate(spec["cases"]):
        case = Case(record["topology"], record["circuit"])
        checkpoint = checkpoint_dir / f"{index:03d}.json"
        old = read_json(checkpoint) if checkpoint.is_file() else None
        complete = bool(old and old["run_id"] == run_id and all(row["status"] == "PASS" for row in old["rows"]))
        if complete:
            data = old
            marker = "cached"
        else:
            marker = "measured"
            args = [
                sys.executable, "-m", "capstone_ab", "_case", str(manifest),
                str(index), str(checkpoint),
            ]
            try:
                worker = subprocess.run(
                    args, cwd=ROOT, text=True, capture_output=True, timeout=spec["case_timeout_s"] or None
                )
                if worker.returncode:
                    reason = (worker.stderr or worker.stdout).strip()[-1200:] or f"worker exited {worker.returncode}"
                    data = _whole_case_failure(study, case, reason, "FAIL")
                    write_json(checkpoint, data)
                else:
                    data = read_json(checkpoint)
            except subprocess.TimeoutExpired:
                data = _whole_case_failure(
                    study, case, f"Case exceeded {spec['case_timeout_s']} s", "TIMEOUT",
                )
                write_json(checkpoint, data)

        rows.extend(data["rows"])
        timings.extend(data["timings"])
        statuses = Counter(row["status"] for row in data["rows"])
        print(f"[{index + 1}/{len(spec['cases'])}] {case.label}  {dict(statuses)} ({marker})", flush=True)

    arm_order = {arm["label"]: i for i, arm in enumerate(spec["arms"])}
    seed_order = {seed: i for i, seed in enumerate(spec["seeds"])}
    cases = {(item["topology"], item["circuit"]): i for i, item in enumerate(spec["cases"])}

    def order(row):
        return (cases[row["topology"], row["circuit"]], seed_order[row["seed"]],
                arm_order[row["arm"]], row.get("repeat", 0))

    write_csv(output / "raw.csv", sorted(rows, key=order), ROW_FIELDS)
    write_csv(output / "timings.csv", sorted(timings, key=order), TIMING_FIELDS)
    statuses = dict(Counter(row["status"] for row in rows))
    write_json(output / "status.json", {
        "run_id": run_id, "expected_rows": len(spec["cases"]) * len(spec["seeds"]) * len(spec["arms"]),
        "statuses": statuses,
        "verification": dict(Counter(row["verification"] for row in rows if row["status"] == "PASS")),
    })
    return study, rows
