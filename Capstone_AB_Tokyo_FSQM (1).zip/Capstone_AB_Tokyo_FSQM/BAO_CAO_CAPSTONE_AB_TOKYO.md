# Đánh giá cải tiến A và B cho Initial Qubit Mapping trên Tokyo

## 1. Tái hiện giữa kỳ

Mạch đại diện có 4 qubit logic và 14 CX đầu vào. Các phép đo dùng Line5, Basic Routing, mức tối ưu hóa 0 và seed biên dịch 42.

| Phương án | Initial layout | Chi phí tĩnh | CX sau routing | Depth |
|---|---|---:|---:|---:|
| Trivial | `[0, 1, 2, 3]` | 20 | 23 | 90 |
| Random đại diện | `[0, 2, 3, 4]` | 31 | 26 | 93 |
| G giữa kỳ | `[2, 1, 3, 0]` | 15 | 20 | 77 |
| Random (20 layout) | Mẫu với seed 2026 | — | 30,50 ± 5,96 | 87,75 ± 4,06 |

- Vét cạn 120 layout cho chi phí tĩnh nhỏ nhất bằng 15, có 4 layout đạt giá trị này. G cũng đạt CX nhỏ nhất là 20 và depth nhỏ nhất là 77 trong phép vét cạn.
- Trên 20 layout Random, tương quan Pearson giữa chi phí tĩnh và số CX sau routing là 0,5384. Tương quan này giúp giải thích vì sao cần chọn tham số bằng kết quả sau routing.
- Ba layout đại diện đạt 48/48 kiểm tra đầu vào cơ sở. Phần benchmark trong bản lưu giữa kỳ khớp 352/352 bản ghi biên dịch trên tám mạch và hai topology, Line5 và Grid6, và cả 352 mạch sau biên dịch đều qua kiểm tra tương đương. Các CSV và số đo sai số mới nằm trong `results/midterm_archive/`.

## 2. Thiết kế thí nghiệm Tokyo

Dùng đồ thị IBM Q 20 có 20 qubit và 43 cạnh hai chiều từ `src/couplinggraph.cpp` của FSQM. Đồ thị này có thêm tám cạnh so với `tokyo20` 35 cạnh của dự án cũ. Bộ mới lấy đủ 28 QASM trong danh sách chính của FSQM, gồm QFT, Ising và nhiều mạch logic thuận nghịch. Mạch có từ 4 đến 20 qubit logic hoạt động. Các dây khai báo trong QASM và vắng mặt trong mọi cổng được lược bỏ trước khi bố trí. [Park và cộng sự, DAC 2022](https://doi.org/10.1145/3489517.3530402)

| Tập mạch | Số mạch | Seed | Mục đích |
|---|---:|---|---|
| Fit | 9 | 42, 0, 1 | Quét từng tham số và đo lại G/A/B/A+B |
| Holdout | 16 | 100, 101, 102 | So sánh các phương án sau khi chốt tham số |
| Stress | 3 | 42 | Kiểm tra trên `urf5_158`, `hwb9_119` và `urf4_187` |

G đếm số CX theo cặp qubit và dùng Greedy giữa kỳ. A giữ Greedy, gán trọng số `α^(ℓ / max(1, ℓ_max))` cho CX ở lớp phụ thuộc `ℓ`. Ở biên α = 0, lớp 0 giữ trọng số 1 và các lớp sau có trọng số 0. B giữ cách đếm CX của G và xét tối đa K vị trí cho qubit đang đặt, mỗi vị trí được chấm thêm chi phí tốt nhất để đặt qubit kế tiếp. K = 0 tắt lookahead. K = 1 cũng tái tạo G trong B. A+B lắp hai thành phần với tham số tốt nhất đo riêng cho từng thành phần.

Mọi phương án Tokyo dùng cùng basis `rz, sx, x, cx`, SABRE Routing với một trial, layout đầu vào cố định theo phương án và cùng seed cho từng mạch. Mỗi SWAP được phân rã thành 3 CX, nên số CX thêm bằng 3 lần số SWAP. 891 dòng quét và 312 dòng so sánh đều qua kiểm tra cấu trúc, gồm thứ tự cổng trên từng dây logic, cạnh vật lý, phân rã SWAP và hoán vị cuối.

## 3. Kết quả quét tham số

Xếp hạng theo trung bình ΔCX tương đối so với G trên các mạch fit, rồi theo ΔDepth. Khi hòa ở cả hai, chọn α cao hơn hoặc K nhỏ hơn. Phạm vi có thể chỉnh từ dòng lệnh.

| Phương án | Khoảng quét | Chọn | ΔCX so với G | ΔDepth so với G |
|---|---|---:|---:|---:|
| A | 0,0 đến 1,0, bước 0,1 | α = 0,6 | −3,99% | −2,10% |
| B | 0 đến 20, bước 1 | K = 4 | −4,18% | −6,69% |
| A+B | Dùng hai giá trị đã chốt | (0,6, 4) | −3,83% | −2,17% |

α = 0,5 cho ΔCX −3,78%, cách α = 0,6 khoảng 0,20 điểm phần trăm. α = 0 cho ΔCX **+4,73%**. Trong B, K từ 4 đến 20 tạo cùng layout trên cả chín mạch fit. K = 4 là điểm đầu của vùng đồng hạng. K = 0 và K = 1 tái hiện layout và chất lượng của G, cũng như α = 1 trong A.

Ở cùng thiết lập Tokyo mới, α = 0,8 và K = 2 lần lượt đạt −3,33% và −3,97% khi đo riêng A và B. Bản cũ từng chọn (0,8, 2) với tập fit, lưới và đồ thị khác. Hàng A+B dùng đúng (0,6, 4) để đo hiệu quả phối hợp của các tham số đã chốt.

## 4. Đối chiếu chính trên 16 mạch holdout

Mỗi mạch được tính trung bình qua ba seed trước khi tổng hợp. Mỗi mạch có trọng số bằng nhau. Δ âm nghĩa là giảm so với mốc. W/T/L đếm số mạch thắng, hòa và thua theo CX trung bình.

| So sánh | ΔCX | ΔCX tương đối | ΔSWAP | ΔDepth tương đối | W/T/L theo CX |
|---|---:|---:|---:|---:|---:|
| A với G | −28,12 | +0,55% | −9,38 | +0,88% | 5/8/3 |
| B với G | −30,56 | −3,08% | −10,19 | −0,24% | 6/7/3 |
| A+B với G | **−91,50** | **−3,26%** | **−30,50** | **−0,86%** | **8/5/3** |
| A+B với A | −63,38 | −3,75% | −21,12 | −1,84% | 9/4/3 |
| A+B với B | −60,94 | −0,19% | −20,31 | −0,60% | 4/11/1 |

Chênh lệch tuyệt đối và tương đối có thể khác dấu. Ví dụ A tiết kiệm 683 CX trên `co14_215` nhưng tăng 37 CX trên `rd84_142`. Hai thay đổi tương ứng với −4,17% và +12,63% trên từng mạch.

A+B giảm 40,00% CX trên `4gt13_92` và tiết kiệm trung bình 1.076 CX trên `sym9_193`. Khi tính lại trung bình trên 15 mạch còn lại sau khi bỏ `4gt13_92`, A+B giảm **0,81%** so với G. Chỉ số CX và depth cũng có thể đi ngược chiều. Trên `qft_10`, A+B giảm 8,16% CX và tăng 22,36% depth.

Khoảng bootstrap 95% theo mạch của A+B so với G đi từ **−8,84% đến +0,30%**. So với B, khoảng đi từ **−0,79% đến +0,52%**. Tương tác `CX(A+B) − CX(A) − CX(B) + CX(G)` trung bình bằng −0,73% khi chuẩn hóa theo G, với khoảng từ −2,23% đến +0,51%. Các khoảng chứa 0 cho thấy độ bất định đáng kể về lợi ích bổ sung của việc kết hợp. Bốn biến thể QFT đều nằm trong holdout, còn ba biến thể Ising đều nằm trong fit. Kết quả theo loại mạch vì vậy cần được đọc cùng cách chia tập.

Trên holdout, thời gian tạo layout của B và A+B lần lượt là 1,48× và 1,89× G. Thời gian biên dịch tương ứng là 1,10× và 1,06× G. Tỷ lệ dùng trung bình nhân qua các mạch và đo từ đầu vào đã chuẩn hóa. Mỗi tổ hợp mạch, seed và phương án có một lượt warmup và ba lượt đo.

## 5. Ba mạch stress

| Mạch | CX đầu vào | CX của G | CX của A+B | ΔCX của A+B |
|---|---:|---:|---:|---:|
| `urf5_158` | 71.932 | 130.633 | 131.026 | +0,30% |
| `hwb9_119` | 90.955 | 181.555 | 182.977 | +0,78% |
| `urf4_187` | 224.028 | 446.889 | 449.373 | +0,56% |

Trong ba ca seed 42, A hòa G về CX cả ba ca, B tăng trung bình 2,50% và A+B tăng 0,55%. A+B giảm 1,84% so với B, với một ca thắng và hai ca hòa. Phần stress có độ bao phủ seed thấp hơn phần holdout.

## Kết luận

A+B đứng đầu theo cả ΔCX tuyệt đối và tương đối trên 16 mạch holdout. Lợi ích so với B nhỏ, tập trung ở bốn mạch, trong khi bước tạo layout tốn thời gian gấp 1,28 lần B. **B là phương án gọn hơn khi ưu tiên chi phí initial mapping.** Kết quả ba mạch stress ủng hộ việc giữ G làm mốc cho các mạch rất lớn. Các kết luận giới hạn ở đồ thị Tokyo của FSQM và cấu hình SABRE đã đo.

Mã chạy lại, tham số, QASM, CSV theo seed và biểu đồ nằm trong `Capstone_AB_Tokyo_FSQM.zip`. `README.md` có lệnh chạy theo từng bước.
