# Capstone A, B và A+B trên Tokyo

Gói chứa mã chạy lại, 28 QASM gốc từ FSQM và các kết quả đã đo. Xem `BAO_CAO_CAPSTONE_AB_TOKYO.md` để đọc kết luận và các trường hợp ngoại lệ.

| Phương án | Trọng số tương tác | Bố trí ban đầu |
|---|---|---|
| G | Đếm CX | Greedy giữa kỳ |
| A | Suy giảm theo lớp CX | Greedy giữa kỳ |
| B | Đếm CX | Lookahead một qubit, xét tối đa K vị trí |
| A+B | Cùng α với A | Cùng K với B |

## 1. Cài môi trường

Mở terminal Linux hoặc WSL trong thư mục `Capstone_AB_Tokyo_FSQM` sau khi giải nén.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 RAYON_NUM_THREADS=1

python -m capstone_ab catalog
python -m unittest discover -s tests -v
```

Kết quả kèm theo được chạy với Python 3.12.14 và Qiskit 2.5.2. `study.json` ghi phiên bản thư viện, seed, cấu hình compiler, mã băm dữ liệu và mã băm mã nguồn.

## 2. Tái hiện giữa kỳ

```bash
python -m capstone_ab midterm --out runs/midterm_core
python -m scripts.reproduce_midterm --out runs/midterm_archive
```

Lệnh thứ nhất xác nhận G trong mã hiện tại trên fixture Line5 có 14 CX đầu vào. Lệnh thứ hai chạy lại Trivial, Random và G bằng Basic Routing, seed 42. Lệnh này tạo 20 layout Random bằng seed 2026, duyệt 120 layout Line5, kiểm tra tương đương trên toàn bộ trạng thái cơ sở và tái hiện thêm tám mạch trên Line5/Grid6 từ bản lưu giữa kỳ. Các dòng số liệu được đối chiếu với CSV lưu trong `fixtures/midterm_archive/reference/`.

## 3. Chọn α và K

```bash
python -m capstone_ab fit --suite fsqm_fit \
  --alpha-grid 0.0:1.0:0.1 --k-grid 0:20 \
  --out runs/tokyo_fit
```

Cú pháp `start:stop[:step]` lấy cả điểm cuối nếu điểm đó rơi trên lưới. Bước mặc định là 0,1 cho α và 1 cho K. Dùng dấu chấm thập phân ở terminal. Ví dụ, có thể truyền `--alpha-grid 0,0.25,0.6,0.9,1 --k-grid 0,1,2,4,8,16`. Nếu bỏ hai cờ thì chương trình dùng 11 giá trị α từ 0 đến 1 và 21 giá trị K từ 0 đến 20 trong `config/fsqm_study.json`.

Với A, α tác động lên trọng số từng CX theo lớp phụ thuộc CX. α = 0 chỉ cho trọng số vào lớp 0, còn α = 1 cho trọng số đồng nhất. Với B, K = 0 tắt lookahead và K = 1 cho cùng vị trí Greedy. Khi đặt một qubit logic giữa qubit đầu và qubit cuối, B cộng chi phí đặt nó với chi phí thấp nhất để đặt thử qubit kế tiếp. K giới hạn số vị trí thử cho qubit đang xét.

Mỗi lần quét chạy G cùng các giá trị A và B trên chín mạch Tokyo, ba seed. Thứ tự ưu tiên là CX sau routing giảm nhiều nhất theo tỷ lệ trung bình mỗi mạch, rồi đến depth. Khi hai chỉ số hòa, ưu tiên α lớn hơn trong A và K nhỏ hơn trong B. `selected.json` ghi đúng các giá trị được chốt và nguồn tạo ra chúng.

## 4. So sánh G, A, B và A+B

```bash
python -m capstone_ab run --suite fsqm_holdout \
  --params runs/tokyo_fit/selected.json --methods G,A,B,A+B \
  --out runs/tokyo_holdout

python -m capstone_ab run --suite fsqm_stress \
  --params runs/tokyo_fit/selected.json --methods G,A,B,A+B \
  --out runs/tokyo_stress

python -m capstone_ab run --suite fsqm_fit \
  --params runs/tokyo_fit/selected.json --methods G,A,B,A+B \
  --out runs/tokyo_fit_comparison
```

Các lệnh trên chia sẻ một đồ thị cố định `tokyo20_fsqm` với 20 qubit và 43 cạnh hai chiều. Tập holdout có 16 mạch và dùng seed 100, 101, 102. Ba mạch stress lớn dùng seed 42. Lệnh cuối mô tả lại bốn phương án trên chín mạch fit. Mỗi phương án có cùng QASM, basis, router SABRE, routing trial và seed trong từng phép đối chiếu. Nếu gián đoạn, chạy lại đúng lệnh với `--resume`.

Lệnh sau xuất QPY và các chỉ số cho một mạch.

```bash
python -m capstone_ab compile benchmarks/fsqm/qft_13.qasm \
  --topology tokyo20_fsqm --method A+B \
  --params runs/tokyo_fit/selected.json --out runs/qft13_ab
```

## 5. Đọc kết quả

| Tệp hoặc thư mục | Nội dung |
|---|---|
| `results/midterm_archive/reproduction_audit.json` | Đối chiếu bằng chứng giữa kỳ, kết quả Random và vét cạn |
| `results/tokyo_fit/fit_ranking.csv` | 11 kết quả A và 21 kết quả B |
| `results/tokyo_fit/selected.json` | α, K, quy tắc chọn và mã lần chạy |
| `results/tokyo_holdout/` | So sánh chính trên 16 mạch độc lập |
| `results/tokyo_stress/` | So sánh trên ba mạch lớn |
| `results/tokyo_fit_comparison/` | Đối chiếu bốn phương án trên tập dùng để chọn tham số |
| `raw.csv` trong mỗi lần chạy Tokyo | CX đầu vào, CX thêm, SWAP, depth, CX depth, layout, thời gian, seed và kiểm chứng |
| `summary.csv`, `paired_cases.csv`, `factorial.csv` | Tổng hợp, delta từng mạch và tương tác A × B |
| `figures/` | Đường quét α/K và khoảng bootstrap của các cặp so sánh |

Cột `width` trong CSV là K. Dùng `python -m capstone_ab analyze --out runs/tokyo_holdout` để dựng lại bảng từ CSV. Để vẽ lại biểu đồ, cài thêm Matplotlib và chạy `python -m scripts.plot_tokyo --results results --out figures`. Dùng `--results runs` để vẽ từ số liệu vừa chạy bằng các lệnh trên.

Nguồn QASM là 28 file `example/*.qasm` trong danh sách `RESULT_OP` của FSQM. Đồ thị Tokyo đến từ `src/couplinggraph.cpp`. `config/fsqm_study.json` ghi phân nhóm, cạnh và SHA-256 từng QASM. [Park và cộng sự, DAC 2022](https://doi.org/10.1145/3489517.3530402)
