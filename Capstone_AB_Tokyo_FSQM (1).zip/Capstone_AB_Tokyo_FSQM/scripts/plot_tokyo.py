"""Plot the Tokyo parameter sweeps and paired holdout CX effects."""

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MaxNLocator

INK = "#142d35"
GRID = "#dce7e8"
TEAL = "#087b77"
BLUE = "#3a5892"
GOLD = "#bc681e"


def read_rows(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def percent(value, decimals=0):
    if value == 0:
        return "0%"
    return f"{value:+.{decimals}f}%".replace(".", ",").replace("-", "−")


def style_axis(ax, axis):
    ax.grid(axis=axis, color=GRID, linewidth=0.85)
    ax.set_axisbelow(True)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(length=0, pad=8, colors=INK)


def plot_sweeps(results, output):
    fit = results / "tokyo_fit"
    rows = read_rows(fit / "fit_ranking.csv")
    chosen = json.loads((fit / "selected.json").read_text(encoding="utf-8"))
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.1), sharey=True, layout="constrained")
    fig.suptitle(f"Quét tham số trên {rows[0]['cases']} mạch Tokyo", fontsize=16, fontweight="bold")
    for ax, method, key, xlabel, color in (
        (axes[0], "A", "alpha", "α", TEAL),
        (axes[1], "B", "width", "K", BLUE),
    ):
        series = sorted(
            (float(row[key]), float(row["mean_delta_cx_pct"])) for row in rows
            if row["method"] == method
        )
        x, y = zip(*series)
        score = dict(series)[chosen[key]]
        ax.axhline(0, color="#6d7f84", linestyle="--", linewidth=1)
        ax.plot(x, y, "o-", color=color, markersize=4, linewidth=1.8)
        ax.scatter(chosen[key], score, s=84, color=GOLD, edgecolors="white", linewidths=1.2, zorder=4)
        ax.annotate(f"{xlabel} = {chosen[key]}\n{percent(score, 2)}".replace(".", ","),
                    (chosen[key], score), xytext=(8, 15), textcoords="offset points", color=INK,
                    fontsize=10, bbox={"facecolor": "white", "edgecolor": GRID, "pad": 4})
        ax.set_title(f"{method} · Khoảng quét {xlabel}", loc="left", fontweight="bold", fontsize=12)
        ax.set_xlabel(xlabel)
        style_axis(ax, "y")
    axes[0].set_ylabel("ΔCX trung bình so với G")
    axes[0].yaxis.set_major_formatter(FuncFormatter(lambda value, _: percent(value)))
    axes[0].xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:.1f}".replace(".", ",")))
    axes[1].xaxis.set_major_locator(MaxNLocator(nbins=10, integer=True))
    fig.savefig(output / "quet_alpha_k_tokyo.png", dpi=180)
    plt.close(fig)


def plot_holdout(results, output):
    rows = {(row["arm"], row["reference"]): row for row in read_rows(results / "tokyo_holdout/summary.csv")
            if row["group"] == "all"}
    pairs = (("A", "G"), ("B", "G"), ("A+B", "G"), ("A+B", "A"), ("A+B", "B"))
    fig, ax = plt.subplots(figsize=(9.1, 4.4))
    fig.subplots_adjust(left=0.16, right=0.81, top=0.79, bottom=0.20)
    fig.text(0.16, 0.92, f"Hiệu ứng CX trên {rows[pairs[0]]['cases']} mạch holdout", fontsize=16,
             fontweight="bold", color=INK)
    fig.text(0.16, 0.85, "Điểm = trung bình theo mạch   ·   Đoạn = khoảng bootstrap 95%",
             fontsize=10, color=INK)
    for i, pair in enumerate(pairs):
        row = rows[pair]
        score = float(row["mean_delta_cx_pct"])
        color = TEAL if pair[0] == "A+B" else BLUE
        if row["cx_ci_low_pct"] and row["cx_ci_high_pct"]:
            ax.hlines(i, float(row["cx_ci_low_pct"]), float(row["cx_ci_high_pct"]),
                      color=color, linewidth=2.3)
        ax.scatter(score, i, s=50, color=color, zorder=4)
        ax.text(1.025, i, percent(score, 2), color=INK, ha="left", va="center",
                transform=ax.get_yaxis_transform())
    ax.axvline(0, color="#6d7f84", linestyle="--", linewidth=1.2)
    ax.set_yticks(range(len(pairs)), [f"{method} / {reference}" for method, reference in pairs])
    ax.set_ylim(len(pairs) - 0.45, -0.55)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: percent(value)))
    ax.set_xlabel("ΔCX tương đối (giá trị âm = giảm CX)", labelpad=12)
    style_axis(ax, "x")
    fig.savefig(output / "so_sanh_tokyo_holdout.png", dpi=180)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=Path("results"))
    parser.add_argument("--out", type=Path, default=Path("figures"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "text.color": INK, "axes.labelcolor": INK})
    plot_sweeps(args.results, args.out)
    plot_holdout(args.results, args.out)


if __name__ == "__main__":
    main()
