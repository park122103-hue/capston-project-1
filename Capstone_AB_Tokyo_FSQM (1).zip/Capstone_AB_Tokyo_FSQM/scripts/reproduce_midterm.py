"""Replay the archived Basic-routing midterm results on Line5 and Grid6."""

import argparse
import csv
from itertools import permutations
from pathlib import Path
from random import Random
from statistics import correlation, mean, stdev

import numpy as np
from qiskit import qpy, transpile, __version__ as qiskit_version
from qiskit.quantum_info import Operator
from qiskit.transpiler import CouplingMap

from capstone_ab.catalog import ROOT, file_hash, read_json, write_csv, write_json
from capstone_ab.compiler import BASIS, interaction_weights
from capstone_ab.mapping import PlacementProblem, distances_from_edges

ARCHIVE = ROOT / "fixtures/midterm_archive"
BASIS_TOLERANCE = 1e-8
MAPPING_SEED = 2026
TRANSPILE_SEED = 42
BENCHMARKS = (
    "chain4", "star4", "ring4", "cross4", "ghz5", "seeded_random5", "dense5", "qft_style4",
)
SETTINGS = {"optimization_level": 0, "transpiler_seed": TRANSPILE_SEED,
            "qiskit_version": qiskit_version}


def load_qpy(path):
    with path.open("rb") as handle:
        circuit, = qpy.load(handle)
    return circuit


def placement(logical, coupling):
    distances = distances_from_edges(coupling.size(), set(coupling.get_edges()))
    return PlacementProblem(interaction_weights(logical), distances)


def compile_layout(logical, coupling, problem, layout):
    compiled = transpile(
        logical, basis_gates=list(BASIS), coupling_map=coupling, initial_layout=list(layout),
        routing_method="basic", optimization_level=0, seed_transpiler=TRANSPILE_SEED,
    )
    edges = set(coupling.get_edges())
    if tuple(compiled.layout.initial_index_layout(filter_ancillas=True)) != tuple(layout):
        raise ValueError(f"Qiskit applied a different layout for {layout}")
    for gate in compiled.data:
        if gate.name not in BASIS:
            raise ValueError(f"Unexpected gate {gate.name}")
        if gate.name == "cx" and tuple(compiled.find_bit(bit).index for bit in gate.qubits) not in edges:
            raise ValueError("CX outside the historical coupling graph")
    input_cx = logical.count_ops().get("cx", 0)
    output_cx = compiled.count_ops().get("cx", 0)
    return compiled, {
        "layout": list(layout), "mapping_cost": problem.cost(layout), "input_2q": input_cx,
        "compiled_2q": output_cx, "twoq_overhead": output_cx - input_cx, "depth": compiled.depth(),
    }


def verify_basis(logical_operator, compiled, initial):
    """Compare every basis column using zero ancillas and one common phase."""
    final = compiled.layout.final_index_layout(filter_ancillas=True)

    def embedded_indices(layout):
        return [sum(((value >> i) & 1) << bit for i, bit in enumerate(layout))
                for value in range(len(logical_operator))]

    actual = Operator(compiled).data[:, embedded_indices(initial)]
    expected = np.zeros_like(actual)
    expected[embedded_indices(final), :] = logical_operator
    overlap = np.vdot(expected, actual)
    phase = overlap / abs(overlap) if overlap else 1.0
    error = float(np.max(np.abs(actual - phase * expected)))
    if not error <= BASIS_TOLERANCE:
        raise ValueError(f"Functional equivalence failed for {initial}: {error:.3e}")
    return {"final_layout": final, "tested_basis_inputs": len(logical_operator),
            "max_error": error, "status": "PASSED"}


def archive_match(name, actual_rows, *, ignored=()):
    with (ARCHIVE / "reference" / name).open(newline="", encoding="utf-8") as handle:
        reference = list(csv.DictReader(handle))
    if len(reference) != len(actual_rows):
        raise ValueError(f"{name}: got {len(actual_rows)} rows, expected {len(reference)}")
    for index, (expected, actual) in enumerate(zip(reference, actual_rows), start=1):
        differences = {
            key: (value, actual.get(key)) for key, value in expected.items()
            if key not in ignored and value != str(actual.get(key))
        }
        if differences:
            raise ValueError(f"{name}, row {index}: {differences}")
    return len(reference)


def replay_representative(logical, output):
    coupling = CouplingMap.from_line(5, bidirectional=True)
    problem = placement(logical, coupling)
    if problem.weights != read_json(ARCHIVE / "interaction_matrix.json"):
        raise ValueError("The representative circuit differs from its archived interaction matrix")

    layouts = list(permutations(range(5), logical.num_qubits))
    compiled = {layout: compile_layout(logical, coupling, problem, layout) for layout in layouts}
    trivial = tuple(range(logical.num_qubits))
    greedy = problem.greedy().layout
    random_one = tuple(Random(MAPPING_SEED).sample(range(5), logical.num_qubits))
    first, equivalents = [], []
    operator = Operator(logical).data
    for method, layout in (("Trivial", trivial), ("Random", random_one), ("Ours", greedy)):
        circuit, metrics = compiled[layout]
        first.append({
            "method": method, "initial_layout": metrics["layout"],
            **{k: v for k, v in metrics.items() if k not in ("layout", "depth")},
            "compiled_depth": metrics["depth"], "routing_method": "basic", **SETTINGS,
        })
        equivalents.append({"method": method, "initial_layout": list(layout),
                            **verify_basis(operator, circuit, layout)})
    random_layouts = Random(MAPPING_SEED).sample(layouts, 20)
    random_rows = [
        {"method": method, "trial": trial, **compiled[layout][1], "routing_method": "basic",
         "mapping_seed": MAPPING_SEED, **SETTINGS}
        for method, trial, layout in (
            ("Trivial", 0, trivial), ("Ours", 0, greedy),
            *(("Random", trial, layout) for trial, layout in enumerate(random_layouts, 1)),
        )
    ]
    exhaustive = [compiled[layout][1] for layout in layouts]
    audits = {}
    for name, rows, ignored in (
        ("first_comparison.csv", first, ()),
        ("random_20_comparison.csv", random_rows, ()),
        ("exhaustive_120.csv", exhaustive, ()),
        ("functional_equivalence.csv", equivalents, ("max_error",)),
    ):
        audits[name] = archive_match(name, rows, ignored=ignored)
        write_csv(output / name, rows)

    sample = random_rows[2:]
    cxs = [row["compiled_2q"] for row in sample]
    depths = [row["depth"] for row in sample]
    optimum = min(row["mapping_cost"] for row in exhaustive)
    return audits, {
        "input_cx": first[0]["input_2q"], "random_mean_cx": mean(cxs), "random_sd_cx": stdev(cxs),
        "random_mean_depth": mean(depths), "random_sd_depth": stdev(depths),
        "random_pearson_cost_vs_cx": correlation([row["mapping_cost"] for row in sample], cxs),
        "minimum_static_cost": optimum, "static_cost_ties": sum(row["mapping_cost"] == optimum
                                                                for row in exhaustive),
        "min_compiled_cx": min(row["compiled_2q"] for row in exhaustive),
        "min_depth": min(row["depth"] for row in exhaustive),
        "representative_basis_inputs_passed": sum(row["tested_basis_inputs"] for row in equivalents),
        "representative_max_error": max(row["max_error"] for row in equivalents),
    }


def replay_benchmarks(output):
    layouts_by_chip = (
        ("line5", CouplingMap.from_line(5, bidirectional=True)),
        ("grid6", CouplingMap.from_grid(2, 3, bidirectional=True)),
    )
    measured, verified, summaries = [], [], []
    for circuit_index, name in enumerate(BENCHMARKS):
        logical = load_qpy(ARCHIVE / f"benchmarks/{name}.qpy")
        operator = Operator(logical).data
        n = logical.num_qubits
        for topology_index, (topology, coupling) in enumerate(layouts_by_chip):
            problem = placement(logical, coupling)
            rng = Random(MAPPING_SEED + 100 * circuit_index + topology_index)
            random_layouts = rng.sample(list(permutations(range(coupling.size()), n)), 20)
            measured_case = []
            for method, trial, layout in (
                ("Trivial", 0, tuple(range(n))), ("Ours", 0, problem.greedy().layout),
                *(("Random", trial, layout) for trial, layout in enumerate(random_layouts, 1)),
            ):
                context = {"circuit": name, "topology": topology, "method": method, "trial": trial}
                compiled, metrics = compile_layout(logical, coupling, problem, layout)
                measured_case.append({**context, **metrics, "routing": "basic", **SETTINGS})
                checks = verify_basis(operator, compiled, layout)
                verified.append({**context, "tested_inputs": checks["tested_basis_inputs"],
                                 "max_error": checks["max_error"], "status": checks["status"]})
            measured.extend(measured_case)
            trivial, greedy, *random_rows = measured_case
            result = {"circuit": name, "topology": topology, "qubits": n,
                      "input_2q": greedy["input_2q"]}
            for label, metric in (("2q", "compiled_2q"), ("depth", "depth")):
                random_values = [row[metric] for row in random_rows]
                result.update({
                    f"trivial_{label}": trivial[metric], f"ours_{label}": greedy[metric],
                    f"random_mean_{label}": round(mean(random_values), 2),
                    f"random_std_{label}": round(stdev(random_values), 2),
                    f"ours_better_{label}": sum(greedy[metric] < value for value in random_values),
                })
            summaries.append(result)
        print(f"{name}: Basic placements and basis-state checks on Line5 and Grid6", flush=True)
    audits = {
        "benchmark_raw.csv": archive_match("benchmark_raw.csv", measured),
        "benchmark_summary.csv": archive_match("benchmark_summary.csv", summaries),
        "benchmark_equivalence.csv": archive_match(
            "benchmark_equivalence.csv",
            sorted(verified, key=lambda row: (row["circuit"], row["topology"], row["trial"],
                                              row["method"] != "Trivial")),
            ignored=("max_error",),
        ),
    }
    write_csv(output / "benchmark_raw.csv", measured)
    write_csv(output / "benchmark_summary.csv", summaries)
    write_csv(output / "benchmark_equivalence.csv", verified)
    return audits, {"benchmark_compilations_passed": len(verified),
                    "benchmark_max_error": max(row["max_error"] for row in verified)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("runs/midterm_archive"))
    args = parser.parse_args()
    manifest = read_json(ARCHIVE / "manifest.json")
    for name, entry in manifest["files"].items():
        if file_hash(ARCHIVE / name) != entry["sha256"]:
            raise ValueError(f"Historical input changed: {name}")
    qpy_path = ROOT / "fixtures/midterm_normalized.qpy"
    fixture = read_json(ROOT / "config/input_manifest.json")["midterm_fixture"]
    if file_hash(qpy_path) != fixture["sha256"]:
        raise ValueError("Historical representative QPY changed")
    if args.out.exists() and any(args.out.iterdir()):
        raise ValueError("Use an empty output directory")
    representative, metrics = replay_representative(load_qpy(qpy_path), args.out)
    benchmarks, benchmark_metrics = replay_benchmarks(args.out)
    write_json(args.out / "reproduction_audit.json", {
        "reference_archive": manifest["archive"], "reference_archive_sha256": manifest["sha256"],
        "qiskit_version": qiskit_version, "transpiler_seed": TRANSPILE_SEED, "mapping_seed": MAPPING_SEED,
        "exact_reference_rows": {**representative, **benchmarks},
        "basis_tolerance": BASIS_TOLERANCE, **metrics, **benchmark_metrics,
    })
    print(args.out.resolve())


if __name__ == "__main__":
    main()
