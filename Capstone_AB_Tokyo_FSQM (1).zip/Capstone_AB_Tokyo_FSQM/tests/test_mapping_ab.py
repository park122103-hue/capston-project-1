import unittest

from qiskit import QuantumCircuit

from capstone_ab.compiler import WEIGHT_SCALE, cx_layers, interaction_weights
from capstone_ab.mapping import PlacementProblem, distances_from_edges


class MappingABTests(unittest.TestCase):
    def test_normalized_cx_layers_and_uniform_control(self):
        circuit = QuantumCircuit(4)
        circuit.cx(0, 1)
        circuit.rz(0.3, 2)
        circuit.cx(2, 3)
        circuit.cx(1, 2)
        circuit.cx(0, 1)
        triples, max_layer = cx_layers(circuit)
        self.assertEqual([layer for _, _, layer in triples], [0, 0, 1, 2])
        self.assertEqual(max_layer, 2)
        uniform = interaction_weights(circuit, 1.0)
        self.assertEqual(uniform[0][1], 2)
        self.assertEqual(sum(uniform[a][b] for a in range(4) for b in range(a + 1, 4)), 4)
        decay = interaction_weights(circuit, 0.8)
        self.assertEqual(decay[0][1], 1_800_000_000_000)
        self.assertEqual(decay[2][3], WEIGHT_SCALE)
        self.assertEqual(decay[1][2], round(WEIGHT_SCALE * 0.8**0.5))
        self.assertEqual(decay[1][2], decay[2][1])
        self.assertEqual([decay[i][i] for i in range(4)], [0] * 4)

    def test_lookahead_reserves_next_site(self):
        weights = ((0, 6, 4, 5), (6, 0, 3, 1), (4, 3, 0, 0), (5, 1, 0, 0))
        distances = distances_from_edges(5, ((i, i + 1) for i in range(4)))
        problem = PlacementProblem(weights, distances)
        self.assertEqual(problem.order, (0, 1, 2, 3))
        self.assertEqual(problem.greedy().layout, (2, 1, 3, 0))
        self.assertEqual(problem.greedy().cost, 27)
        self.assertEqual(problem.lookahead(1), problem.greedy())
        result = problem.lookahead(2)
        self.assertEqual(result.layout, (2, 1, 0, 3))
        self.assertEqual(result.cost, 24)
        self.assertEqual(result.evaluations, 4)

    def test_no_interactions_and_single_qubit(self):
        circuit = QuantumCircuit(1)
        self.assertEqual(interaction_weights(circuit, 0.8), [[0]])
        problem = PlacementProblem([[0]], ((0,),))
        self.assertEqual(problem.lookahead(2).layout, (0,))
        self.assertEqual(problem.lookahead(2).evaluations, 0)

    def test_alpha_zero_weights_only_the_first_cx_layer(self):
        circuit = QuantumCircuit(4)
        circuit.cx(0, 1)
        circuit.cx(2, 3)
        circuit.cx(1, 2)
        circuit.cx(0, 1)
        weights = interaction_weights(circuit, 0)
        self.assertEqual(weights[0][1], WEIGHT_SCALE)
        self.assertEqual(weights[2][3], WEIGHT_SCALE)
        self.assertEqual(weights[1][2], 0)
        self.assertEqual(interaction_weights(QuantumCircuit(1), 0), [[0]])

    def test_k_zero_and_one_bypass_lookahead(self):
        distances = distances_from_edges(3, ((0, 1), (1, 2)))
        problem = PlacementProblem([[0, 2, 0], [2, 0, 1], [0, 1, 0]], distances)
        for k in (0, 1):
            self.assertEqual(problem.lookahead(k), problem.greedy())
        self.assertEqual(problem.lookahead(19), problem.lookahead(20))
