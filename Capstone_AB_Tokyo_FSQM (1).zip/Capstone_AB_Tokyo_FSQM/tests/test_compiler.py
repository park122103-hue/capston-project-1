from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from qiskit import QuantumCircuit, qpy
from qiskit.quantum_info import Operator

from capstone_ab.catalog import ROOT, hardware_catalog
from capstone_ab.compiler import Arm, CompilerOptions, METHODS, compile_circuit, load_unitary, normalize
from capstone_ab.verification import Verifier


class CompilerTests(unittest.TestCase):
    def test_midterm_actual_compilation(self):
        with (ROOT / "fixtures/midterm_normalized.qpy").open("rb") as handle:
            logical, = qpy.load(handle)
        hardware = hardware_catalog()["line5"]
        coupling = hardware.coupling_map()
        options = CompilerOptions(router="basic")
        verifier = Verifier(logical, hardware, 6)
        for method, expected in [
            ("T", (3, 23, 90)), ("G", (2, 20, 77)),
        ]:
            compiled = compile_circuit(logical, hardware, coupling, Arm(method, method),
                                       42, options)
            row = verifier.check(compiled)
            self.assertEqual((row["swap"], row["cx"], row["depth"]), expected)
            self.assertEqual(row["verification"], "OPERATOR+STRUCTURAL")

    def test_every_arm_and_cancellation(self):
        logical = QuantumCircuit(3)
        logical.rz(0.7, 1)
        logical.sx(0)
        logical.cx(0, 2)
        logical.cx(0, 2)
        logical.cx(1, 0)
        hardware = hardware_catalog()["quito5"]
        coupling = hardware.coupling_map()
        verifier = Verifier(logical, hardware, 6)
        options = CompilerOptions(post_opt="cancel-cx")
        for method in METHODS:
            with self.subTest(method=method):
                compiled = compile_circuit(logical, hardware, coupling, Arm(method, method),
                                           42, options)
                row = verifier.check(compiled)
                self.assertLessEqual(row["cx"], row["cx_before_post_opt"])
                self.assertEqual(row["cx_before_post_opt"], 3 + 3 * row["swap"])
                if method == "T":
                    self.assertLess(row["cx"], row["cx_before_post_opt"])
                bad_final = tuple(reversed(compiled.final))
                with self.assertRaisesRegex(ValueError, "permutation"):
                    verifier.check(replace(compiled, final=bad_final))

    def test_qasm3_and_rejection_of_nonunitary(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "example.qasm3"
            path.write_text('OPENQASM 3.0;\ninclude "stdgates.inc";\nqubit[2] q;\nh q[0];\ncx q[0], q[1];\n')
            original = load_unitary(path)
            self.assertTrue(Operator(original).equiv(Operator(normalize(original))))
            path.write_text('OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[1];\ncreg c[1];\nmeasure q[0] -> c[0];\n')
            with self.assertRaisesRegex(ValueError, "non-unitary"):
                load_unitary(path)

    def test_fsqm_trim_removes_only_unused_wires(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "padded.qasm"
            path.write_text('OPENQASM 2.0;\ninclude "qelib1.inc";\nqreg q[5];\n'
                            'x q[1];\nbarrier q;\ncx q[4],q[1];\n')
            expected = QuantumCircuit(2)
            expected.x(0)
            expected.cx(1, 0)
            trimmed = load_unitary(path, trim_idle=True)
            self.assertEqual(trimmed.metadata["declared_qubits"], 5)
            self.assertTrue(Operator(trimmed).equiv(Operator(expected)))
            self.assertEqual(load_unitary(path).num_qubits, 5)
