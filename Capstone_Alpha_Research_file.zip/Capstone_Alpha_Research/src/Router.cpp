
#include <vector>
#include <deque>
#include <algorithm>
#include <climits>
#include <cmath>
#include <stdexcept>
#include <iostream>
#include "Router.h"

using namespace std;

Router::Router(const Circuits& circ, const Graph& graph, const Mapper& mapper_state,
               double b, double alpha, bool trace, bool bridge)
    : circ(circ), graph(graph), aq(mapper_state), b_param(b), alpha_r(alpha),
      record_events(trace), allow_bridge(bridge), excess_deferral_cost(0) {}

std::vector<std::pair<int, int>> Router::run() {
    total_swapped_list.clear();
    events.clear();
    const std::vector<Gate>& circ_gates = circ.getGates();
    
    // 1. 2-큐비트 게이트만 추출
    std::vector<std::pair<int, int>> two_q_gates;
    for (const auto& g : circ_gates) {
        if (g.q0 != -1) {
            two_q_gates.push_back({ g.q0, g.q1 });
        }
    }
    int num_2q = (int)two_q_gates.size();
    if (num_2q == 0) return total_swapped_list;

    int num_lq = aq.num_lq;

    // 2. DAG 위상 전처리: ASAP 깊이, ALAP 남은 깊이, Slack(여유 시간) 계산
    std::vector<int> asap_depth(num_2q, 1);
    std::vector<int> last_gate(num_lq, -1);
    for (int i = 0; i < num_2q; i++) {
        int c = two_q_gates[i].first, t = two_q_gates[i].second;
        int d = 1;
        if (last_gate[c] != -1) d = std::max(d, asap_depth[last_gate[c]] + 1);
        if (last_gate[t] != -1) d = std::max(d, asap_depth[last_gate[t]] + 1);
        asap_depth[i] = d;
        last_gate[c] = i;
        last_gate[t] = i;
    }
    int D_max = 0;
    for (int d : asap_depth) D_max = std::max(D_max, d);

    std::vector<int> rem_depth(num_2q, 1);
    std::vector<int> next_gate(num_lq, -1);
    for (int i = num_2q - 1; i >= 0; i--) {
        int c = two_q_gates[i].first, t = two_q_gates[i].second;
        int d = 1;
        if (next_gate[c] != -1) d = std::max(d, rem_depth[next_gate[c]] + 1);
        if (next_gate[t] != -1) d = std::max(d, rem_depth[next_gate[t]] + 1);
        rem_depth[i] = d;
        next_gate[c] = i;
        next_gate[t] = i;
    }

    std::vector<int> slack(num_2q, 0);
    for (int i = 0; i < num_2q; i++) {
        slack[i] = D_max - (asap_depth[i] + rem_depth[i] - 1);
    }

    std::vector<int> defer_count(num_2q, 0); // 각 게이트별 W /= 2 미루기 누적 횟수

    // 3. 큐비트별 게이트 의존성 큐 (DAG 런타임 큐)
    std::vector<std::deque<int>> qubit_queues(num_lq);
    for (int gid = 0; gid < num_2q; gid++) {
        qubit_queues[two_q_gates[gid].first].push_back(gid);
        qubit_queues[two_q_gates[gid].second].push_back(gid);
    }

    std::vector<bool> executed(num_2q, false);
    int num_executed = 0;
    int first_unexec = 0;
    std::vector<int> in_win_stamp(num_2q, 0);
    int win_epoch = 0;
    std::vector<double> decay(graph.getNumPq(), 1.0); // 핑퐁 및 무한 루프 차단용 쿨다운 페널티

    static const long long POW_08[60] = {
        1000000000000LL, 800000000000LL, 640000000000LL, 512000000000LL, 409600000000LL, 327680000000LL,
        262144000000LL, 209715200000LL, 167772160000LL, 134217728000LL, 107374182400LL, 85899345920LL,
        68719476736LL, 54975581388LL, 43980465111LL, 35184372088LL, 28147497671LL, 22517998136LL,
        18014398509LL, 14411518807LL, 11529215046LL, 9223372036LL, 7378697629LL, 5902958103LL,
        4722366482LL, 3777893186LL, 3022314549LL, 2417851639LL, 1934281311LL, 1547425049LL,
        1237940039LL, 990352031LL, 792281625LL, 633825300LL, 507060240LL, 405648192LL,
        324518553LL, 259614842LL, 207691874LL, 166153499LL, 132922799LL, 106338239LL,
        85070591LL, 68056473LL, 54445178LL, 43556142LL, 34844914LL, 27875931LL,
        22300745LL, 17840596LL, 14272476LL, 11417981LL, 9134385LL, 7307508LL,
        5846006LL, 4676805LL, 3741444LL, 2993155LL, 2394524LL, 1915619LL,
    };

    // Only the lookahead exponent varies. Hold deferral decay and the legacy
    // exponent cap constant. At 0.8 the original fixed-point table is exact.
    double lag_factors[60] = {1.0};
    for (int layer = 1; layer < 60; ++layer) {
        lag_factors[layer] = lag_factors[layer - 1] * alpha_r;
    }
    auto window_weight = [&](int layer, int gid) -> unsigned long long {
        int wait = std::min(59 - layer, defer_count[gid]);
        auto weight = static_cast<unsigned long long>(POW_08[layer + wait]);
        if (alpha_r != 0.8 && layer > 0) {
            weight = std::llround(lag_factors[layer] * POW_08[wait]);
        }
        if (b_param > 0.0 && slack[gid] > 0) {
            weight = static_cast<unsigned long long>(weight / (1.0 + slack[gid] * b_param));
        }
        return std::max(1ULL, weight);
    };
    int previous_executed = -1;
    int no_progress_rounds = 0;
    const int limit = 4 * graph.getNumPq() * graph.getNumPq();

    // 4. 메인 DAG Front Layer 라우팅 루프
    while (num_executed < num_2q) {
        no_progress_rounds = (num_executed == previous_executed) ? no_progress_rounds + 1 : 0;
        previous_executed = num_executed;
        if (record_events && no_progress_rounds > limit) {
            throw std::runtime_error("Router stalled without executing a CX");
        }
        // (A) Front Layer 수집
        std::vector<int> front_layer;
        for (int q = 0; q < num_lq; q++) {
            if (!qubit_queues[q].empty()) {
                int gid = qubit_queues[q].front();
                int c = two_q_gates[gid].first;
                int t = two_q_gates[gid].second;
                if (!qubit_queues[c].empty() && qubit_queues[c].front() == gid &&
                    !qubit_queues[t].empty() && qubit_queues[t].front() == gid) {
                    bool already = false;
                    for (int fg : front_layer) {
                        if (fg == gid) { already = true; break; }
                    }
                    if (!already) front_layer.push_back(gid);
                }
            }
        }

        // (B) 인접한(dist <= 1) 게이트 즉시 실행
        bool progress = true;
        bool any_executed = false;
        while (progress) {
            progress = false;
            std::vector<int> exec_list;
            for (int gid : front_layer) {
                int c = two_q_gates[gid].first;
                int t = two_q_gates[gid].second;
                if (aq.distance[aq.l2p[c]][aq.l2p[t]] == 1) {
                    exec_list.push_back(gid);
                }
            }
            if (!exec_list.empty()) {
                progress = true;
                any_executed = true;
                for (int gid : exec_list) {
                    int c = two_q_gates[gid].first;
                    int t = two_q_gates[gid].second;
                    qubit_queues[c].pop_front();
                    qubit_queues[t].pop_front();
                    executed[gid] = true;
                    num_executed++;
                    if (record_events) events.push_back({'G', gid});

                    for (auto it = front_layer.begin(); it != front_layer.end(); ++it) {
                        if (*it == gid) {
                            front_layer.erase(it);
                            break;
                        }
                    }

                    for (int q : { c, t }) {
                        if (!qubit_queues[q].empty()) {
                            int ngid = qubit_queues[q].front();
                            int nc = two_q_gates[ngid].first;
                            int nt = two_q_gates[ngid].second;
                            if (!qubit_queues[nc].empty() && qubit_queues[nc].front() == ngid &&
                                !qubit_queues[nt].empty() && qubit_queues[nt].front() == ngid) {
                                bool already = false;
                                for (int fg : front_layer) {
                                    if (fg == ngid) { already = true; break; }
                                }
                                if (!already) front_layer.push_back(ngid);
                            }
                        }
                    }
                }
            }
        }

        if (num_executed >= num_2q) break;
        if (any_executed) {
            std::fill(decay.begin(), decay.end(), 1.0); // 게이트 실행 시 쿨다운 리셋
        }

        // (C) DAG Topological Layer 기반 가중치 윈도우 구축 (최대 52개 게이트)
        struct WindowGate {
            int gid;
            unsigned long long weight;
        };
        std::vector<WindowGate> unexec_window;

        // Front layer 게이트들: Slack=0이면 무한제약(전체 가중치), Slack>0이면 dc * 0.8 / Slack
        for (int fg : front_layer) {
            unexec_window.push_back({fg, window_weight(0, fg)});
        }

        // 후속 게이트들의 위상 레이어 (O(1) Epoch 스탬핑 + first_unexec 점프)
        win_epoch++;
        for (const auto& wg : unexec_window) in_win_stamp[wg.gid] = win_epoch;

        while (first_unexec < num_2q && executed[first_unexec]) {
            first_unexec++;
        }

        for (int gid = first_unexec; gid < num_2q && (int)unexec_window.size() < 52; gid++) {
            if (executed[gid] || in_win_stamp[gid] == win_epoch) continue;

            int c = two_q_gates[gid].first, t = two_q_gates[gid].second;
            int pos_c = 0;
            for (int x : qubit_queues[c]) {
                if (x == gid) break;
                if (++pos_c >= 52) break;
            }
            int pos_t = 0;
            for (int x : qubit_queues[t]) {
                if (x == gid) break;
                if (++pos_t >= 52) break;
            }
            int layer = std::max(pos_c, pos_t);

            unexec_window.push_back({gid, window_weight(layer, gid)});
            in_win_stamp[gid] = win_epoch;
        }

        // (D) Front Layer 게이트들에 대한 SWAP 후보 생성
        std::vector<std::pair<int, int>> candi_swaps;
        for (int gid : front_layer) {
            int c = two_q_gates[gid].first;
            int t = two_q_gates[gid].second;
            int pc = aq.l2p[c];
            int pt = aq.l2p[t];
            int d_cur = aq.distance[pc][pt];
            for (int p : { pc, pt }) {
                int p_other = (p == pc) ? pt : pc;
                for (int nxt : graph.adj[p]) {
                    int d_new = aq.distance[nxt][p_other];

                    int u = std::min(p, nxt);
                    int v = std::max(p, nxt);
                    bool exists = false;
                    for (const auto& pr : candi_swaps) {
                        if (pr.first == u && pr.second == v) { exists = true; break; }
                    }
                    if (!exists) candi_swaps.push_back({ u, v });
                }
            }
        }

        auto eval_swap = [&](const std::vector<int>& cur_l2p, int p1, int p2, int depth_offset) -> long long {
            long long delta_cost = 0;
            for (const auto& wg : unexec_window) {
                int c = two_q_gates[wg.gid].first;
                int t = two_q_gates[wg.gid].second;
                int pc_old = cur_l2p[c];
                int pt_old = cur_l2p[t];

                int pc_new = (pc_old == p1) ? p2 : ((pc_old == p2) ? p1 : pc_old);
                int pt_new = (pt_old == p1) ? p2 : ((pt_old == p2) ? p1 : pt_old);

                int d_before = aq.distance[pc_old][pt_old];
                int d_after = aq.distance[pc_new][pt_new];
                int d_diff = d_after - d_before;

                if (d_diff != 0) {
                    unsigned long long w = wg.weight >> depth_offset;
                    if (w == 0) w = 1ULL;
                    delta_cost += (long long)d_diff * (long long)w;
                }
            }
            // 쿨다운 페널티 적용 (가산 페널티로 핑퐁 억제, base 10^12 대응)
            long long pen = (long long)((decay[p1] - 1.0 + decay[p2] - 1.0) * 150000000000.0);
            return delta_cost + pen;
        };

        // --- Depth 1 평가 ---
        struct Cand1 {
            std::pair<int, int> swap;
            long long c1;
        };
        std::vector<Cand1> eval_d1;
        long long min_c1 = LLONG_MAX;

        for (const auto& pr : candi_swaps) {
            long long c1 = eval_swap(aq.l2p, pr.first, pr.second, 0);
            eval_d1.push_back({ pr, c1 });
            if (c1 < min_c1) min_c1 = c1;
        }

        // (BRIDGE Gate Optimization - FSQM Algorithm 2 Line 15)
        // Front Layer 내에 거리 2인 게이트가 있을 때, 해당 게이트를 위한 스왑이 미래에 큰 이득을 주지 못하면
        // 무리하게 배치를 망치는 SWAP 대신 제자리 BRIDGE(3 CNOT = 1 SWAP 동등)로 즉시 실행!
        int bridge_gid = -1;
        for (int fg : front_layer) {
            int c = two_q_gates[fg].first;
            int t = two_q_gates[fg].second;
            if (aq.distance[aq.l2p[c]][aq.l2p[t]] == 2) {
                // 해당 게이트의 전용 스왑 평가: 만약 스왑이 미래 게이트에 큰 이득을 주지 못한다면 BRIDGE 선택
                bridge_gid = fg;
                break;
            }
        }

        if (allow_bridge && bridge_gid != -1 && min_c1 >= -500000000000LL) {
            int c = two_q_gates[bridge_gid].first;
            int t = two_q_gates[bridge_gid].second;
            qubit_queues[c].pop_front();
            qubit_queues[t].pop_front();
            executed[bridge_gid] = true;
            num_executed++;
            total_swapped_list.push_back({ -1, bridge_gid }); // -1 indicates BRIDGE
            if (record_events) events.push_back({'B', bridge_gid});

            for (auto it = front_layer.begin(); it != front_layer.end(); ++it) {
                if (*it == bridge_gid) {
                    front_layer.erase(it);
                    break;
                }
            }

            for (int q : { c, t }) {
                if (!qubit_queues[q].empty()) {
                    int ngid = qubit_queues[q].front();
                    int nc = two_q_gates[ngid].first;
                    int nt = two_q_gates[ngid].second;
                    if (!qubit_queues[nc].empty() && qubit_queues[nc].front() == ngid &&
                        !qubit_queues[nt].empty() && qubit_queues[nt].front() == ngid) {
                        bool already = false;
                        for (int fg : front_layer) {
                            if (fg == ngid) { already = true; break; }
                        }
                        if (!already) front_layer.push_back(ngid);
                    }
                }
            }
            continue;
        }

        if (eval_d1.empty()) break;

        // Depth 1 후보들을 비용 오름차순으로 정렬
        std::sort(eval_d1.begin(), eval_d1.end(), [](const Cand1& a, const Cand1& b) {
            return a.c1 < b.c1;
        });

        // 가지치기 임계값 (base 10^12 대응)
        long long prune_thresh_d1 = 1500000000000LL;
        long long best_total_score = LLONG_MAX;
        std::pair<int, int> best_root_swap = eval_d1[0].swap;

        int max_beam_d1 = 3;
        int expanded_d1 = 0;

        for (const auto& d1 : eval_d1) {
            if (d1.c1 > min_c1 + prune_thresh_d1) break;
            if (expanded_d1 >= max_beam_d1) break;
            expanded_d1++;

            // Depth 1 가상 적용
            std::vector<int> l2p_1 = aq.l2p;
            std::vector<int> p2l_1 = aq.p2l;
            int p1 = d1.swap.first, p2 = d1.swap.second;
            int q1 = p2l_1[p1], q2 = p2l_1[p2];
            if (q1 != -1) l2p_1[q1] = p2;
            if (q2 != -1) l2p_1[q2] = p1;
            p2l_1[p1] = q2;
            p2l_1[p2] = q1;

            // Depth 2 후보 생성
            std::vector<std::pair<int, int>> candi_d2;
            for (int gid : front_layer) {
                int c = two_q_gates[gid].first, t = two_q_gates[gid].second;
                int pc = l2p_1[c], pt = l2p_1[t];
                for (int p : { pc, pt }) {
                    for (int nxt : graph.adj[p]) {
                        int u = std::min(p, nxt), v = std::max(p, nxt);
                        if (std::make_pair(u, v) == d1.swap) continue;
                        bool exists = false;
                        for (const auto& pr : candi_d2) {
                            if (pr.first == u && pr.second == v) { exists = true; break; }
                        }
                        if (!exists) candi_d2.push_back({ u, v });
                    }
                }
            }

            if (candi_d2.empty()) {
                if (d1.c1 < best_total_score) {
                    best_total_score = d1.c1;
                    best_root_swap = d1.swap;
                }
                continue;
            }

            struct Cand2 {
                std::pair<int, int> swap;
                long long c2;
            };
            std::vector<Cand2> eval_d2;
            long long min_c2 = LLONG_MAX;

            for (const auto& pr2 : candi_d2) {
                long long c2 = eval_swap(l2p_1, pr2.first, pr2.second, 1);
                eval_d2.push_back({ pr2, c2 });
                if (c2 < min_c2) min_c2 = c2;
            }

            if (eval_d2.empty()) {
                if (d1.c1 < best_total_score) {
                    best_total_score = d1.c1;
                    best_root_swap = d1.swap;
                }
                continue;
            }

            std::sort(eval_d2.begin(), eval_d2.end(), [](const Cand2& a, const Cand2& b) {
                return a.c2 < b.c2;
            });

            long long prune_thresh_d2 = 1000000000000LL;
            int max_beam_d2 = 2;
            int expanded_d2 = 0;

            for (const auto& d2 : eval_d2) {
                if (d2.c2 > min_c2 + prune_thresh_d2) break;
                if (expanded_d2 >= max_beam_d2) break;
                expanded_d2++;

                // Depth 2 가상 적용
                std::vector<int> l2p_2 = l2p_1;
                std::vector<int> p2l_2 = p2l_1;
                int p2_1 = d2.swap.first, p2_2 = d2.swap.second;
                int q2_1 = p2l_2[p2_1], q2_2 = p2l_2[p2_2];
                if (q2_1 != -1) l2p_2[q2_1] = p2_2;
                if (q2_2 != -1) l2p_2[q2_2] = p2_1;
                p2l_2[p2_1] = q2_2;
                p2l_2[p2_2] = q2_1;

                // Depth 3 평가
                std::vector<std::pair<int, int>> candi_d3;
                for (int gid : front_layer) {
                    int c = two_q_gates[gid].first, t = two_q_gates[gid].second;
                    int pc = l2p_2[c], pt = l2p_2[t];
                    for (int p : { pc, pt }) {
                        for (int nxt : graph.adj[p]) {
                            int u = std::min(p, nxt), v = std::max(p, nxt);
                            if (std::make_pair(u, v) == d2.swap) continue;
                            bool exists = false;
                            for (const auto& pr : candi_d3) {
                                if (pr.first == u && pr.second == v) { exists = true; break; }
                            }
                            if (!exists) candi_d3.push_back({ u, v });
                        }
                    }
                }

                long long min_c3 = 0;
                bool has_d3 = false;
                for (const auto& pr3 : candi_d3) {
                    long long c3 = eval_swap(l2p_2, pr3.first, pr3.second, 2);
                    if (!has_d3 || c3 < min_c3) {
                        min_c3 = c3;
                        has_d3 = true;
                    }
                }

                long long total_path_score = d1.c1 + d2.c2 + (has_d3 ? min_c3 : 0);
                if (total_path_score < best_total_score) {
                    best_total_score = total_path_score;
                    best_root_swap = d1.swap;
                }
            }
        }

        std::pair<int, int> best_swap = best_root_swap;

        // (E) 최적 SWAP 실행 및 레이아웃 갱신
        if (best_swap.first != -1) {
            int p1 = best_swap.first;
            int p2 = best_swap.second;
            int q1 = aq.p2l[p1];
            int q2 = aq.p2l[p2];

            if (q1 != -1) aq.l2p[q1] = p2;
            if (q2 != -1) aq.l2p[q2] = p1;
            aq.p2l[p1] = q2;
            aq.p2l[p2] = q1;

            total_swapped_list.push_back({ p1, p2 });
            if (record_events) events.push_back({'S', p1, p2});
            decay[p1] += 0.5;
            decay[p2] += 0.5;

            // 사용자 지정 Slack 미루기(Deferral) 및 W_{ij} /= 2 갱신:
            // 이번 스왑으로 혜택을 받지 못하고 1턴 지연된 non-critical(Slack > 0) 게이트는 W /= 2 반영!
            for (int fg : front_layer) {
                int c = two_q_gates[fg].first;
                int t = two_q_gates[fg].second;
                int pc = aq.l2p[c], pt = aq.l2p[t];
                // 이번 스왑과 무관하게 자리를 지킨 게이트 중 여유(Slack > 0)가 남아있는 게이트
                if (pc != p1 && pc != p2 && pt != p1 && pt != p2) {
                    if (slack[fg] - defer_count[fg] > 0) {
                        defer_count[fg]++; // W_{ij} /= 2 및 Slack 1소진!
                    }
                }
            }
        } else {
            break;
        }
    }

    if (record_events && num_executed != num_2q) {
        throw std::runtime_error("Router stopped before executing all CX gates");
    }
    excess_deferral_cost = 0;
    for (int i = 0; i < num_2q; i++) {
        if (slack[i] > 0 && defer_count[i] > slack[i]) {
            excess_deferral_cost += (long long)(defer_count[i] - slack[i]);
        }
    }
    return total_swapped_list;
}
