#pragma once
#include <vector>

class Mapper {
	friend class Router;
	// 하드웨어 거리 행렬(D)과 회로 상호작용 행렬(W)
	const std::vector<std::vector<int>>& distance;				// 물리 큐비트 거리 행렬
	std::vector<std::vector<unsigned long long>>& weight;		// 가상 큐비트 가중치 행렬

	// 큐비트 총 개수 (Logical / Physical)
	const int num_lq;											// 총 논리 큐비트 갯수
	const int num_pq;											// 총 물리 큐비트 갯수

	// 사전 계산된 정적 지표 (Importance / Centrality)
	std::vector<unsigned long long> importance;					// 논리 큐비트의 중요도(~가중치, 64비트 정수)
	std::vector<int> centrality;								// 물리 큐비트의 중심도(~거리)

	// 양방향 매핑 테이블 (l2p[lq] = pq, p2l[pq] = lq)
	std::vector<int> p2l;										// 물리 큐비트에 대응되는 논리 큐비트 (~p2l[pq]=lq)
	std::vector<int> l2p;										// 논리 큐비트에 대응되는 물리 큐비트 (~l2p[lq]=pq)

	// 내부 탐색 메서드
	unsigned long long getAffinity(int unmapped_lq) const;		// 논리 큐비트의 친밀도(~가중치)
	unsigned long long getCost(int unmapped_pq, int best_lq) const;	// 최적화될 목적 함수(~가중치, ~거리)
	int getBestQ() const;										// max affinity, tie-breaker max importance
	int getBestP(int best_lq) const;							// min cost, tie-breaker min centrality
	int getFirstQ() const;										// max importance
	int getFirstP() const;										// min centrality

	void push(int best_lq, int best_pq);
public:
	Mapper(const std::vector<std::vector<int>>& distance, std::vector<std::vector<unsigned long long>>& weight);
	
	// mapper 실행
	std::vector<int> go();										// result[lq] = pq (Index: Logical, Value: Physical)
	void setLayout(const std::vector<int>& new_l2p, const std::vector<int>& new_p2l) {
		l2p = new_l2p;
		p2l = new_p2l;
	}
	void swapP(int p1, int p2) {
		int q1 = p2l[p1];
		int q2 = p2l[p2];
		if (q1 != -1) l2p[q1] = p2;
		if (q2 != -1) l2p[q2] = p1;
		p2l[p1] = q2;
		p2l[p2] = q1;
	}
	const std::vector<int>& getL2P() const { return l2p; }
	const std::vector<int>& getP2L() const { return p2l; }
};
