#pragma once
#include <vector>
#include <queue>

class Graph {
public:
    const int num_pq;
    std::vector<std::vector<int>> adj;

    // 생성자
    Graph(const std::vector<std::vector<int>>& adj) : num_pq((int)adj.size()), adj(adj) {}
    
    int getNumPq() const { return num_pq; }
    const std::vector<std::vector<int>>& getAdj() const { return adj; }

    // 거리 행렬을 리턴하는 함수
    std::vector<std::vector<int>> getDistance() const {
        std::vector<std::vector<int>> dist(num_pq, std::vector<int>(num_pq, -1));
        for (int i = 0; i < num_pq; i++) {
            std::queue<int> q;
            dist[i][i] = 0;
            q.push(i);

            while (!q.empty()) {
                int v = q.front();
                q.pop();

                for (const int w : adj[v]) {
                    if (dist[i][w] != -1) continue;
                    dist[i][w] = dist[i][v] + 1;
                    q.push(w);
                }
            }
        }
        return dist;
    }
};
