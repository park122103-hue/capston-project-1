#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

struct Gate {
    std::string type;
    int q0;
    int q1;
    double param;
    Gate(const std::string& t, int a, int b, double p = 0.0)
        : type(t), q0(a), q1(b), param(p) {}
};

class Circuits {
    const int num_lq;
    std::vector<Gate> gates;
    bool verbose;
public:
    Circuits(int num_lq, bool verbose = false) : num_lq(num_lq), verbose(verbose) {}

    int getNumLq() const { return num_lq; }

    void h(int target) {
        if (target >= 0 && target < num_lq) {
            gates.push_back(Gate("h", -1, target));
            if (verbose) std::cout << "execute | h q[" << target << "] <-- success\n";
        } else if (verbose) {
            std::cout << "fail\n";
        }
    }

    void cx(int control, int target) {
        if (target >= 0 && control >= 0 && target < num_lq && control < num_lq && target != control) {
            gates.push_back(Gate("cx", control, target));
            if (verbose) std::cout << "execute | cx q[" << control << "] q[" << target << "] <-- success\n";
        } else if (verbose) {
            std::cout << "fail\n";
        }
    }

    void print() const {
        std::cout << "circuit: \n";
        for (int i = 0; i < num_lq; i++) {
            std::cout << 'q' << i << " | ";
            for (const Gate& g : gates) {
                if (g.q0 == -1) {
                    if (g.q1 == i)
                        std::cout << g.type[0] << ' ';
                    else
                        std::cout << "- ";
                }
                else {
                    if (g.q1 == i)
                        std::cout << "x ";
                    else if (g.q0 == i)
                        std::cout << g.type[0] << ' ';
                    else
                        std::cout << "- ";
                }
            }
            std::cout << std::endl;
        }
    }

    // CX-only dependency layer with first eligible interactions at layer zero.
    std::vector<int> cxLayers() const {
        std::vector<int> last_layer(num_lq, -1);
        std::vector<int> layers;
        for (const auto& g : gates) {
            if (g.q0 == -1) continue;
            int layer = 1 + std::max(last_layer[g.q0], last_layer[g.q1]);
            layers.push_back(layer);
            last_layer[g.q0] = layer;
            last_layer[g.q1] = layer;
        }
        return layers;
    }

    std::vector<std::vector<unsigned long long>> getWeight() const {
        std::vector<std::vector<unsigned long long>> weight(num_lq, std::vector<unsigned long long>(num_lq, 0ULL));
        
        auto layers = cxLayers();
        // alpha = 0.8 지수 감쇠 테이블 (base 10^12)
        static const unsigned long long POW_08_INIT[60] = {
            1000000000000ULL, 800000000000ULL, 640000000000ULL, 512000000000ULL, 409600000000ULL, 327680000000ULL,
            262144000000ULL, 209715200000ULL, 167772160000ULL, 134217728000ULL, 107374182400ULL, 85899345920ULL,
            68719476736ULL, 54975581388ULL, 43980465111ULL, 35184372088ULL, 28147497671ULL, 22517998136ULL,
            18014398509ULL, 14411518807ULL, 11529215046ULL, 9223372036ULL, 7378697629ULL, 5902958103ULL,
            4722366482ULL, 3777893186ULL, 3022314549ULL, 2417851639ULL, 1934281311ULL, 1547425049ULL,
            1237940039ULL, 990352031ULL, 792281625ULL, 633825300ULL, 507060240ULL, 405648192ULL,
            324518553ULL, 259614842ULL, 207691874ULL, 166153499ULL, 132922799ULL, 106338239ULL,
            85070591ULL, 68056473ULL, 54445178ULL, 43556142ULL, 34844914ULL, 27875931ULL,
            22300745ULL, 17840596ULL, 14272476ULL, 11417981ULL, 9134385ULL, 7307508ULL,
            5846006ULL, 4676805ULL, 3741444ULL, 2993155ULL, 2394524ULL, 1915619ULL,
        };

        size_t i = 0;
        for (const auto& g : gates) {
            if (g.q0 == -1) continue;
            int layer = layers[i++];
            if (layer < 60) {
                weight[g.q0][g.q1] += POW_08_INIT[layer];
                weight[g.q1][g.q0] += POW_08_INIT[layer];
            }
        }
        return weight;
    }

    const std::vector<Gate>& getGates() const {
        return gates;
    }
};
