#pragma once
#include <vector>
#include <iostream>
#include "Circuit.h"
#include "Graph.h"
#include "Mapper.h"

struct RouteEvent {
    // G = direct CX by gate ID, B = bridge by gate ID, S = physical SWAP.
    char type;
    int first;
    int second = -1;
};

class Router {
    const Circuits circ;
    const Graph graph;
    Mapper aq;
    std::vector<std::pair<int, int>> total_swapped_list;
    double b_param;
    double alpha_r;
    bool record_events;
    bool allow_bridge;
    std::vector<RouteEvent> events;
    long long excess_deferral_cost; // 비임계 게이트 지연 초과 누적 코스트

public:
    Router(const Circuits& circ, const Graph& graph, const Mapper& mapper_state,
           double b = 1.0, double alpha = 0.8, bool trace = false, bool bridge = true);

    // 전체 회로 DAG Front Layer 라우팅 실행
    std::vector<std::pair<int, int>> run();

    const std::vector<RouteEvent>& getEvents() const { return events; }
    const std::vector<int>& getL2P() const { return aq.l2p; }
    const std::vector<int>& getP2L() const { return aq.p2l; }
    const std::vector<std::pair<int, int>>& getSwaps() const { return total_swapped_list; }
    long long getExcessDeferralCost() const { return excess_deferral_cost; }
    void circ_print() const { circ.print(); }
};
