#include "Circuit.h"
#include "Graph.h"
#include "Mapper.h"
#include "Router.h"

#include <chrono>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>

using Clock = std::chrono::steady_clock;
using Weight = std::vector<std::vector<unsigned long long>>;
constexpr unsigned long long scale = 1'000'000'000'000ULL;

auto elapsed_ns(Clock::time_point started) {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - started).count();
}

double read_alpha(const char* field) {
    std::size_t end = 0;
    double value = std::stod(field, &end);
    if (end != std::string(field).size() || !(value > 0.0 && value <= 1.0)) {
        throw std::runtime_error("Alpha must be in (0, 1]");
    }
    return value;
}

auto read_pair(int width) {
    int a = -1, b = -1;
    if (!(std::cin >> a >> b) || a < 0 || a >= width || b < 0 || b >= width || a == b) {
        throw std::runtime_error("Invalid gate or edge endpoints");
    }
    return std::make_pair(a, b);
}

Weight build_weight(const Circuits& circuit, const std::string& mode, double alpha) {
    if (mode == "member") {
        if (alpha != 0.8) throw std::runtime_error("The member profile uses alpha_M=0.8");
        return circuit.getWeight();
    }
    const bool by_layer = mode == "layer" || mode == "normalized-layer";
    const bool normalized = mode == "normalized-layer" || mode == "normalized-index";
    if (!by_layer && !normalized && mode != "uniform" && mode != "index") {
        throw std::runtime_error("Unknown weight profile");
    }

    const auto& gates = circuit.getGates(); // This driver accepts only CX.
    const int width = circuit.getNumLq();
    Weight weight(width, std::vector<unsigned long long>(width, 0ULL));
    const auto layers = by_layer ? circuit.cxLayers() : std::vector<int>{};
    int denominator = 1;
    if (normalized && !gates.empty()) {
        denominator = std::max(1, by_layer ? *std::max_element(layers.begin(), layers.end())
                                            : static_cast<int>(gates.size()) - 1);
    }
    for (std::size_t id = 0; id < gates.size(); ++id) {
        const auto& gate = gates[id];
        const double lag = by_layer ? layers[id] : static_cast<double>(id);
        const auto entry = mode == "uniform" || alpha == 1.0
                               ? scale
                               : static_cast<unsigned long long>(std::llround(scale * std::pow(alpha, lag / denominator)));
        weight[gate.q0][gate.q1] += entry;
        weight[gate.q1][gate.q0] += entry;
    }
    return weight;
}

void print_layout(const char* label, const std::vector<int>& layout) {
    std::cout << label;
    for (int p : layout) std::cout << ' ' << p;
    std::cout << '\n';
}

template <class T>
void print_matrix(const char* label, const std::vector<std::vector<T>>& matrix) {
    for (const auto& row : matrix) {
        std::cout << label;
        for (auto entry : row) std::cout << ' ' << entry;
        std::cout << '\n';
    }
}

int main(int argc, char** argv) {
    try {
        if (argc != 6) {
            throw std::runtime_error("usage: research map|route|compile PROFILE ALPHA_M ALPHA_R dump|default|no-bridge");
        }
        const std::string command = argv[1], profile = argv[2], option = argv[5];
        if ((command != "map" && command != "route" && command != "compile") ||
            (option != "default" && option != "dump" && option != "no-bridge")) {
            throw std::runtime_error("Invalid command or option");
        }
        const auto alpha_m = read_alpha(argv[3]), alpha_r = read_alpha(argv[4]);
        int logical = 0, physical = 0, gates = 0, edge_count = 0;
        if (!(std::cin >> logical >> physical >> gates >> edge_count) ||
            logical < 1 || physical < logical || physical > 64 || gates < 0 || edge_count < 0 ||
            static_cast<unsigned long long>(gates) >
                std::numeric_limits<unsigned long long>::max() / scale / std::max(1, physical - 1)) {
            throw std::runtime_error("Invalid problem size or fixed-point cost range");
        }
        Circuits circuit(logical);
        for (int i = 0; i < gates; ++i) {
            auto [a, b] = read_pair(logical);
            circuit.cx(a, b);
        }
        std::vector<std::vector<int>> neighbors(physical);
        for (int i = 0; i < edge_count; ++i) {
            auto [a, b] = read_pair(physical);
            if (std::find(neighbors[a].begin(), neighbors[a].end(), b) != neighbors[a].end()) {
                throw std::runtime_error("Supply each undirected edge once");
            }
            neighbors[a].push_back(b);
            neighbors[b].push_back(a);
        }

        auto started = Clock::now();
        Graph graph(neighbors);
        auto distance = graph.getDistance();
        const auto graph_ns = elapsed_ns(started);
        if (std::find(distance[0].begin(), distance[0].end(), -1) != distance[0].end()) {
            throw std::runtime_error("The topology must be connected");
        }
        started = Clock::now();
        auto weight = command == "route" ? Weight(logical, std::vector<unsigned long long>(logical))
                                          : build_weight(circuit, profile, alpha_m);
        const auto weight_ns = elapsed_ns(started);
        started = Clock::now();
        Mapper mapper(distance, weight);
        std::vector<int> initial;
        if (command == "route") {
            initial.resize(logical);
            std::vector<int> inverse(physical, -1);
            for (int q = 0; q < logical; ++q) {
                int p = -1;
                if (!(std::cin >> p) || p < 0 || p >= physical || inverse[p] != -1) {
                    throw std::runtime_error("Invalid initial layout");
                }
                initial[q] = p;
                inverse[p] = q;
            }
            mapper.setLayout(initial, inverse);
        } else {
            initial = mapper.go();
        }
        const auto greedy_ns = elapsed_ns(started);

        print_layout("initial", initial);
        std::cout << "graph_ns " << graph_ns << "\nweight_ns " << weight_ns
                  << "\ngreedy_ns " << greedy_ns << '\n';
        if (option == "dump") {
            print_matrix("W", weight);
            print_matrix("D", distance);
            print_layout("cx_layers", circuit.cxLayers());
        }
        if (command != "map") {
            started = Clock::now();
            Router router(circuit, graph, mapper, 0.0, alpha_r, true, option != "no-bridge");
            router.run();
            const auto router_ns = elapsed_ns(started);
            print_layout("final", router.getL2P());
            std::cout << "route_ns " << router_ns << '\n';
            for (const auto& event : router.getEvents()) {
                std::cout << event.type << ' ' << event.first;
                if (event.type == 'S') std::cout << ' ' << event.second;
                std::cout << '\n';
            }
        }
    } catch (const std::exception& failure) {
        std::cerr << failure.what() << '\n';
        return 1;
    }
}
