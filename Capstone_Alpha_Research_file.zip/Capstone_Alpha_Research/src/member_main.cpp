#include <iostream>
#include <vector>
#include <chrono>
#include <string>
#include "Circuit.h"
#include "Graph.h"
#include "Mapper.h"
#include "Router.h"

using namespace std;

void print(const vector<int>& v) {
    cout << "f : ";
    for (int x : v) cout << x << ' ';
    cout << endl;
}

void print(const vector<vector<int>>& v) {
    cout << "matrix: \n";
    for (const vector<int>& i : v) {
        for (int j : i) {
            cout << j << ' ';
        }
        cout << endl;
    }
}

void print(const vector<vector<unsigned long long>>& v) {
    cout << "matrix: \n";
    for (const vector<unsigned long long>& i : v) {
        for (unsigned long long j : i) {
            cout << j << ' ';
        }
        cout << endl;
    }
}

void print(const vector<pair<int, int>>& v) {
    cout << "overhead: \n";
    for (const pair<int, int>& i : v) {
        cout << "SWAP " << i.first << ", " << i.second << endl;
    }
}

vector<vector<int>> getAdj(const vector<pair<int, int>>& edge, int num_pq) {
    vector<vector<int>> adj(num_pq);
    for (const pair<int, int>& e : edge) {
        bool fwd = false, bwd = false;
        for (int x : adj[e.first]) if (x == e.second) { fwd = true; break; }
        for (int x : adj[e.second]) if (x == e.first) { bwd = true; break; }
        if (!fwd) adj[e.first].push_back(e.second);
        if (!bwd) adj[e.second].push_back(e.first);
    }
    return adj;
}

int main(int argc, char* argv[]) {
    // 벤치마크 모드 (--benchmark 또는 --pipe)
    if (argc > 1 && string(argv[1]) == "--benchmark") {
        int num_lq, num_pq, num_gates, num_edges;
        if (!(cin >> num_lq >> num_pq >> num_gates >> num_edges)) {
            cerr << "Invalid input format\n";
            return 1;
        }

        Circuits circ(num_lq, false);
        for (int i = 0; i < num_gates; i++) {
            int c, t;
            cin >> c >> t;
            circ.cx(c, t);
        }

        vector<pair<int, int>> edges;
        for (int i = 0; i < num_edges; i++) {
            int u, v;
            cin >> u >> v;
            edges.push_back({u, v});
        }

        vector<vector<int>> adj = getAdj(edges, num_pq);
        Graph graph(adj);

        // 거리 행렬 계산
        vector<vector<int>> dist = graph.getDistance();
        // 가중치 행렬 계산
        vector<vector<unsigned long long>> weight = circ.getWeight();

        // 1. 초기 매핑 시간 측정
        auto t_start_map = chrono::high_resolution_clock::now();
        Mapper aq(dist, weight);
        vector<int> initial_layout = aq.go();
        auto t_end_map = chrono::high_resolution_clock::now();
        long long map_us = chrono::duration_cast<chrono::microseconds>(t_end_map - t_start_map).count();

        // 2. 라우팅 (Bidirectional Forward-Backward Pass / 역전파 Post-Optimization)
        auto t_start_route = chrono::high_resolution_clock::now();

        // 역방향 회로 생성
        Circuits circ_bwd(num_lq);
        const auto& all_gates = circ.getGates();
        for (int i = (int)all_gates.size() - 1; i >= 0; i--) {
            if (all_gates[i].q0 != -1) {
                circ_bwd.cx(all_gates[i].q0, all_gates[i].q1);
            }
        }

        // =========================================================================
        // Pass 0: 순수 위상 기준선 (b = 0.0) - z4_268 219 SWAP 등 최고 성능 기준선 확보
        // =========================================================================
        vector<int> initial_p2l = aq.getP2L();
        aq.setLayout(initial_layout, initial_p2l);
        Router r_fwd0(circ, graph, aq, 0.0);
        vector<pair<int, int>> sw0 = r_fwd0.run();

        vector<pair<int, int>> best_swaps = sw0;
        vector<int> best_final_layout = r_fwd0.getL2P();
        vector<int> best_final_p2l = r_fwd0.getP2L();
        vector<int> best_initial_layout = initial_layout;

        // =========================================================================
        // Stage 1: 3회 순방향(Forward) 피드백 적응형 b 수렴 탐색
        // 코스트(비임계 게이트 지연 초과량)가 크면 b를 낮추고, 작으면 b를 높여 수렴
        // =========================================================================
        double b_history[3] = { 0.2, 0.5, 1.0 };
        int swaps_history[3] = { (int)sw0.size(), 0, 0 };
        long long cost_history[3] = { r_fwd0.getExcessDeferralCost(), 0, 0 };

        // 1차 순방향 라우팅 (b = 0.2 탐색)
        aq.setLayout(initial_layout, initial_p2l);
        Router r_fwd1(circ, graph, aq, b_history[0]);
        vector<pair<int, int>> sw1 = r_fwd1.run();
        swaps_history[0] = (int)sw1.size();
        cost_history[0] = r_fwd1.getExcessDeferralCost();

        if (sw1.size() < best_swaps.size()) {
            best_swaps = sw1;
            best_final_layout = r_fwd1.getL2P();
            best_final_p2l = r_fwd1.getP2L();
        }

        if (!best_swaps.empty()) {
            // 비임계 게이트 지연율 평가: 게이트당 평균 지연 초과량
            double avg_excess1 = (double)cost_history[0] / (double)std::max(1, num_gates);

            // 비임계 게이트가 너무 밀려 코스트가 크면 b를 낮추고, 여유가 있으면 b를 높임
            if (avg_excess1 > 0.4) {
                b_history[1] = 0.2; // 비임계 게이트 적극 우대 (b 낮춤)
            } else if (avg_excess1 < 0.05) {
                b_history[1] = 2.0; // 임계 게이트 적극 우대 (b 높임)
            } else {
                b_history[1] = 0.5; // 균형 조절
            }

            // 2차 순방향 라우팅
            aq.setLayout(initial_layout, initial_p2l);
            Router r_fwd2(circ, graph, aq, b_history[1]);
            vector<pair<int, int>> sw2 = r_fwd2.run();
            swaps_history[1] = (int)sw2.size();
            cost_history[1] = r_fwd2.getExcessDeferralCost();

            if (sw2.size() < best_swaps.size()) {
                best_swaps = sw2;
                best_final_layout = r_fwd2.getL2P();
                best_final_p2l = r_fwd2.getP2L();
            }

            // 3차 순방향 라우팅: 1차와 2차의 성적을 비교하여 수렴점 도출
            if (swaps_history[1] < swaps_history[0]) {
                if (b_history[1] < b_history[0]) {
                    b_history[2] = std::max(0.0, b_history[1] * 0.5);
                } else {
                    b_history[2] = b_history[1] * 1.5;
                }
            } else {
                b_history[2] = (b_history[0] + b_history[1]) / 2.0;
            }

            aq.setLayout(initial_layout, initial_p2l);
            Router r_fwd3(circ, graph, aq, b_history[2]);
            vector<pair<int, int>> sw3 = r_fwd3.run();
            swaps_history[2] = (int)sw3.size();
            cost_history[2] = r_fwd3.getExcessDeferralCost();

            if (sw3.size() < best_swaps.size()) {
                best_swaps = sw3;
                best_final_layout = r_fwd3.getL2P();
                best_final_p2l = r_fwd3.getP2L();
            }

            // 3회 순방향 결과 중 SWAP이 최소인 최적의 수렴 b* 확정
            double b_star = b_history[0];
            int min_sw = swaps_history[0];
            for (int i = 1; i < 3; i++) {
                if (swaps_history[i] < min_sw) {
                    min_sw = swaps_history[i];
                    b_star = b_history[i];
                }
            }

            // =========================================================================
            // Stage 2: 수렴된 b*를 기반으로 7회 순방향+역방향 양방향 라우팅 매핑 최적화
            // =========================================================================
            aq.setLayout(best_final_layout, best_final_p2l);

            for (int r = 0; r < 7; r++) {
                // 수렴된 b*를 중심으로 미세 조율
                double cur_b = b_star;
                if (r == 1) cur_b = b_star * 0.8;
                else if (r == 2) cur_b = b_star * 1.2;
                else if (r == 3) cur_b = std::max(0.0, b_star - 0.2);
                else if (r == 4) cur_b = b_star + 0.2;

                // 1) Backward pass: 끝에서 시작으로 역방향 라우팅하여 초기 배치 역전파 갱신
                Router r_bwd(circ_bwd, graph, aq, cur_b);
                r_bwd.run();
                vector<int> refined_init_l2p = r_bwd.getL2P();
                vector<int> refined_init_p2l = r_bwd.getP2L();

                // 2) Forward pass: 역전파된 초기 배치에서 순방향 라우팅 재실행
                aq.setLayout(refined_init_l2p, refined_init_p2l);
                Router r_fwd(circ, graph, aq, cur_b);
                vector<pair<int, int>> cur_swaps = r_fwd.run();

                if (cur_swaps.size() < best_swaps.size()) {
                    best_swaps = cur_swaps;
                    best_final_layout = r_fwd.getL2P();
                    best_final_p2l = r_fwd.getP2L();
                    best_initial_layout = refined_init_l2p;
                }
                // 다음 라운드를 위해 현재 순방향의 끝 배치를 역방향 출발점으로 갱신 (탐색 다양성 확보)
                aq.setLayout(r_fwd.getL2P(), r_fwd.getP2L());
            }
        }

        auto t_end_route = chrono::high_resolution_clock::now();
        long long route_us = chrono::duration_cast<chrono::microseconds>(t_end_route - t_start_route).count();

        vector<pair<int, int>> swaps = best_swaps;
        vector<int> final_layout = best_final_layout;
        initial_layout = best_initial_layout;

        // 결과 출력 (파이썬 자동 파싱용)
        cout << "initial_layout";
        for (int p : initial_layout) cout << " " << p;
        cout << "\n";

        cout << "final_layout";
        for (int p : final_layout) cout << " " << p;
        cout << "\n";

        cout << "swaps_count " << swaps.size() << "\n";
        cout << "time_map_us " << map_us << "\n";
        cout << "time_route_us " << route_us << "\n";

        cout << "swaps_list";
        for (const auto& sw : swaps) cout << " " << sw.first << "," << sw.second;
        cout << "\n";

        return 0;
    }

    // 기본 테스트 모드
    vector<pair<int, int>> edge = {
        { 0, 1 }, { 1, 0 },
        { 1, 2 }, { 2, 1 },
        { 2, 3 }, { 3, 2 },
        { 3, 4 }, { 4, 3 }
    };

    vector<vector<int>> adj = getAdj(edge, 5);
    Graph graph(adj);
    vector<vector<int>> dist(graph.getDistance());
    print(dist);
    cout << std::endl;

    Circuits circ(4, true);
    for (int i = 0; i < 7; i++) circ.cx(0, 1);
    for (int i = 0; i < 4; i++) circ.cx(0, 2);
    circ.cx(1, 2);
    for (int i = 0; i < 2; i++) circ.cx(1, 3);
    cout << std::endl;

    circ.print();
    cout << std::endl;

    vector<vector<unsigned long long>> weight(circ.getWeight());
    print(weight);
    cout << std::endl;

    Mapper aq(dist, weight);
    vector<int> f(aq.go());
    print(f);

    Router route(circ, graph, aq);
    vector<pair<int, int>> total_swapped_list = route.run();
    f = route.getL2P();
    print(f);
    print(total_swapped_list);

    return 0;
}
