#include <vector>
#include "Mapper.h"

using namespace std;

// ***** 초기 세팅 ******
Mapper::Mapper(const vector<vector<int>>& distance, vector<vector<unsigned long long>>& weight)
	: distance(distance), weight(weight), num_lq((int)weight.size()), num_pq((int)distance.size()), p2l(num_pq, -1), l2p(num_lq, -1) {
	// 1. 논리 큐비트 중요도(W 합 - 64비트 정수)
	for (int qs = 0; qs < num_lq; qs++) {
		unsigned long long result = 0ULL;
		for (int qt = 0; qt < num_lq; qt++) result += weight[qs][qt];
		importance.push_back(result);
	}
	// 2. 물리 큐비트 중심도 (D 합 - 작을수록 중앙!)
	for (int ps = 0; ps < num_pq; ps++) {
		int result = 0;
		for (int pt = 0; pt < num_pq; pt++) result += distance[ps][pt];
		centrality.push_back(result);
	}
}

// ***** 큐비트 뽑기 기준 *****
// A(unmapped_lq) : 모든 mapped_lq에 대해 unmapped_lq와 mapped_lq 사이의 W의 합
unsigned long long Mapper::getAffinity(int unmapped_lq) const {
	unsigned long long result = 0ULL;
	for (int mapped_lq = 0; mapped_lq < num_lq; mapped_lq++) {
		if (l2p[mapped_lq] != -1) {
			result += weight[unmapped_lq][mapped_lq];
		}
	}
	return result;
}

// C(unmapped_pq, best_lq) : D(unmapped_pq, l2p[mapped_lq]) * W(best_lq, mapped_lq)
unsigned long long Mapper::getCost(int unmapped_pq, int best_lq) const {
	unsigned long long result = 0ULL;
	for (int mapped_lq = 0; mapped_lq < num_lq; mapped_lq++) {
		if (l2p[mapped_lq] != -1) {
			result += (unsigned long long)distance[unmapped_pq][l2p[mapped_lq]] * weight[best_lq][mapped_lq];
		}
	}
	return result;
}

// ***** 큐비트 뽑기 *****
// 아직 짝지어지지 않은 논리 큐비트 중 affinity가 가장 큰 큐비트
int Mapper::getBestQ() const {
	int qstar = -1;
	unsigned long long maxaff = 0ULL;
	for (int unmapped_qt = 0; unmapped_qt < num_lq; unmapped_qt++) {
		if (l2p[unmapped_qt] != -1) continue;
		unsigned long long aff = getAffinity(unmapped_qt);
		if (qstar == -1 || aff > maxaff) {
			qstar = unmapped_qt;
			maxaff = aff;
		}
		else if (aff == maxaff && importance[unmapped_qt] > importance[qstar]) {
			qstar = unmapped_qt;
			maxaff = aff;
		}
	}
	return qstar;
}

// 아직 짝지어지지 않은 물리 큐비트 중 cost가 가장 작은 노드
int Mapper::getBestP(int best_lq) const {
	int pstar = -1;
	unsigned long long mincost = ~0ULL;
	for (int unmapped_pt = 0; unmapped_pt < num_pq; unmapped_pt++) {
		if (p2l[unmapped_pt] != -1) continue;
		unsigned long long cost = getCost(unmapped_pt, best_lq);
		if (pstar == -1 || cost < mincost) {
			pstar = unmapped_pt;
			mincost = cost;
		}
		else if (cost == mincost && centrality[unmapped_pt] < centrality[pstar]) {
			pstar = unmapped_pt;
			mincost = cost;
		}
	}
	return pstar;
}

// ***** 초기 1순위 큐비트 선정 *****
int Mapper::getFirstQ() const {
	int result = -1;
	unsigned long long max_imp = 0ULL;
	for (int unmapped_lq = 0; unmapped_lq < num_lq; unmapped_lq++) {
		if (result == -1 || importance[unmapped_lq] > max_imp) {
			max_imp = importance[unmapped_lq];
			result = unmapped_lq;
		}
	}
	return result;
}

int Mapper::getFirstP() const {
	int result = -1;
	int min_center = -1;
	for (int unmapped_pq = 0; unmapped_pq < num_pq; unmapped_pq++) {
		if (min_center == -1 || centrality[unmapped_pq] < min_center) {
			min_center = centrality[unmapped_pq];
			result = unmapped_pq;
		}
	}
	return result;
}

// ***** 본체: 모든 논리 큐비트 순차 매핑 *****
vector<int> Mapper::go() {
	p2l.assign(num_pq, -1);
	l2p.assign(num_lq, -1);
	int first_lq = getFirstQ();
	int first_pq = getFirstP();
	if (first_lq != -1 && first_pq != -1) {
		push(first_lq, first_pq);
	}
	for (int i = 1; i < num_lq; i++) {
		int best_lq = getBestQ();
		if (best_lq == -1) break;
		int best_pq = getBestP(best_lq);
		if (best_pq == -1) break;
		push(best_lq, best_pq);
	}

	return l2p;
}

void Mapper::push(int best_lq, int best_pq) {
	p2l[best_pq] = best_lq;
	l2p[best_lq] = best_pq;
}
