import argparse
from collections import Counter
import csv
from dataclasses import asdict
import hashlib
import json
import platform
import random
import subprocess
from statistics import mean
import sys
from time import perf_counter_ns
from pathlib import Path

from qiskit import QuantumCircuit
import qiskit

from pipeline import (
    Arm, Compiled, Program, ROOT, SCALE, Topology, compile_program, load_qasm,
    lower_to_basis, normalize, qubit_ids, replay, run_engine, verify,
)
from summarize import case_averages, summarize, write_csv

E1 = Arm("E1", "sabre-fixed")
E3 = Arm("E3", "our")
MAPPING_GRID = {
    "layer": (0.8, 0.9, 0.95, 0.99),
    "normalized-layer": (0.2, 0.5, 0.8),
    "index": (0.8, 0.9, 0.95, 0.99),
    "normalized-index": (0.2, 0.5, 0.8),
}
ROUTING_GRID = (0.8, 0.9, 0.95, 0.99)
FIELDS = (
    "split", "topology", "benchmark", "logical_qubits", "physical_qubits",
    "input_cx", "arm", "profile", "router", "alpha_m", "alpha_r", "seed", "repeat",
    "status", "check", "error", "initial_layout", "final_layout",
    "swaps", "bridges", "cx", "added_cx", "depth", "cx_depth",
    "input_ms", "graph_ms", "weight_ms", "greedy_ms", "map_core_ms", "map_wall_ms",
    "route_ms", "native_wall_ms", "replay_ms", "basis_ms", "total_ms", "full_ms",
)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def cases():
    return read_json(ROOT / "config/cases.json")


def topology_data():
    records = read_json(ROOT / "config/topologies.json")
    return {
        name: Topology(entry["width"], tuple(tuple(edge) for edge in entry["edges"]))
        for name, entry in records.items()
    }


def verify_smoke(out, timeout):
    circuit = QuantumCircuit(4)
    for a, b in [(0, 1), (2, 3), (1, 2), (0, 1)]:
        circuit.cx(a, b)
    topology = Topology(5, ((0, 1), (1, 2), (2, 3), (3, 4)))
    program = Program(circuit)
    dumps = {}
    for mode, alpha in (("uniform", 1.0), ("layer", 1.0), ("layer", 0.8),
                        ("index", 0.8), ("normalized-layer", 0.8),
                        ("normalized-index", 1.0), ("member", 0.8)):
        key = f"{mode}_{alpha}"
        values, _ = run_engine(program, topology, Arm(key, "sabre-fixed", mode, alpha),
                               timeout, dump=True)
        dumps[key] = values
    u, layer = dumps["uniform_1.0"], dumps["layer_0.8"]
    assert u["cx_layers"] == [0, 0, 1, 2]
    assert u["D"] == [[abs(i-j) for j in range(5)] for i in range(5)]
    assert all(record["D"] == u["D"] for record in dumps.values())
    assert u["W"] == dumps["layer_1.0"]["W"] == dumps["normalized-index_1.0"]["W"]
    assert u["initial"] == dumps["layer_1.0"]["initial"] == dumps["normalized-index_1.0"]["initial"]
    assert layer["W"][0][1] == 1_640_000_000_000 and layer["W"][1][2] == 800_000_000_000
    assert layer["W"][2][3] == SCALE and layer["W"] == dumps["member_0.8"]["W"]
    assert dumps["index_0.8"]["W"][0][1] == 1_512_000_000_000
    assert dumps["normalized-layer_0.8"]["W"][0][1] == 1_800_000_000_000

    bridge_case = QuantumCircuit(3)
    bridge_case.sx(0)
    bridge_case.rz(0.3, 1)
    bridge_case.cx(0, 2)
    bridge_case.sx(1)
    topology = Topology(3, ((0, 1), (1, 2)))
    bridge_program = Program(bridge_case)
    native = replay(bridge_program, topology, [("B", 0)], [0, 1, 2])
    compiled = Compiled(native, lower_to_basis(native), [0, 1, 2], [0, 1, 2], {})
    result = verify(bridge_program, topology, compiled, set())
    assert (result["swaps"], result["bridges"], result["cx"]) == (0, 1, 4)
    write_json(out / "unit_checks.json", {
        "matrix_scale": SCALE, "matrix_checks": "PASS", "examples": dumps,
        "bridge_check": result,
    })


def fitting_arms():
    weights = [Arm(f"map_{mode}_{alpha}", "sabre-fixed", mode, alpha)
               for mode, grid in MAPPING_GRID.items() for alpha in grid]
    routers = [Arm(f"route_{alpha}", "our", alpha_r=alpha) for alpha in ROUTING_GRID]
    return [E1, E3, *weights, *routers]


def final_arms(selection):
    mapping = selection["mapping"]
    decay = mapping["profile"], mapping["alpha_m"]
    alpha_r = selection["routing"]["alpha_r"]
    diagnostics = [Arm(f"W_{mode.replace('-', '_')}", "sabre-fixed", mode, params["alpha_m"])
                   for mode, params in selection["mapping_by_profile"].items()]
    return [
        E1, Arm("E2", "sabre-fixed", *decay), E3,
        Arm("E4", "our", *decay), Arm("E5", "our", alpha_r=alpha_r),
        Arm("E6", "our", *decay, alpha_r),
        Arm("E7", "sabre-full"), Arm("E8", "sabre-layout"),
        Arm("Member_1pass", "our", "member", 0.8, 0.8),
        *diagnostics,
    ]


def select_parameters(arms, rows, args):
    values = case_averages(rows)
    trials = []
    for arm in arms:
        if arm.name in ("E1", "E3"):
            continue
        reference = "E3" if arm.router == "our" else "E1"
        case_keys = [key[:2] for key in values if key[2] == reference]
        scores = [(values.get((*case, arm.name), {}), values[(*case, reference)]) for case in case_keys]
        valid = [(a, b) for a, b in scores if "cx" in a and "cx" in b]
        trials.append({
            **asdict(arm), "baseline": reference, "cases": len(valid),
            "mean_delta_cx": mean(a["cx"]-b["cx"] for a, b in valid) if valid else None,
            "mean_delta_depth": mean(a["depth"]-b["depth"] for a, b in valid) if valid else None,
            "eligible": bool(valid) and len(valid) == len(case_keys),
        })
    with (args.out / "ranking.csv").open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=list(trials[0]))
        writer.writeheader()
        writer.writerows(trials)
    eligible = [r for r in trials if r["eligible"]]

    def pick(candidates):
        if not candidates:
            raise ValueError("A parameter group has no fully verified candidate. Inspect results.csv.")
        return min(candidates, key=lambda x: (x["mean_delta_cx"], x["mean_delta_depth"], x["name"]))

    mappings = [row for row in eligible if row["router"] == "sabre-fixed"]
    return {
        "mapping": pick(mappings),
        "mapping_by_profile": {mode: pick([r for r in mappings if r["profile"] == mode])
                               for mode in MAPPING_GRID},
        "routing": pick([r for r in eligible if r["router"] == "our"]),
        "protocol": {
            "fit_circuits": sorted({row["benchmark"] for row in rows}),
            "seeds": args.seeds, "swap_trials": args.swap_trials,
            "layout_trials": args.layout_trials, "allow_bridge": not args.no_bridge,
            "qiskit": qiskit.__version__,
        },
    }


def run_case(split, topology_name, name, topology, arms, args):
    qasm = ROOT / "benchmarks" / f"{name}.qasm"
    started = perf_counter_ns()
    program = Program(normalize(qasm))
    input_ms = (perf_counter_ns() - started) / 10**6
    if program.logical.num_qubits > topology.width:
        raise ValueError(f"{name}: QASM has more wires than {topology_name}")
    exact_cache = set()
    rows = []
    for seed in args.seeds:
        for repeat in range(-args.warmup, args.repeats):
            ordered = arms.copy()
            random.Random(f"{topology_name}/{name}/{seed}/{repeat}").shuffle(ordered)
            for arm in ordered:
                row = dict(
                    split=split, topology=topology_name, benchmark=name,
                    logical_qubits=program.logical.num_qubits, physical_qubits=topology.width,
                    input_cx=len(program.cx), arm=arm.name, profile=arm.profile,
                    router=arm.router, alpha_m=arm.alpha_m if arm.router in {"our", "sabre-fixed"} else "",
                    alpha_r=arm.alpha_r if arm.router == "our" else "",
                    seed=seed, repeat=repeat, input_ms=input_ms,
                )
                try:
                    compiled = compile_program(
                        program, topology, arm, seed, args.swap_trials,
                        args.layout_trials, args.timeout, not args.no_bridge,
                    )
                    if repeat < 0:
                        continue
                    metrics = verify(program, topology, compiled, exact_cache)
                    row.update(
                        status="PASS", **metrics, **compiled.times,
                        full_ms=compiled.times["total_ms"] + input_ms,
                        initial_layout=json.dumps(compiled.initial),
                        final_layout=json.dumps(compiled.claimed_final),
                    )
                except (RuntimeError, subprocess.TimeoutExpired, ValueError, KeyError) as failure:
                    if repeat < 0:
                        print(f"Warm-up failed ({arm.name}, {name}): {failure}", file=sys.stderr)
                        continue
                    row.update(status="FAIL", error=str(failure))
                rows.append(row)

    print(f"{split} {topology_name}/{name}: "
          f"{sum(row['status'] == 'PASS' for row in rows)}/{len(rows)} PASS", flush=True)
    return rows


def legacy_check(out, timeout):
    snapshot = topology_data()
    result = []
    for topology_name, label in (("tokyo20", "4gt13_92"), ("line5", "qe_qft_4"), ("tokyo20", "qft_13")):
        original = load_qasm(ROOT / "benchmarks" / f"{label}.qasm")
        topology = snapshot[topology_name]
        pairs = [qubit_ids(original, inst) for inst in original.data if inst.operation.name == "cx"]
        edges = [edge for a, b in topology.edges for edge in ((a, b), (b, a))]
        lines = [f"{original.num_qubits} {topology.width} {len(pairs)} {len(edges)}"]
        lines.extend(f"{a} {b}" for a, b in [*pairs, *edges])
        report = subprocess.run(
            [str(ROOT / "build/member"), "--benchmark"], input="\n".join(lines)+"\n",
            text=True, capture_output=True, check=True, timeout=timeout,
        ).stdout
        values = {key: parts for key, *parts in (line.split() for line in report.splitlines())}
        entries = [tuple(int(x) for x in pair.split(",")) for pair in values["swaps_list"]]
        assert len(entries) == int(values["swaps_count"][0])
        if topology_name == "tokyo20" and label == "4gt13_92":
            assert not entries, "Historical smoke reference expected zero routing actions"
        bridge = sum(a == -1 for a, b in entries)
        result.append(dict(
            topology=topology_name, benchmark=label, input_cx=len(pairs),
            member_reported_actions=len(entries), true_swaps=len(entries)-bridge, bridges=bridge,
            initial_layout=" ".join(values["initial_layout"]),
            final_layout=" ".join(values["final_layout"]),
        ))
    write_csv(out / "member_smoke.csv", result)
    print("Original benchmark entry point: 3/3 smoke checks passed")


def main():
    parser = argparse.ArgumentParser(description="Evaluate alpha in Greedy Mapping and DAG Routing.")
    parser.add_argument("phase", choices=("legacy", "smoke", "fit", "holdout", "extended", "stress"))
    parser.add_argument("--out", type=Path, required=True, help="New or empty results directory")
    parser.add_argument("--selection", type=Path, help="Frozen selected.json from fit")
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 0, 1, 2, 3])
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--swap-trials", type=int, default=1)
    parser.add_argument("--layout-trials", type=int, default=4)
    parser.add_argument("--timeout", type=float, default=60)
    parser.add_argument("--no-bridge", action="store_true", help="Disable BRIDGE in the C++ ablation")
    args = parser.parse_args()
    if (args.repeats < 1 or args.warmup < 0 or args.swap_trials < 1 or args.layout_trials < 1
            or args.timeout <= 0 or min(args.seeds) < 0 or len(args.seeds) != len(set(args.seeds))):
        parser.error("Invalid seeds, repetitions, trials, or timeout")
    if args.out.exists() and (not args.out.is_dir() or any(args.out.iterdir())):
        parser.error("--out must be new or empty")
    args.out.mkdir(parents=True, exist_ok=True)
    if args.phase == "legacy":
        legacy_check(args.out, args.timeout)
        return 0

    if args.phase == "smoke":
        verify_smoke(args.out, args.timeout)
        temporary = {
            "mapping": {"profile": "layer", "alpha_m": 0.8}, "routing": {"alpha_r": 0.8},
            "mapping_by_profile": {},
        }
        arms = final_arms(temporary)
    elif args.phase == "fit":
        arms = fitting_arms()
    else:
        if args.selection is None:
            parser.error("--selection is required for a frozen evaluation")
        selection = read_json(args.selection)
        protocol = selection["protocol"]
        actual = (args.seeds, args.swap_trials, args.layout_trials, not args.no_bridge, qiskit.__version__)
        expected = tuple(protocol[k] for k in ("seeds", "swap_trials", "layout_trials", "allow_bridge", "qiskit"))
        if actual != expected:
            parser.error("Use the same seeds, trials, BRIDGE setting and Qiskit version as fit")
        test_circuits = {name for names in cases()[args.phase].values() for name in names}
        if test_circuits.intersection(protocol["fit_circuits"]):
            parser.error("A circuit appears in both fitting and evaluation")
        arms = final_arms(selection)

    snapshots = topology_data()
    suite = cases()[args.phase]
    write_json(args.out / "run.json", {
        "phase": args.phase, "python": platform.python_version(), "qiskit": qiskit.__version__,
        "platform": platform.platform(), "seeds": args.seeds, "repeats": args.repeats,
        "warmup": args.warmup, "swap_trials": args.swap_trials, "layout_trials": args.layout_trials,
        "allow_bridge": not args.no_bridge, "timeout_cpp_s": args.timeout,
        "arms": [asdict(arm) for arm in arms], "cases": suite,
        "qasm_sha256": {
            name: hashlib.sha256((ROOT / "benchmarks" / f"{name}.qasm").read_bytes()).hexdigest()
            for name in sorted({name for names in suite.values() for name in names})
        },
    })
    rows = []
    with (args.out / "results.csv").open("w", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=FIELDS)
        writer.writeheader()
        for topology_name, benchmarks in suite.items():
            for name in benchmarks:
                batch = run_case(args.phase, topology_name, name, snapshots[topology_name], arms, args)
                rows.extend(batch)
                writer.writerows(batch)
                destination.flush()

    counts = Counter(row["status"] for row in rows)
    write_json(args.out / "status.json", dict(counts))
    if args.phase == "fit":
        write_json(args.out / "selected.json", select_parameters(arms, rows, args))
    else:
        summarize(rows, args.out)
    print(f"{args.phase}: {counts['PASS']}/{len(rows)} measured runs passed", flush=True)
    return 1 if counts["FAIL"] else 0


if __name__ == "__main__":
    sys.exit(main())
