import argparse
from collections import defaultdict
import csv
from pathlib import Path
from statistics import mean, median

METRICS = ("swaps", "bridges", "cx", "added_cx", "depth", "cx_depth",
           "map_core_ms", "map_wall_ms", "total_ms", "full_ms")

COMPARISONS = (
    ("W_with_SABRE", "E2", "E1"),
    ("router_vs_SABRE_fixed", "E3", "E1"),
    ("W_with_our_alphaR1", "E4", "E3"),
    ("alphaR_with_uniform", "E5", "E3"),
    ("alphaR_with_decay_W", "E6", "E4"),
    ("W_with_decay_R", "E6", "E5"),
    ("combined_vs_our_uniform", "E6", "E3"),
    ("combined_vs_uniform_SABRE", "E6", "E1"),
    ("combined_vs_SABRE_full", "E6", "E7"),
    ("router_decay_vs_SABRE_full", "E5", "E7"),
    ("SABRE_layout_vs_greedy_uniform", "E8", "E1"),
    ("SABRE_layout_vs_greedy_decay", "E8", "E2"),
    ("W_layer_with_SABRE", "W_layer", "E1"),
    ("W_normalized_layer_with_SABRE", "W_normalized_layer", "E1"),
    ("W_index_with_SABRE", "W_index", "E1"),
    ("W_normalized_index_with_SABRE", "W_normalized_index", "E1"),
    ("member_1pass_vs_SABRE_full", "Member_1pass", "E7"),
)


def write_csv(path, rows, fields=None):
    fields = list(fields or (list(rows[0]) if rows else []))
    with path.open("w", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def by_seed(rows):
    groups = defaultdict(list)
    for row in rows:
        key = tuple(row[label] for label in ("topology", "benchmark", "arm", "seed"))
        groups[key].append(row)
    return groups


def case_averages(rows):
    seed_groups = by_seed(rows)
    case_groups = defaultdict(list)
    for key, group in seed_groups.items():
        case_groups[key[:3]].append(group)
    averaged = {}
    for key, all_seeds in case_groups.items():
        if any(row["status"] != "PASS" for group in all_seeds for row in group):
            averaged[key] = {}
            continue
        averaged[key] = {
            metric: mean(median(float(row[metric]) for row in group) for group in all_seeds)
            for metric in METRICS
            if all(row.get(metric, "") != "" for group in all_seeds for row in group)
        }
    return averaged


def summarize(results, out):
    averaged = case_averages(results)
    cases = sorted({key[:2] for key in averaged})
    arms = {key[2] for key in averaged}
    pairs = []
    for label, candidate, baseline in COMPARISONS:
        if {candidate, baseline} - arms:
            continue
        for topology, benchmark in cases:
            a = averaged.get((topology, benchmark, candidate), {})
            b = averaged.get((topology, benchmark, baseline), {})
            for metric in METRICS:
                if metric not in a or metric not in b:
                    continue
                pairs.append(dict(
                    contrast=label, topology=topology, benchmark=benchmark,
                    metric=metric, delta=round(a[metric] - b[metric], 9),
                ))
    if {"E3", "E4", "E5", "E6"} <= arms:
        for topology, benchmark in cases:
            results_234 = [averaged.get((topology, benchmark, arm), {}) for arm in ("E3", "E4", "E5", "E6")]
            for metric in ("swaps", "cx", "depth"):
                if all(metric in r for r in results_234):
                    base, w, r, combined = (r[metric] for r in results_234)
                    pairs.append(dict(
                        contrast="interaction_W_x_alphaR", topology=topology, benchmark=benchmark,
                        metric=metric, delta=round(combined - r - w + base, 9),
                    ))

    grouped = defaultdict(list)
    for row in pairs:
        for topology in (row["topology"], "all"):
            grouped[row["contrast"], topology, row["metric"]].append(row["delta"])
    summary = []
    for (contrast, topology, metric), deltas in sorted(grouped.items()):
        w = sum(x < -1e-8 for x in deltas)
        loss = sum(x > 1e-8 for x in deltas)
        summary.append(dict(
            contrast=contrast, topology=topology, metric=metric, cases=len(deltas),
            expected_cases=sum(topology in ("all", t) for t, _ in cases),
            mean_delta=round(mean(deltas), 6), median_delta=round(median(deltas), 6),
            wins=w if not metric.endswith("_ms") else "",
            ties=len(deltas) - w - loss if not metric.endswith("_ms") else "",
            losses=loss if not metric.endswith("_ms") else "",
        ))

    layout_diffs = []
    for (topology, benchmark, arm, seed), group in sorted(by_seed(results).items()):
        if group[0]["status"] == "PASS":
            layout_diffs.append(dict(
                topology=topology, benchmark=benchmark, arm=arm, seed=seed,
                initial_layout=group[0]["initial_layout"], final_layout=group[0]["final_layout"],
            ))
    write_csv(out / "paired.csv", pairs)
    write_csv(out / "summary.csv", summary)
    write_csv(out / "layouts.csv", layout_diffs)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run", type=Path, help="Directory containing results.csv")
    args = parser.parse_args()
    with (args.run / "results.csv").open(newline="", encoding="utf-8") as source:
        summarize(list(csv.DictReader(source)), args.run)
