from dataclasses import dataclass
from math import isclose, remainder, tau
from pathlib import Path
import subprocess
from time import perf_counter_ns

from qiskit import QuantumCircuit, qasm2
from qiskit.circuit import Gate
from qiskit.circuit.equivalence_library import SessionEquivalenceLibrary
from qiskit.quantum_info import Operator
from qiskit.transpiler import CouplingMap, PassManager
from qiskit.transpiler.passes import BasisTranslator, SabreLayout, SabreSwap

BASIS = ("rz", "sx", "x", "cx")
SCALE = 10**12
ROOT = Path(__file__).resolve().parent
BRIDGE_CX = ((0, 1), (1, 2), (0, 1), (1, 2))
SWAP_CX = ((0, 1), (1, 0), (0, 1))


@dataclass(frozen=True)
class Topology:
    width: int
    edges: tuple

    @property
    def coupling(self):
        coupling = CouplingMap()
        for p in range(self.width):
            coupling.add_physical_qubit(p)
        for a, b in self.edges:
            coupling.add_edge(a, b)
            coupling.add_edge(b, a)
        return coupling


@dataclass(frozen=True)
class Arm:
    name: str
    router: str
    profile: str = "uniform"
    alpha_m: float = 1.0
    alpha_r: float = 1.0


@dataclass
class Compiled:
    before_basis: QuantumCircuit
    after_basis: QuantumCircuit
    initial: list
    claimed_final: list
    times: dict


def qubit_ids(circuit, instruction):
    return tuple(circuit.find_bit(q).index for q in instruction.qubits)


def load_qasm(path):
    return qasm2.load(
        path, custom_instructions=qasm2.LEGACY_CUSTOM_INSTRUCTIONS,
        custom_classical=qasm2.LEGACY_CUSTOM_CLASSICAL,
    )


def normalize(path):
    original = load_qasm(path)
    unitary = QuantumCircuit(original.num_qubits, global_phase=original.global_phase)
    for inst in original.data:
        if inst.operation.name == "barrier":
            continue
        if not isinstance(inst.operation, Gate) or inst.clbits:
            raise ValueError(f"{path.name} contains a non-unitary or unsupported instruction")
        unitary.append(inst.operation, qubit_ids(original, inst))
    translator = BasisTranslator(SessionEquivalenceLibrary, list(BASIS))
    logical = PassManager(translator).run(unitary)
    if set(logical.count_ops()) - set(BASIS):
        raise ValueError(f"{path.name} was not translated to the common basis")
    return logical


class Program:
    def __init__(self, logical):
        self.logical = logical
        self.cx = []
        self.before_cx = []
        pending = [[] for _ in logical.qubits]
        for inst in logical.data:
            qubits = qubit_ids(logical, inst)
            if inst.operation.name == "cx":
                a, b = qubits
                self.cx.append(qubits)
                self.before_cx.append((pending[a], pending[b]))
                pending[a], pending[b] = [], []
            else:
                pending[qubits[0]].append(inst.operation)
        self.trailing = pending
        self.signature = wire_signatures(logical, list(range(logical.num_qubits)), None)[0]

    def engine_input(self, topology, edges=None):
        edges = topology.edges if edges is None else edges
        lines = [f"{self.logical.num_qubits} {topology.width} {len(self.cx)} {len(edges)}"]
        lines.extend(f"{a} {b}" for a, b in self.cx)
        lines.extend(f"{a} {b}" for a, b in edges)
        return "\n".join(lines) + "\n"


def run_engine(program, topology, arm, timeout, *, dump=False, bridge=True):
    command = "compile" if arm.router == "our" else "map"
    option = "dump" if dump else ("default" if bridge else "no-bridge")
    request = [
        str(ROOT / "build/research"), command, arm.profile,
        str(arm.alpha_m), str(arm.alpha_r), option,
    ]
    result = subprocess.run(
        request, input=program.engine_input(topology),
        capture_output=True, text=True, timeout=timeout,
    )
    if result.returncode:
        raise RuntimeError(f"C++ {command}: {result.stderr.strip()}")
    values, events = {"W": [], "D": []}, []
    for line in result.stdout.splitlines():
        key, *parts = line.split()
        row = [int(part) for part in parts]
        if key in {"S", "B", "G"}:
            events.append((key, *row))
        elif key in {"W", "D"}:
            values[key].append(row)
        else:
            values[key] = row
    return values, events


def bridge_gate():
    definition = QuantumCircuit(3, name="bridge")
    for a, b in BRIDGE_CX:
        definition.cx(a, b)
    return definition.to_gate()


BRIDGE = bridge_gate()


def replay(program, topology, events, initial):
    physical = QuantumCircuit(topology.width, global_phase=program.logical.global_phase)
    layout = initial.copy()
    inverse = {p: q for q, p in enumerate(layout)}
    neighbors = [set() for _ in range(topology.width)]
    for a, b in topology.edges:
        neighbors[a].add(b)
        neighbors[b].add(a)
    done = set()
    for action, first, *rest in events:
        if action == "S":
            p, r = first, rest[0]
            physical.swap(p, r)
            q, s = inverse.get(p), inverse.get(r)
            if q is not None:
                layout[q] = r
            if s is not None:
                layout[s] = p
            inverse[p], inverse[r] = s, q
            continue

        if not 0 <= first < len(program.cx) or first in done:
            raise ValueError(f"Invalid or repeated CX event {first}")
        done.add(first)
        a, b = program.cx[first]
        p, r = layout[a], layout[b]
        left, right = program.before_cx[first]
        for op in left:
            physical.append(op, [p])
        for op in right:
            physical.append(op, [r])
        if action == "G":
            physical.cx(p, r)
        elif action == "B":
            common = neighbors[p] & neighbors[r]
            if not common:
                raise ValueError(f"BRIDGE endpoints have no common neighbor: {p}, {r}")
            physical.append(BRIDGE, [p, min(common), r])
        else:
            raise ValueError(f"Unknown action {action}")

    if len(done) != len(program.cx):
        raise ValueError("Trace omitted logical CX gates")
    for q, ops in enumerate(program.trailing):
        for op in ops:
            physical.append(op, [layout[q]])
    return physical


def lower_to_basis(routed):
    output = QuantumCircuit(routed.num_qubits, global_phase=routed.global_phase)
    for inst in routed.data:
        args = qubit_ids(routed, inst)
        name = inst.operation.name
        if name == "swap":
            for a, b in SWAP_CX:
                output.cx(args[a], args[b])
        elif name == "bridge":
            for a, b in BRIDGE_CX:
                output.cx(args[a], args[b])
        elif name in BASIS:
            output.append(inst.operation, args)
        else:
            raise ValueError(f"Unsupported routed gate {name}")
    return output


def sabre_layout_pass(coupling, seed, trials, layout_trials, *, skip_routing):
    return PassManager(SabreLayout(
        coupling, seed=seed, max_iterations=3, swap_trials=trials,
        layout_trials=layout_trials, skip_routing=skip_routing,
    ))


def compile_program(program, topology, arm, seed, trials, layout_trials, timeout, bridge=True):
    started = perf_counter_ns()
    logical = program.logical
    times = {}
    if arm.router == "our":
        call = perf_counter_ns()
        native, events = run_engine(program, topology, arm, timeout, bridge=bridge)
        times["native_wall_ms"] = (perf_counter_ns() - call) / 10**6
        initial, final = native["initial"], native["final"]
        replay_start = perf_counter_ns()
        routed = replay(program, topology, events, initial)
        times["replay_ms"] = (perf_counter_ns() - replay_start) / 10**6
        set_native_times(times, native)
        times["route_ms"] = native["route_ns"][0] / 10**6
    else:
        coupling = topology.coupling
        if arm.router == "sabre-full":
            search = sabre_layout_pass(coupling, seed, trials, layout_trials, skip_routing=False)
            routed = search.run(logical)
            if routed.layout is None:
                raise ValueError("Missing SABRE layout metadata")
            initial = routed.layout.initial_index_layout(filter_ancillas=True)
            final = routed.layout.final_index_layout(filter_ancillas=True)
        else:
            map_started = perf_counter_ns()
            if arm.router == "sabre-layout":
                search = sabre_layout_pass(coupling, seed, trials, layout_trials, skip_routing=True)
                search.run(logical)
                initial = [search.property_set["layout"][q] for q in logical.qubits]
            elif arm.router == "sabre-fixed":
                native, _ = run_engine(program, topology, arm, timeout)
                initial = native["initial"]
                set_native_times(times, native)
            else:
                raise ValueError(f"Unknown router {arm.router}")
            times["map_wall_ms"] = (perf_counter_ns() - map_started) / 10**6
            place_and_route = perf_counter_ns()
            placed = QuantumCircuit(topology.width)
            placed.compose(logical, qubits=initial, inplace=True)
            router = PassManager(SabreSwap(coupling, heuristic="decay", seed=seed, trials=trials))
            routed = router.run(placed)
            final_layout = router.property_set.get("final_layout")
            final = initial.copy() if final_layout is None else [
                final_layout[routed.qubits[p]] for p in initial
            ]
            times["route_ms"] = (perf_counter_ns() - place_and_route) / 10**6
    finishing = perf_counter_ns()
    final_circuit = lower_to_basis(routed)
    times["basis_ms"] = (perf_counter_ns() - finishing) / 10**6
    times["total_ms"] = (perf_counter_ns() - started) / 10**6
    return Compiled(routed, final_circuit, initial, final, times)


def set_native_times(times, native):
    for label in ("graph", "weight", "greedy"):
        times[f"{label}_ms"] = native[f"{label}_ns"][0] / 10**6
    times["map_core_ms"] = sum(times[f"{label}_ms"] for label in ("graph", "weight", "greedy"))


def wire_signatures(circuit, initial, topology):
    # Map physical wires to logical wire labels, including unused wires.
    width = circuit.num_qubits
    if len(set(initial)) != len(initial) or any(not 0 <= p < width for p in initial):
        raise ValueError("Layout is not a valid injective mapping")
    at = [-1] * width
    for q, p in enumerate(initial):
        at[p] = q
    idle = iter(range(len(initial), width))
    at = [next(idle) if q == -1 else q for q in at]
    histories = [[] for _ in range(width)]
    edge_set = set(topology.edges) if topology is not None else set()
    swaps = []
    bridges = 0
    for inst in circuit.data:
        name = inst.operation.name
        args = qubit_ids(circuit, inst)
        if name in {"cx", "swap", "bridge"} and topology is not None:
            links = zip(args, args[1:])
            if any(tuple(sorted(edge)) not in edge_set for edge in links):
                raise ValueError(f"{name} uses a non-edge: {args}")
        if name == "swap":
            a, b = args
            at[a], at[b] = at[b], at[a]
            swaps.append(args)
            continue
        if name == "bridge":
            args = args[0], args[2]
            name = "cx"
            bridges += 1
        qubits = tuple(at[p] for p in args)
        gate = (name, qubits, tuple(float(x) for x in inst.operation.params))
        for q in qubits:
            histories[q].append(gate)
    final = [at.index(q) for q in range(len(initial))]
    return histories, final, swaps, bridges


def verify(program, topology, compiled, exact_cache):
    local, audit_final, swaps, bridges = wire_signatures(
        compiled.before_basis, compiled.initial, topology,
    )
    width = program.logical.num_qubits
    if compiled.before_basis.num_qubits != topology.width:
        raise ValueError("Unexpected physical circuit width")
    if local[:width] != program.signature or any(local[width:]):
        raise ValueError("Logical per-wire instruction sequences changed")
    if audit_final != compiled.claimed_final:
        raise ValueError(f"Final layout mismatch: audit={audit_final}, route={compiled.claimed_final}")
    if not isclose(remainder(
        float(compiled.after_basis.global_phase) - float(program.logical.global_phase), tau
    ), 0.0, abs_tol=1e-10):
        raise ValueError("Global phase was not propagated")

    final = compiled.after_basis
    allowed_edges = set(topology.edges)
    for inst in final.data:
        name = inst.operation.name
        if name not in BASIS:
            raise ValueError(f"Final circuit contains an unexpected gate: {name}")
        if name == "cx" and tuple(sorted(qubit_ids(final, inst))) not in allowed_edges:
            raise ValueError("A final CX is outside the hardware topology")
    cx_count = final.count_ops().get("cx", 0)
    if cx_count != len(program.cx) + 3 * (len(swaps) + bridges):
        raise ValueError("Explicit CX count differs from the unoptimized routing overhead")

    verified = "STRUCTURAL"
    if topology.width <= 6:
        key = (
            tuple(compiled.initial),
            tuple((inst.operation.name, qubit_ids(final, inst), tuple(inst.operation.params))
                  for inst in final.data),
        )
        if key not in exact_cache:
            expected = QuantumCircuit(topology.width)
            expected.compose(program.logical, qubits=compiled.initial, inplace=True)
            for a, b in swaps:
                expected.swap(a, b)
            if not Operator(expected).equiv(Operator(final)):
                raise ValueError("Operator check failed")
            exact_cache.add(key)
        verified = "OPERATOR+STRUCTURAL"

    return {
        "check": verified, "swaps": len(swaps), "bridges": bridges,
        "cx": cx_count, "added_cx": cx_count - len(program.cx),
        "depth": final.depth(), "cx_depth": final.depth(lambda i: i.operation.name == "cx"),
    }
