import ast
import math
import operator

def rz_angle(expression):

    # Define the supported binary operations.
    binary_ops = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv
    }


    # Evaluate a node in the expression tree.
    def value(node):

        # Handle integer and floating-point numbers.
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return float(node.value)

        # Handle the mathematical constant pi.
        if isinstance(node, ast.Name) and node.id == "pi":
            return math.pi
        

        # Handle unary positive and negative operators.
        if isinstance(node, ast.UnaryOp):

            # Evaluate the operand recursively.
            operand_value = value(node.operand)

            # Handle the negative sign.
            if isinstance(node.op, ast.USub):
                return -operand_value

            # Handle the positive sign.
            if isinstance(node.op, ast.UAdd):
                return operand_value
            
        # Handle binary operations.
        if isinstance(node, ast.BinOp) and type(node.op) in binary_ops:

            # Evaluate the left operand.
            left_value = value(node.left)

            # Evaluate the right operand.
            right_value = value(node.right)

            # Select the corresponding operation.
            operation = binary_ops[type(node.op)]

            # Apply the operation to both operands.
            return operation(left_value, right_value)


        # Reject unsupported expressions.
        raise ValueError("Unsupported RZ angle expression.")

    # Parse the expression into an AST.
    tree = ast.parse(expression, mode="eval")

   
    # Evaluate the expression.
    result = value(tree.body)

    # Reject infinite or NaN values.
    if not math.isfinite(result):
        raise ValueError("RZ angle must be finite.")

    return result
