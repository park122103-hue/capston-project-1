
import csv
import json
from pathlib import Path

# 1. Load the Stress benchmark list.
splits = json.loads(
    Path("data/benchmark_split.json").read_text(
        encoding="utf-8"
    )
)

benchmarks = splits["stress"]
alpha_values = [0.0, 0.6]

# 2. Load the Stress experiment results.
input_path = Path("runs/stress_alpha_locked.csv")

with input_path.open(
    "r", newline="", encoding="utf-8"
) as file:
    rows = list(csv.DictReader(file))

# 3. Organize results by benchmark and alpha.
results = {}

for row in rows:

    key = (
        row["benchmark"],
        round(float(row["alpha"]), 1)
    )

    if key in results:
        raise ValueError("Duplicate experiment.")

    results[key] = row

expected = {
    (name, alpha)
    for name in benchmarks
    for alpha in alpha_values
}

if set(results) != expected:
    raise ValueError("Missing or unexpected experiment.")

# 4. Calculate metrics for each alpha.
summary = {}

for alpha in alpha_values:

    selected = [
        results[(name, alpha)]
        for name in benchmarks
    ]

    if any(row["status"] != "PASS" for row in selected):
        raise RuntimeError("Incomplete Stress results.")

    total_swaps = sum(
        int(row["swaps"])
        for row in selected
    )

    mean_swap_cx = sum(
        int(row["swaps"]) / int(row["cx"])
        for row in selected
    ) / len(selected)

    mean_depth = sum(
        int(row["depth"])
        for row in selected
    ) / len(selected)

    total_fallbacks = sum(
        int(row["fallbacks"])
        for row in selected
    )

    total_time = sum(
        float(row["runtime_s"])
        for row in selected
    )

    summary[alpha] = {
        "swaps": total_swaps,
        "swap_cx": mean_swap_cx,
        "depth": mean_depth,
        "fallbacks": total_fallbacks,
        "time": total_time
    }

    print(f"\nAlpha = {alpha:.1f}")
    print("PASS:", len(selected))
    print("Total SWAP:", total_swaps)
    print("Mean SWAP/CX:", round(mean_swap_cx, 5))
    print("Mean Depth:", round(mean_depth, 2))
    print("Fallback:", total_fallbacks)
    print("Total Routing Time:", round(total_time, 3))

# 5. Compare the two alpha values.
print("\nSTRESS COMPARISON")

baseline = summary[0.0]
improved = summary[0.6]

for metric in [
    "swaps",
    "swap_cx",
    "depth",
    "fallbacks",
    "time"
]:

    old = baseline[metric]
    new = improved[metric]

    if old == 0:
        print(metric, ": comparison undefined")
        continue

    change = (new - old) / old * 100

    print(
        f"{metric}: {change:+.2f}%"
    )

# 6. Count SWAP wins, ties and losses.
wins = 0
ties = 0
losses = 0

for name in benchmarks:

    old = int(results[(name, 0.0)]["swaps"])
    new = int(results[(name, 0.6)]["swaps"])

    if new < old:
        wins += 1
    elif new == old:
        ties += 1
    else:
        losses += 1

print("\nSWAP Win/Tie/Loss:")
print(wins, ties, losses)
