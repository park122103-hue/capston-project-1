import time
from cost import choose_swap, layout_after_swap
MAX_STALLED_SWAPS = 48
MAX_TOTAL_SWAPS = 300_000
from dataclasses import dataclass

@dataclass
class RouteMetrics:
    swaps: int = 0
    depth: int = 0
    fallbacks: int = 0
    first_swap: tuple | None = None
    first_score: float | None = None

class Frontier:
    def __init__(self, circuit):
        # Store the circuit.
        self.circuit = circuit

        # Track the next gate on each logical qubit.
        self.next_gate = [0] * circuit.n_qubits

        # Track the next CX on each logical qubit.
        self.next_cx = [0] * circuit.n_qubits

        # Count completed original gates.
        self.completed = 0

    def ready_gates(self):
        # Find the first unfinished gate on every wire.
        heads = []

        for wire, index in zip(
            self.circuit.wire_gates,
            self.next_gate
        ):
            if index < len(wire):
                heads.append(wire[index])
            else:
                heads.append(None)

        # Find gates that are ready on all affected wires.
        ready = []

        candidate_ids = sorted({
            head for head in heads
            if head is not None
        })

        for gate_id in candidate_ids:
            gate = self.circuit.gates[gate_id]

            if all(heads[q] == gate_id for q in gate.qubits):
                ready.append(gate)

        return ready

    def finish(self, gate):
        # Advance the gate pointer on each affected qubit.
        for q in gate.qubits:
            self.next_gate[q] += 1

            # Advance the CX pointer only for CX gates.
            if gate.is_cx:
                self.next_cx[q] += 1

        # Count one completed gate.
        self.completed += 1

def add_to_schedule(available_at, sites, duration):
    # Find when all required physical sites are available.
    start = max(available_at[site] for site in sites)

    # Calculate the operation's completion time.
    end = start + duration

    # Update the availability of affected physical sites.
    for site in sites:
        available_at[site] = end

def route(circuit, hardware, initial_layout, alpha, timeout_s):

    # Validate the alpha parameter.
    if not 0 <= alpha <= 1:
        raise ValueError("Alpha must be between 0 and 1.")

    # Initialize the routing state.
    layout = initial_layout.copy()
    frontier = Frontier(circuit)
    metrics = RouteMetrics()

    available_at = [0] * len(hardware.distance)

    visited_layouts = {tuple(layout)}
    stalled = 0

    deadline = time.monotonic() + timeout_s

    # Apply one SWAP and update its metrics.
    def apply_swap(edge, score=None):
        nonlocal layout, stalled

        if metrics.swaps >= MAX_TOTAL_SWAPS:
            raise RuntimeError("Maximum SWAP count exceeded.")

        occupant = {
            site: q
            for q, site in enumerate(layout)
        }

        layout = layout_after_swap(layout, occupant, edge)

        add_to_schedule(available_at, edge, duration=3)

        if metrics.first_swap is None:
            metrics.first_swap = edge
            metrics.first_score = score

        metrics.swaps += 1
        stalled += 1

    # Main routing loop.
    while frontier.completed < len(circuit.gates):

        if time.monotonic() >= deadline:
            raise TimeoutError("Routing timeout exceeded.")

        ready = frontier.ready_gates()

        if not ready:
            raise RuntimeError("No ready gates found.")

        # Find executable original gates.
        executable = []

        for gate in ready:
            sites = tuple(layout[q] for q in gate.qubits)

            if (
                not gate.is_cx
                or hardware.distance[sites[0]][sites[1]] == 1
            ):
                executable.append((gate, sites))

        # Execute gates before attempting a SWAP.
        if executable:

            for gate, sites in executable:
                add_to_schedule(
                    available_at,
                    sites,
                    duration=1
                )
                frontier.finish(gate)

            visited_layouts = {tuple(layout)}
            stalled = 0

            continue

        # Identify sites involved in blocked CX gates.
        blocked_sites = {
            layout[q]
            for gate in ready
            for q in gate.qubits
        }

        # Select the best Greedy SWAP.
        edge, score = choose_swap(
            blocked_sites,
            hardware,
            layout,
            circuit.cx_partners,
            frontier.next_cx,
            alpha
        )

        occupant = {
            site: q
            for q, site in enumerate(layout)
        }

        possible_layout = layout_after_swap(
            layout,
            occupant,
            edge
        )

        cycle_detected = (
            tuple(possible_layout) in visited_layouts
        )

        stalled_limit_reached = (
            stalled >= MAX_STALLED_SWAPS
        )

        if cycle_detected or stalled_limit_reached:

            # Use the shortest-path fallback.
            control, target = ready[0].qubits

            path = hardware.paths[
                layout[control]
            ][
                layout[target]
            ]

            metrics.fallbacks += 1

            for i in range(len(path) - 2):
                fallback_edge = (
                    path[i],
                    path[i + 1]
                )
                apply_swap(fallback_edge)

            visited_layouts = {tuple(layout)}

        else:

            # Apply the highest-scoring Greedy SWAP.
            apply_swap(edge, score)

            visited_layouts.add(tuple(layout))

    # Calculate the final scheduled depth.
    metrics.depth = max(available_at)

    return metrics
