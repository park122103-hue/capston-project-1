WEIGHT_CUTOFF = 1e-7
TIE_TOLERANCE = 1e-12
def layout_after_swap(layout, occupant, edge):
    # Get the two physical sites of the SWAP.
    a, b = edge

    # Create a copy of the current layout.
    after = layout.copy()

    # Move the logical qubit at site a to site b.
    if a in occupant:
        after[occupant[a]] = b

    # Move the logical qubit at site b to site a.
    if b in occupant:
        after[occupant[b]] = a

    return after

def swap_score(edge, layout, occupant, distance,
               cx_partners, next_cx, alpha):

    # Simulate the candidate SWAP.
    after = layout_after_swap(layout, occupant, edge)

    total = 0.0

    # Evaluate each occupied endpoint of the SWAP.
    for site in edge:
        if site not in occupant:
            continue

        q = occupant[site]
        weight = 1.0
        partners = cx_partners[q]

        # Evaluate the remaining CX interactions.
        for index in range(next_cx[q], len(partners)):
            partner = partners[index]

            before_dist = distance[layout[q]][layout[partner]]
            after_dist = distance[after[q]][after[partner]]

            gain = before_dist - after_dist

            # Stop if the gain is negative or weight is too small.
            if gain < 0 or weight < WEIGHT_CUTOFF:
                break

            # Accumulate the weighted distance improvement.
            total += gain * weight

            # Apply decay for the next CX.
            weight *= alpha

    return 10.0 * total

def choose_swap(blocked_sites, hardware, layout,
                cx_partners, next_cx, alpha):

    # Build the physical-to-logical mapping.
    occupant = {
        site: q
        for q, site in enumerate(layout)
    }

    # Store the score of each candidate SWAP.
    scores = {}

    for edge in hardware.edges:
        a, b = edge

        # Consider edges connected to blocked sites.
        if a in blocked_sites or b in blocked_sites:
            scores[edge] = swap_score(
                edge,
                layout,
                occupant,
                hardware.distance,
                cx_partners,
                next_cx,
                alpha
            )

    # Find the highest SWAP score.
    maximum = max(scores.values())

    # Resolve ties using the smallest edge labels.
    best = min(
        edge
        for edge, score in scores.items()
        if maximum - score <= TIE_TOLERANCE
    )

    return best, scores[best]

