
import csv
import json
from pathlib import Path

# 1. Load the fixed Holdout benchmark list.
splits = json.loads(
    Path("data/benchmark_split.json").read_text(
        encoding="utf-8"
    )
)

benchmarks = splits["holdout"]
alpha_values = [0.0, 0.6]

# 2. Read Holdout results.
with Path("runs/holdout_alpha_locked.csv").open(
    "r", newline="", encoding="utf-8"
) as file:
    rows = list(csv.DictReader(file))

# 3. Organize results by benchmark and alpha.
results = {}

for row in rows:
    key = (
        row["benchmark"],
        round(float(row["alpha"]), 1)
    )

    if key in results:
        raise ValueError("Duplicate experiment found.")

    results[key] = row

# Confirm that every expected experiment exists.
expected = {
    (name, alpha)
    for name in benchmarks
    for alpha in alpha_values
}

if set(results) != expected:
    raise ValueError("Missing or unexpected experiments.")

# 4. Calculate summary metrics.
for alpha in alpha_values:

    selected = [
        results[(name, alpha)]
        for name in benchmarks
    ]

    pass_count = sum(
        row["status"] == "PASS"
        for row in selected
    )

    if pass_count != len(benchmarks):
        raise RuntimeError("Incomplete Holdout results.")

    total_swaps = sum(
        int(row["swaps"])
        for row in selected
    )

    mean_swap_cx = sum(
        int(row["swaps"]) / int(row["cx"])
        for row in selected
    ) / len(selected)

    mean_depth = sum(
        int(row["depth"])
        for row in selected
    ) / len(selected)

    total_fallbacks = sum(
        int(row["fallbacks"])
        for row in selected
    )

    print(f"\nAlpha = {alpha:.1f}")
    print("PASS:", pass_count)
    print("Total SWAP:", total_swaps)
    print("Mean SWAP/CX:", round(mean_swap_cx, 5))
    print("Mean Depth:", round(mean_depth, 2))
    print("Fallback:", total_fallbacks)

# 5. Compare SWAP performance on each benchmark.
wins = 0
ties = 0
losses = 0

for name in benchmarks:

    baseline = int(
        results[(name, 0.0)]["swaps"]
    )

    selected = int(
        results[(name, 0.6)]["swaps"]
    )

    if selected < baseline:
        wins += 1
    elif selected == baseline:
        ties += 1
    else:
        losses += 1

print("\nHoldout SWAP comparison")
print("Win:", wins)
print("Tie:", ties)
print("Loss:", losses)
