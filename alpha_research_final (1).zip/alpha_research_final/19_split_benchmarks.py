
import json
from pathlib import Path

# Define benchmark groups.
splits = {
    "fit": [
        "4mod5-v1_22.qasm",
        "alu-v0_27.qasm",
        "ising_model_10.qasm",
        "ising_model_13.qasm",
        "ising_model_16.qasm",
        "mod5mils_65.qasm",
        "qft_10.qasm",
        "qft_13.qasm",
        "qft_16.qasm",
        "qft_20.qasm",
        "adr4_197.qasm",
        "cycle10_2_110.qasm",
        "misex1_241.qasm",
        "radd_250.qasm",
        "rd73_252.qasm",
        "co14_215.qasm",
        "sqn_258.qasm",
    ],

    "holdout": [
        "4gt13_92.qasm",
        "decod24-v2_43.qasm",
        "rd84_142.qasm",
        "rd84_253.qasm",
        "square_root_7.qasm",
        "sym6_145.qasm",
        "z4_268.qasm",
    ],

    "stress": [
        "hwb9_119.qasm",
        "sym9_193.qasm",
        "urf4_187.qasm",
        "urf5_158.qasm",
    ],
}

benchmark_dir = Path("data/benchmarks")

# Collect all benchmark filenames.
all_files = [
    path.name
    for path in benchmark_dir.rglob("*.qasm")
]

# Collect filenames assigned to the groups.
assigned_files = []

for group, filenames in splits.items():
    assigned_files.extend(filenames)

# Check for duplicate assignments.
if len(assigned_files) != len(set(assigned_files)):
    raise ValueError("Duplicate benchmark assignment.")

# Check that all files are assigned exactly once.
if (
    len(all_files) != len(set(all_files))
    or set(all_files) != set(assigned_files)
):
    raise ValueError("Missing or unknown benchmark files.")

# Save the fixed benchmark split.
output_path = Path("data/benchmark_split.json")

output_path.write_text(
    json.dumps(splits, indent=2),
    encoding="utf-8"
)

print("Benchmark split saved:", output_path)

for group, filenames in splits.items():
    print(group.upper(), ":", len(filenames))

print("Total:", len(assigned_files))
print("All benchmarks assigned exactly once.")
