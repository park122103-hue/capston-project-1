
import csv
import json
import time
from pathlib import Path

from circuit_parser import read_circuit
from hardware_parser import load_hardware
from greedy_mapping import initial_layout
from router import route


# 1. Load the benchmark split.
split_path = Path("data/benchmark_split.json")

splits = json.loads(
    split_path.read_text(encoding="utf-8")
)

# Use all Fit benchmarks.
# Holdout benchmarks were not used to select alpha.
holdout_files = splits["holdout"]


# 2. Load the hardware.
hardware = load_hardware(
    Path("data/tokyo20.json")
)


# 3. Define alpha values.
# The selected alpha is fixed using Fit results.
selected_alpha = 0.6

# Compare against the predefined reference setting.
reference_alpha = 0.0

alpha_values = [
    reference_alpha,
    selected_alpha
]


# 4. Prepare the output file.
output_dir = Path("runs")
output_dir.mkdir(exist_ok=True)

output_path = output_dir / "holdout_alpha_locked.csv"
columns = [
    "benchmark",
    "alpha",
    "gates",
    "cx",
    "swaps",
    "depth",
    "fallbacks",
    "runtime_s",
    "status",
]


# Find experiments that have already been recorded.
completed_runs = set()

if output_path.exists():

    with output_path.open(
        "r",
        newline="",
        encoding="utf-8"
    ) as file:

        reader = csv.DictReader(file)

        for row in reader:

            benchmark_name = row["benchmark"]
            alpha = round(float(row["alpha"]), 1)

            completed_runs.add(
                (benchmark_name, alpha)
            )

print("Previously recorded runs:", len(completed_runs))

# 5. Run the experiments.

with output_path.open(
    "a",
    newline="",
    encoding="utf-8"
) as file:

    writer = csv.DictWriter(
        file,
        fieldnames=columns
    )

    # Write the header only for a new file.
    if file.tell() == 0:
        writer.writeheader()


    for benchmark_name in holdout_files:

        # Read the benchmark circuit.
        circuit = read_circuit(
            Path("data/benchmarks") / benchmark_name
        )

        # Count CX gates.
        cx_count = sum(
            1 for gate in circuit.gates
            if gate.is_cx
        )

        # Compute the initial layout once.
        layout = initial_layout(
            circuit,
            hardware.distance
        )

        print("\nBenchmark:", benchmark_name)
        print("Initial layout:", layout)

        # Evaluate every alpha value.
        for alpha in alpha_values:
            # Skip runs that were already recorded.
            if (benchmark_name, alpha) in completed_runs:
                print("Skipped:", benchmark_name, alpha)
                continue

            start = time.perf_counter()

            status = "PASS"
            swaps = None
            depth = None
            fallbacks = None

            try:
                metrics = route(
                    circuit,
                    hardware,
                    layout,
                    alpha=alpha,
                    timeout_s=600 
                )

                swaps = metrics.swaps
                depth = metrics.depth
                fallbacks = metrics.fallbacks

            except TimeoutError:
                status = "TIMEOUT"

            except RuntimeError as error:
                status = "ERROR"
                print("Routing error:", error)

            elapsed = time.perf_counter() - start

            # Save the result.
            writer.writerow({
                "benchmark": benchmark_name,
                "alpha": alpha,
                "gates": len(circuit.gates),
                "cx": cx_count,
                "swaps": swaps,
                "depth": depth,
                "fallbacks": fallbacks,
                "runtime_s": round(elapsed, 4),
                "status": status,
            })

            file.flush()

            print(
                f"Alpha={alpha:.1f} | "
                f"Status={status} | "
                f"SWAP={swaps} | "
                f"Depth={depth} | "
                f"Time={elapsed:.3f}s"
            )


print("\nExperiment completed.")
print("Results saved to:", output_path)
