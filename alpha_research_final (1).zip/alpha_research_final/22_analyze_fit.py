
import csv
import json
from pathlib import Path

# 1. Load the benchmark split.
split_path = Path("data/benchmark_split.json")

splits = json.loads(
    split_path.read_text(encoding="utf-8")
)

fit_files = splits["fit"]

# 2. Load routing results.
input_path = Path("runs/fit_alpha_full.csv")

with input_path.open(
    "r", newline="", encoding="utf-8"
) as file:
    rows = list(csv.DictReader(file))

# 3. Define the expected experiments.
alpha_values = [
    round(i / 10, 1)
    for i in range(11)
]

expected = {
    (name, alpha)
    for name in fit_files
    for alpha in alpha_values
}

recorded = [
    (row["benchmark"], round(float(row["alpha"]), 1))
    for row in rows
]

if len(recorded) != len(set(recorded)):
    raise ValueError("Duplicate experiment found.")

if set(recorded) != expected:
    raise ValueError("Missing or unexpected experiments.")

print("Total experiments:", len(rows))

# 4. Summarize results for each alpha.
summary = []

for alpha in alpha_values:

    alpha_rows = [
        row for row in rows
        if round(float(row["alpha"]), 1) == alpha
    ]

    passed = [
        row for row in alpha_rows
        if row["status"] == "PASS"
    ]

    pass_count = len(passed)

    # Prevent incomplete runs from biasing the ranking.
    if pass_count != len(fit_files):
        print("Incomplete alpha:", alpha)
        continue

    total_swaps = sum(
        int(row["swaps"])
        for row in passed
    )

    mean_swap_cx = sum(
        int(row["swaps"]) / int(row["cx"])
        for row in passed
    ) / pass_count

    mean_depth = sum(
        int(row["depth"])
        for row in passed
    ) / pass_count

    total_fallbacks = sum(
        int(row["fallbacks"])
        for row in passed
    )

    result = {
        "alpha": alpha,
        "pass_count": pass_count,
        "total_swaps": total_swaps,
        "mean_swap_cx": mean_swap_cx,
        "mean_depth": mean_depth,
        "total_fallbacks": total_fallbacks,
    }

    summary.append(result)

    print(
        f"Alpha={alpha:.1f} | "
        f"PASS={pass_count} | "
        f"SWAP={total_swaps} | "
        f"SWAP/CX={mean_swap_cx:.5f} | "
        f"Depth={mean_depth:.2f} | "
        f"Fallback={total_fallbacks}"
    )

# 5. Select the best alpha.
if len(summary) != len(alpha_values):
    raise RuntimeError("Cannot rank incomplete Fit results.")

best = min(
    summary,
    key=lambda r: (
        r["mean_swap_cx"],
        r["mean_depth"],
        r["total_fallbacks"],
        r["alpha"]
    )
)

print("\nBEST ALPHA:", best["alpha"])
print("Mean SWAP/CX:", best["mean_swap_cx"])
print("Mean Depth:", best["mean_depth"])

# 6. Save the summary.
output_path = Path("runs/fit_alpha_summary.csv")

with output_path.open(
    "w", newline="", encoding="utf-8"
) as file:

    writer = csv.DictWriter(
        file,
        fieldnames=list(summary[0].keys())
    )

    writer.writeheader()
    writer.writerows(summary)

print("Summary saved:", output_path)
