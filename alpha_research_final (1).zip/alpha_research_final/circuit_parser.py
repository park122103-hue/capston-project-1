import math
import re

from dataclasses import dataclass
from angle_parser import rz_angle

@dataclass(frozen=True)
class Gate:
    name: str
    qubits: tuple[int, ...]
    angle: float | None = None

    @property
    def is_cx(self):
        return self.name == "cx"


@dataclass
class Circuit:
    n_qubits: int
    gates: list[Gate]
    wire_gates: list[list[int]]
    cx_partners: list[list[int]]
    original_cx: int

def read_cx(statement):
    # Match the CX statement.
    pattern = r"cx\s+q\[(\d+)\]\s*,\s*q\[(\d+)\]"
    match = re.fullmatch(pattern, statement)

    # Reject invalid CX syntax.
    if match is None:
        raise ValueError("Invalid CX syntax.")

    # Extract the logical qubit indices.
    a_text, b_text = match.groups()
    a = int(a_text)
    b = int(b_text)

    # Check that the qubits are different.
    if a == b:
        raise ValueError("CX requires two different qubits.")

    return (a, b)

def read_single_gate(statement):
    # Define the supported single-qubit gates.
    pattern = r"(h|x|z|t|tdg|s|sdg)\s+q\[(\d+)\]"

    # Check the statement syntax.
    match = re.fullmatch(pattern, statement)

    if match is None:
        raise ValueError("Invalid single-qubit gate syntax.")

    # Extract the gate name and qubit index.
    gate_name, qubit_text = match.groups()

    # Convert the qubit index to an integer.
    qubit = int(qubit_text)

    return gate_name, qubit

def read_rz(statement):
    # Define the RZ gate pattern.
    pattern = r"rz\(([^()]*)\)\s+q\[(\d+)\]"

    # Check the statement syntax.
    match = re.fullmatch(pattern, statement)

    if match is None:
        raise ValueError("Invalid RZ gate syntax.")

    # Extract the angle expression and qubit index.
    angle_text, qubit_text = match.groups()

    # Convert the qubit index into an integer.
    qubit = int(qubit_text)

    return angle_text, qubit


def read_gate(statement):
    # Extract the gate type.
    gate_type = statement.split(maxsplit=1)[0].split("(")[0]

    # Handle CX gates.
    if gate_type == "cx":
        qubits = read_cx(statement)

        return Gate(
            name="cx",
            qubits=qubits
        )

    # Handle supported single-qubit gates.
    if gate_type in ("h", "x", "z", "t", "tdg", "s", "sdg"):
        name, qubit = read_single_gate(statement)

        # Define rotation angles for phase gates.
        phase_angles = {
            "t": math.pi / 4,
            "tdg": -math.pi / 4,
            "s": math.pi / 2,
            "sdg": -math.pi / 2
        }

        # Convert phase gates into RZ gates.
        if name in phase_angles:
            return Gate(
                name="rz",
                qubits=(qubit,),
                angle=phase_angles[name]
            )

        # Keep other single-qubit gates unchanged.
        return Gate(
            name=name,
            qubits=(qubit,)
        )

    # Handle RZ gates with an angle expression.
    if gate_type == "rz":

        # Extract the angle expression and qubit index.
        angle_text, qubit = read_rz(statement)

        # Convert the angle expression into a float.
        angle = rz_angle(angle_text)

        # Create and return the RZ gate.
        return Gate(
            name="rz",
            qubits=(qubit,),
            angle=angle
        )

    # Reject gate types not implemented yet.
    raise ValueError("Gate type not supported yet.")


def read_circuit(path):
    # Read the QASM file.
    text = path.read_text(encoding="utf-8-sig")

    # Remove multi-line comments.
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)

    # Remove single-line comments.
    text = "\n".join(
        line.split("//")[0]
        for line in text.splitlines()
    )

    # Split the QASM text into statements.
    statements = [
        part.strip()
        for part in text.split(";")
        if part.strip()
    ]

    # Validate the QASM header.
    if not statements or statements[0] != "OPENQASM 2.0":
        raise ValueError("Invalid OPENQASM 2.0 header.")

    
    # Initialize the number of logical qubits.
    n_qubits = None
    # Store all parsed quantum gates.
    gates = []

    # Count the original CX gates.
    original_cx = 0


    # Process QASM statements after the header.
    for line in statements[1:]:

        # Skip the library declaration and classical registers.
        if line == 'include "qelib1.inc"' or re.fullmatch(
            r"creg\s+\w+\[\d+\]", line
        ):
            continue

        # Check for the quantum register declaration.
        register = re.fullmatch(r"qreg\s+q\[(\d+)\]", line)

        if register:
            # Reject multiple quantum register declarations.
            if n_qubits is not None:
                raise ValueError("Only one quantum register is supported.")

            # Extract the number of logical qubits.
            n_qubits = int(register.group(1))

            # Create an empty gate list for each logical qubit.
            wire_gates = [[] for _ in range(n_qubits)]

            # Store CX interaction partners for each logical qubit.
            cx_partners = [[] for _ in range(n_qubits)]



            continue

        
        # Parse the quantum gate.
        gate = read_gate(line)

        # Check whether the qubits are declared.
        if n_qubits is None or max(gate.qubits) >= n_qubits:
            raise ValueError("Gate uses an undeclared qubit.")
        
        # Get the current gate ID.
        gate_id = len(gates)

        # Store the gate ID on every affected logical qubit.
        for qubit in gate.qubits:
            wire_gates[qubit].append(gate_id)

        
        # Update CX interaction information.
        if gate.is_cx:
            a, b = gate.qubits

            # Record both directions of the interaction.
            cx_partners[a].append(b)
            cx_partners[b].append(a)

            # Count this CX gate.
            original_cx += 1


        # Add the parsed gate to the circuit.
        gates.append(gate)


    # Reject missing or empty quantum registers.
    if not n_qubits:
        raise ValueError("Missing a valid quantum register.")

    # Temporarily return the logical qubit count.
    # Temporarily return the qubit count and parsed gates.
    # Temporarily return the parsed circuit data.
    
    # Return the complete circuit data.
    return Circuit(
        n_qubits=n_qubits,
        gates=gates,
        wire_gates=wire_gates,
        cx_partners=cx_partners,
        original_cx=original_cx
    )
