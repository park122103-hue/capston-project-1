
def initial_layout(circuit, distance):
    # Get logical and physical qubit counts.
    n = circuit.n_qubits
    m = len(distance)

    if not 1 <= n <= m:
        raise ValueError("Invalid logical or physical qubit count.")

    # Build the logical interaction matrix.
    weights = [[0] * n for _ in range(n)]

    for gate in circuit.gates:
        if gate.is_cx:
            a, b = gate.qubits
            weights[a][b] += 1
            weights[b][a] += 1

    # Calculate logical importance and physical centrality.
    importance = [sum(row) for row in weights]
    centrality = [sum(row) for row in distance]

    # Select the first logical and physical qubits.
    first_q = min(
        range(n),
        key=lambda q: (-importance[q], q)
    )

    first_p = min(
        range(m),
        key=lambda p: (centrality[p], p)
    )

    # Initialize the mapping.
    placed = {first_q: first_p}
    remaining = set(range(n)) - {first_q}
    available = set(range(m)) - {first_p}

    # Map the remaining logical qubits.
    while remaining:

        def logical_priority(q):
            affinity = sum(
                weights[q][other]
                for other in placed
            )
            return -affinity, -importance[q], q

        q = min(remaining, key=logical_priority)

        def physical_priority(p):
            cost = sum(
                weights[q][other] * distance[p][site]
                for other, site in placed.items()
            )
            return cost, centrality[p], p

        p = min(available, key=physical_priority)

        placed[q] = p
        remaining.remove(q)
        available.remove(p)

    # Return the physical position of every logical qubit.
    return [placed[q] for q in range(n)]
