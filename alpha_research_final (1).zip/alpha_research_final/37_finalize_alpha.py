
import csv
import json
from pathlib import Path

# 1. Load results from the three Fit searches.
summary_files = [
    "runs/fit_alpha_summary.csv",
    "runs/fit_alpha_refined_summary.csv",
    "runs/fit_alpha_fine_summary.csv",
]

best_alphas = []

for filename in summary_files:

    with open(filename, newline="") as file:
        rows = list(csv.DictReader(file))

    best = min(
        rows,
        key=lambda row: (
            float(row["mean_swap_cx"]),
            float(row["mean_depth"])
        )
    )

    best_alphas.append(float(best["alpha"]))

    print(filename, "->", best["alpha"])

# 2. Confirm the three searches agree.
if not all(alpha == 0.6 for alpha in best_alphas):
    raise ValueError("Alpha selection is inconsistent.")

# 3. Save the selected parameter.
config = {
    "hardware": "tokyo20",
    "algorithm": "greedy_swap_only",
    "alpha_route": 0.6,
    "selection_metric": "mean_swap_cx",
    "fit_benchmarks": 17,
    "holdout_benchmarks": 7,
    "stress_benchmarks": 4,
    "fit_mean_swap_cx": 0.24847091538498683,
}

output_path = Path("data/selected_alpha.json")

output_path.write_text(
    json.dumps(config, indent=2),
    encoding="utf-8"
)

print("\nFINAL ALPHA:", config["alpha_route"])
print("Saved to:", output_path)
