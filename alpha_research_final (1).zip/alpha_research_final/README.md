# Greedy SWAP Routing — Alpha Parameter Research

This is the trimmed research version of the original `alpha_learning` project. Every retained Python script, source file, CSV, QASM benchmark, and JSON configuration was copied **without modifying its contents**. Step-by-step teaching examples, exploratory diagnostics, pilot runs, and Python bytecode caches were excluded.

## 1. Algorithm modules

| File | Purpose |
|---|---|
| `angle_parser.py` | Evaluate RZ angle expressions in QASM. |
| `circuit_parser.py` | Parse QASM circuits and construct the gate dependencies and CX partner lists. |
| `hardware_parser.py` | Load Tokyo20 connectivity and calculate all-pairs shortest paths. |
| `greedy_mapping.py` | Build a Greedy initial logical-to-physical qubit layout. |
| `cost.py` | Evaluate alpha-decayed candidate SWAP scores and select a Greedy SWAP. |
| `router.py` | Run SWAP-only routing, including scheduling, cycle detection, fallback, and performance metrics. |

## 2. Research workflow

Run the following commands from the **project root** (the directory containing `router.py` and the `data/` folder) with Python 3.10 or newer. The project uses the Python standard library only.

```bash
# A. Re-create the fixed Fit / Holdout / Stress allocation (17 / 7 / 4)
python 19_split_benchmarks.py

# B. Fit: coarse search, alpha = 0.0 to 1.0, step = 0.1
python 21_fit_alpha_full.py
python 22_analyze_fit.py

# C. Fit: refined search, alpha = 0.50 to 0.70, step = 0.05
python 33_fit_alpha_refined.py
python 34_analyze_fit_refined.py

# D. Fit: fine search, alpha = 0.56 to 0.64, step = 0.01
python 35_fit_alpha_fine.py
python 36_analyze_fit_fine.py

# E. Finalize alpha using the three Fit summaries
python 37_finalize_alpha.py

# F. Evaluate the locked parameter on unseen benchmarks
python 23_evaluate_holdout.py
python 24_analyze_holdout.py
python 25_evaluate_stress.py
python 26_analyze_stress.py
```

The original completed results are preserved in `runs/` and can be analyzed immediately. The experiment scripts skip `(benchmark, alpha)` pairs already present in their output CSVs. To recompute a particular experiment from scratch, back up and remove its corresponding raw CSV before running its script.

## 3. Data files

- `data/benchmarks/`: all 28 original QASM circuits.
- `data/tokyo20.json`: 20-qubit hardware topology.
- `data/benchmark_split.json`: fixed dataset split.
- `data/selected_alpha.json`: final alpha and its selection metadata.
- `runs/fit_alpha_*.csv`: original Fit trial results and summary tables.
- `runs/holdout_alpha_locked.csv`: Holdout raw experiment results.
- `runs/stress_alpha_locked.csv`: Stress raw experiment results.

## 4. Research notes and limitations

- The original project selects `alpha_route = 0.6` using the average per-benchmark SWAP/CX metric on the 17 Fit circuits. The search covers the finite alpha grids shown above; this is not a proof of a globally optimal continuous alpha.
- The original `37_finalize_alpha.py` **explicitly checks for `0.6`**, and the original Holdout/Stress scripts also **hard-code the selected alpha to `0.6`**. These files were left unchanged as requested. If you change the tuning grid or select a different alpha, these hard-coded values must be updated deliberately.
- The reference used in the Holdout and Stress scripts is `alpha = 0.0`, **not** a separately implemented SABRE or FSQM baseline.
- `router.py` counts SWAP operations and calculates schedule depth assuming 1 time unit per original gate and 3 units per SWAP. Its `fallbacks` count is an important supporting metric; better SWAP count alone does not establish improvements across all metrics.
- The provided project has no final plot-generation module. This package preserves tabular experiment results and the original console analysis scripts; it does not invent new visualizations.
- All paths in the original scripts are relative. Run them from the repository root.
