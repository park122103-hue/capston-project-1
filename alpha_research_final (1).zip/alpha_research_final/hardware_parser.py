
import json
from collections import deque
from dataclasses import dataclass


@dataclass
class Hardware:
    edges: list
    distance: list
    paths: list


def load_hardware(path):
    # Read the hardware configuration.
    config = json.loads(path.read_text(encoding="utf-8"))

    n = config["physical_qubits"]
    edges = sorted({
        tuple(sorted(pair))
        for pair in config["edges"]
    })

    # Build the adjacency list.
    neighbors = [[] for _ in range(n)]

    for a, b in edges:
        if not 0 <= a < b < n:
            raise ValueError("Invalid hardware edge.")

        neighbors[a].append(b)
        neighbors[b].append(a)

    for adjacent in neighbors:
        adjacent.sort()


    # Find shortest paths from every physical qubit.
    distance = []
    paths = []

    for source in range(n):
        from_source = [None] * n
        from_source[source] = [source]

        queue = deque([source])

        while queue:
            current = queue.popleft()

            for neighbor in neighbors[current]:
                if from_source[neighbor] is None:
                    from_source[neighbor] = (
                        from_source[current] + [neighbor]
                    )
                    queue.append(neighbor)

        # Reject disconnected hardware graphs.
        if None in from_source:
            raise ValueError("Hardware graph must be connected.")

        paths.append(from_source)

        distance.append([
            len(path) - 1
            for path in from_source
        ])

    return Hardware(edges, distance, paths)
